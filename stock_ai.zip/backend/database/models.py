"""
SQLAlchemy ORM models.

Covers: users (auth-ready), watchlists, stock metadata, historical data
metadata, analysis results, ML model registry, backtest results, paper
trades, portfolio history, and alerts — per spec Section 25.

Design notes:
- No secrets are ever stored here (API keys live only in environment/.env).
- Numeric financial values use Float for simplicity in this research tool;
  a production ledger-grade system would use Numeric/Decimal, but Float is
  acceptable here since this is not a real-money settlement system.
- Timestamps are stored as timezone-aware UTC; conversion to market
  timezone happens at the presentation layer, not in the database.
"""
from __future__ import annotations

import datetime as dt
import enum
import uuid

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.constants import (
    MarketRegime,
    OrderSide,
    OrderStatus,
    OrderType,
    ResearchSignal,
    RiskLevel,
    SentimentLabel,
    ValidationStage,
)
from backend.database.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


# ---------------------------------------------------------------------------
# Users (authentication-ready; no auth enforced yet — see Phase 12 note)
# ---------------------------------------------------------------------------
class User(Base):
    """
    Registered user. Password is stored as a bcrypt hash only — never
    plaintext. This platform ships with authentication architecture ready,
    but a single-user "local" mode is also supported (see Settings).
    """

    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255))
    display_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    watchlists: Mapped[list["Watchlist"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    portfolios: Mapped[list["PaperPortfolio"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    alerts: Mapped[list["Alert"]] = relationship(back_populates="user", cascade="all, delete-orphan")


# ---------------------------------------------------------------------------
# Stock metadata
# ---------------------------------------------------------------------------
class StockMetadata(Base):
    """Cached, slow-changing descriptive info about a ticker."""

    __tablename__ = "stock_metadata"

    symbol: Mapped[str] = mapped_column(String(20), primary_key=True)
    company_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    exchange: Mapped[str | None] = mapped_column(String(50), nullable=True)
    sector: Mapped[str | None] = mapped_column(String(100), nullable=True)
    industry: Mapped[str | None] = mapped_column(String(100), nullable=True)
    currency: Mapped[str | None] = mapped_column(String(10), nullable=True)
    country: Mapped[str | None] = mapped_column(String(100), nullable=True)
    market_cap: Mapped[float | None] = mapped_column(Float, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_updated: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


# ---------------------------------------------------------------------------
# Historical data metadata (NOT the raw OHLCV bars themselves — those are
# fetched live/cached in-memory or via a lightweight cache table; here we
# only track *what ranges we have* and freshness, per spec Section 32).
# ---------------------------------------------------------------------------
class HistoricalDataMeta(Base):
    """Tracks what historical ranges have been fetched for a symbol, and when."""

    __tablename__ = "historical_data_meta"
    __table_args__ = (UniqueConstraint("symbol", "interval", name="uq_symbol_interval"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    symbol: Mapped[str] = mapped_column(String(20), index=True)
    interval: Mapped[str] = mapped_column(String(10))  # e.g. "1d", "1h"
    earliest_date: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    latest_date: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    data_provider: Mapped[str | None] = mapped_column(String(50), nullable=True)
    is_delayed: Mapped[bool] = mapped_column(Boolean, default=True)
    fetched_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


# ---------------------------------------------------------------------------
# Analysis results (multi-factor Research Score snapshots)
# ---------------------------------------------------------------------------
class AnalysisResult(Base):
    """
    A single point-in-time research snapshot for a symbol, storing the
    computed Research Score and its component sub-scores/explanations.
    Stored so the UI can show history and so backtests/scanners can reuse
    prior computations without needing to recompute if unchanged (caching).
    """

    __tablename__ = "analysis_results"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    symbol: Mapped[str] = mapped_column(String(20), index=True)
    as_of: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), index=True)

    research_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    technical_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    fundamental_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    momentum_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    volume_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    market_regime_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    sector_strength_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    sentiment_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    risk_reward_score: Mapped[float | None] = mapped_column(Float, nullable=True)

    market_regime: Mapped[MarketRegime | None] = mapped_column(SAEnum(MarketRegime), nullable=True)
    research_signal: Mapped[ResearchSignal | None] = mapped_column(SAEnum(ResearchSignal), nullable=True)
    risk_level: Mapped[RiskLevel | None] = mapped_column(SAEnum(RiskLevel), nullable=True)

    ml_model_id: Mapped[str | None] = mapped_column(String(36), ForeignKey("ml_models.id"), nullable=True)
    ml_estimated_probability: Mapped[float | None] = mapped_column(Float, nullable=True)

    # Hypothetical research levels (never guaranteed — see constants.py disclaimers)
    entry_zone_low: Mapped[float | None] = mapped_column(Float, nullable=True)
    entry_zone_high: Mapped[float | None] = mapped_column(Float, nullable=True)
    invalidation_level: Mapped[float | None] = mapped_column(Float, nullable=True)
    target_1: Mapped[float | None] = mapped_column(Float, nullable=True)
    target_2: Mapped[float | None] = mapped_column(Float, nullable=True)
    risk_reward_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)

    explanation: Mapped[str | None] = mapped_column(Text, nullable=True)
    scoring_weights_used: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    warnings: Mapped[list | None] = mapped_column(JSON, nullable=True)
    is_delayed_data: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    ml_model: Mapped["MLModel | None"] = relationship()


# ---------------------------------------------------------------------------
# ML model registry
# ---------------------------------------------------------------------------
class MLModel(Base):
    """
    Model registry entry (spec Section 31). Every prediction must be
    traceable to exactly one row here so users know which model, trained on
    what data, with what validation methodology, produced a given estimate.
    """

    __tablename__ = "ml_models"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String(100))
    version: Mapped[str] = mapped_column(String(50))
    algorithm: Mapped[str] = mapped_column(String(50))  # e.g. "RandomForestClassifier"

    training_period_start: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    training_period_end: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    prediction_horizon_days: Mapped[int] = mapped_column(Integer)
    target_return_threshold_pct: Mapped[float] = mapped_column(Float)
    target_definition: Mapped[str] = mapped_column(Text)  # human-readable target description

    features: Mapped[list] = mapped_column(JSON)  # list of feature names used
    validation_methodology: Mapped[str] = mapped_column(Text)  # e.g. "walk-forward, 3 folds"

    # Held-out test-set performance (never optimized against)
    accuracy: Mapped[float | None] = mapped_column(Float, nullable=True)
    precision: Mapped[float | None] = mapped_column(Float, nullable=True)
    recall: Mapped[float | None] = mapped_column(Float, nullable=True)
    f1_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    roc_auc: Mapped[float | None] = mapped_column(Float, nullable=True)
    calibration_notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    artifact_path: Mapped[str | None] = mapped_column(String(500), nullable=True)  # path to serialized model
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


# ---------------------------------------------------------------------------
# Backtest results
# ---------------------------------------------------------------------------
class BacktestResult(Base):
    """Stores summary metrics for a single backtest run, tagged by validation stage."""

    __tablename__ = "backtest_results"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    symbol: Mapped[str] = mapped_column(String(20), index=True)
    strategy_name: Mapped[str] = mapped_column(String(100))
    strategy_params: Mapped[dict] = mapped_column(JSON)

    period_start: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    period_end: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    validation_stage: Mapped[ValidationStage] = mapped_column(SAEnum(ValidationStage))

    total_return_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    cagr_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    sharpe_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)
    sortino_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)
    max_drawdown_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    win_rate_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    loss_rate_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    profit_factor: Mapped[float | None] = mapped_column(Float, nullable=True)
    num_trades: Mapped[int | None] = mapped_column(Integer, nullable=True)
    avg_trade_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    exposure_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    volatility_pct: Mapped[float | None] = mapped_column(Float, nullable=True)

    benchmark_return_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    benchmark_symbol: Mapped[str | None] = mapped_column(String(20), nullable=True)

    equity_curve: Mapped[list | None] = mapped_column(JSON, nullable=True)  # [{date, equity}, ...]
    trade_log: Mapped[list | None] = mapped_column(JSON, nullable=True)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


# ---------------------------------------------------------------------------
# Watchlists
# ---------------------------------------------------------------------------
class Watchlist(Base):
    __tablename__ = "watchlists"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"))
    name: Mapped[str] = mapped_column(String(100))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="watchlists")
    items: Mapped[list["WatchlistItem"]] = relationship(back_populates="watchlist", cascade="all, delete-orphan")


class WatchlistItem(Base):
    __tablename__ = "watchlist_items"
    __table_args__ = (UniqueConstraint("watchlist_id", "symbol", name="uq_watchlist_symbol"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    watchlist_id: Mapped[str] = mapped_column(String(36), ForeignKey("watchlists.id"))
    symbol: Mapped[str] = mapped_column(String(20))
    added_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    watchlist: Mapped["Watchlist"] = relationship(back_populates="items")


# ---------------------------------------------------------------------------
# Paper trading: portfolios, positions, orders, equity history
# ---------------------------------------------------------------------------
class PaperPortfolio(Base):
    """A simulated trading account. No connection to any real broker exists."""

    __tablename__ = "paper_portfolios"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"))
    name: Mapped[str] = mapped_column(String(100), default="Paper Portfolio")

    starting_cash: Mapped[float] = mapped_column(Float)
    cash_balance: Mapped[float] = mapped_column(Float)

    max_risk_per_trade_pct: Mapped[float] = mapped_column(Float)
    max_portfolio_exposure_pct: Mapped[float] = mapped_column(Float)
    max_open_positions: Mapped[int] = mapped_column(Integer)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="portfolios")
    positions: Mapped[list["PaperPosition"]] = relationship(back_populates="portfolio", cascade="all, delete-orphan")
    orders: Mapped[list["PaperOrder"]] = relationship(back_populates="portfolio", cascade="all, delete-orphan")
    equity_history: Mapped[list["PortfolioEquitySnapshot"]] = relationship(
        back_populates="portfolio", cascade="all, delete-orphan"
    )


class PaperPosition(Base):
    """An open (or closed, for history) simulated position."""

    __tablename__ = "paper_positions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    portfolio_id: Mapped[str] = mapped_column(String(36), ForeignKey("paper_portfolios.id"))
    symbol: Mapped[str] = mapped_column(String(20), index=True)

    quantity: Mapped[float] = mapped_column(Float)
    average_entry_price: Mapped[float] = mapped_column(Float)
    realized_pnl: Mapped[float] = mapped_column(Float, default=0.0)
    is_open: Mapped[bool] = mapped_column(Boolean, default=True)

    opened_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    closed_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    portfolio: Mapped["PaperPortfolio"] = relationship(back_populates="positions")


class PaperOrder(Base):
    """A simulated order (buy or sell). Never touches a real broker/exchange."""

    __tablename__ = "paper_orders"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    portfolio_id: Mapped[str] = mapped_column(String(36), ForeignKey("paper_portfolios.id"))
    symbol: Mapped[str] = mapped_column(String(20), index=True)

    side: Mapped[OrderSide] = mapped_column(SAEnum(OrderSide))
    order_type: Mapped[OrderType] = mapped_column(SAEnum(OrderType))
    status: Mapped[OrderStatus] = mapped_column(SAEnum(OrderStatus), default=OrderStatus.PENDING)

    quantity: Mapped[float] = mapped_column(Float)
    limit_price: Mapped[float | None] = mapped_column(Float, nullable=True)
    fill_price: Mapped[float | None] = mapped_column(Float, nullable=True)

    transaction_cost: Mapped[float] = mapped_column(Float, default=0.0)
    slippage_applied: Mapped[float] = mapped_column(Float, default=0.0)

    stop_loss: Mapped[float | None] = mapped_column(Float, nullable=True)
    take_profit: Mapped[float | None] = mapped_column(Float, nullable=True)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    filled_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    rejection_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    portfolio: Mapped["PaperPortfolio"] = relationship(back_populates="orders")


class PortfolioEquitySnapshot(Base):
    """Daily (or on-demand) snapshot of total portfolio value, for equity-curve charting."""

    __tablename__ = "portfolio_equity_history"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    portfolio_id: Mapped[str] = mapped_column(String(36), ForeignKey("paper_portfolios.id"))
    as_of: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), index=True)
    cash_balance: Mapped[float] = mapped_column(Float)
    positions_value: Mapped[float] = mapped_column(Float)
    total_equity: Mapped[float] = mapped_column(Float)

    portfolio: Mapped["PaperPortfolio"] = relationship(back_populates="equity_history")


# ---------------------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------------------
class AlertType(str, enum.Enum):
    PRICE_CROSSES_MA = "PRICE_CROSSES_MA"
    BREAKOUT = "BREAKOUT"
    BREAKDOWN = "BREAKDOWN"
    UNUSUAL_VOLUME = "UNUSUAL_VOLUME"
    RSI_CONDITION = "RSI_CONDITION"
    RESEARCH_SCORE_THRESHOLD = "RESEARCH_SCORE_THRESHOLD"
    NEWS_EVENT = "NEWS_EVENT"


class Alert(Base):
    """
    An in-app alert condition and its trigger history. Alerts never carry
    guaranteed-profit language; message text is generated from computed
    data only (see backend/analysis explanation engine, Phase 7+).
    """

    __tablename__ = "alerts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"))
    symbol: Mapped[str] = mapped_column(String(20), index=True)
    alert_type: Mapped[AlertType] = mapped_column(SAEnum(AlertType))
    condition_params: Mapped[dict] = mapped_column(JSON)  # e.g. {"ma_period": 50, "direction": "above"}

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_triggered_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    trigger_count: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    user: Mapped["User"] = relationship(back_populates="alerts")
