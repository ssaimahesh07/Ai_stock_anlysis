"""
Database engine and session management.

Works with SQLite for development (DATABASE_URL default) and is
PostgreSQL-ready for production — just change DATABASE_URL in .env.
No code changes are required to switch engines because we avoid any
SQLite-specific or Postgres-specific SQL in the ORM layer.
"""
from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from backend.config import get_settings
from backend.logging_config import get_logger

logger = get_logger(__name__)


class Base(DeclarativeBase):
    """Declarative base class for all ORM models."""


def _build_engine():
    settings = get_settings()
    connect_args = {}
    if settings.database_url.startswith("sqlite"):
        # Needed for SQLite + multiple threads (FastAPI runs handlers in a
        # threadpool). Not applicable/used for PostgreSQL.
        connect_args = {"check_same_thread": False}

    engine = create_engine(
        settings.database_url,
        echo=settings.debug and settings.app_env == "development",
        connect_args=connect_args,
        pool_pre_ping=True,  # avoids stale-connection errors, esp. on Postgres
    )
    logger.info(
        "Database engine created (dialect=%s)", engine.dialect.name
    )
    return engine


engine = _build_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def init_db() -> None:
    """
    Create all tables that don't yet exist.

    This is a lightweight bootstrap for development/SQLite. For production
    with PostgreSQL, use Alembic migrations instead of calling this blindly
    against an existing database.
    """
    # Import models so they register with Base.metadata before create_all.
    from backend.database import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created/verified.")


def get_db() -> Generator[Session, None, None]:
    """
    FastAPI dependency: yields a database session and guarantees it is
    closed after the request, even if an exception occurs.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope() -> Generator[Session, None, None]:
    """
    Context manager for scripts/background jobs (non-FastAPI code paths).

    Commits on success, rolls back on exception, always closes the session.
    """
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        logger.exception("Database session rolled back due to an error.")
        raise
    finally:
        db.close()
