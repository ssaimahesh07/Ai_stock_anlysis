"""
Backtesting engine (spec Section 12).

Simulates trading a signal series against historical OHLCV data with
realistic frictions: transaction costs, slippage, stop-loss, take-profit,
trailing stop, and position sizing. Never uses information from bar t+1 or
later to decide the action taken at bar t (entries/exits execute at the
NEXT bar's open, simulating realistic order fill timing).
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from backend.exceptions import BacktestConfigError


@dataclass
class BacktestConfig:
    initial_capital: float = 100_000.0
    position_size_pct: float = 100.0  # % of capital allocated per trade (single-position engine)
    transaction_cost_bps: float = 5.0  # basis points per trade (entry AND exit each charged)
    slippage_bps: float = 2.0
    stop_loss_pct: float | None = None  # e.g. 5.0 means exit if price drops 5% from entry
    take_profit_pct: float | None = None
    trailing_stop_pct: float | None = None


def run_backtest(df: pd.DataFrame, signal: pd.Series, config: BacktestConfig) -> dict:
    """
    Args:
        df: OHLCV data, DatetimeIndex.
        signal: 1 (want long) / 0 (want flat), aligned to df.index. Computed
            using only data available at that bar (caller's responsibility;
            the strategies in strategies.py already guarantee this).
        config: BacktestConfig.

    Execution model: a signal change observed at bar t is acted on at bar
    t+1's OPEN price (you can't react to today's close before it happens
    in a real trading system) — this avoids look-ahead in execution timing.
    """
    if config.position_size_pct <= 0 or config.position_size_pct > 100:
        raise BacktestConfigError("position_size_pct must be in (0, 100].")
    if len(df) != len(signal):
        raise BacktestConfigError("df and signal must be the same length and aligned.")

    cash = config.initial_capital
    shares = 0.0
    entry_price = None
    peak_price_since_entry = None
    equity_curve = []
    exposure_flags = []  # 1 if holding a position at this bar's close, else 0
    trades: list[dict] = []

    cost_rate = config.transaction_cost_bps / 10_000
    slippage_rate = config.slippage_bps / 10_000

    prev_signal = 0
    for i in range(len(df) - 1):  # -1 because we act on i+1's open
        row = df.iloc[i]
        next_row = df.iloc[i + 1]
        date = df.index[i]

        # Mark-to-market equity at this bar's close
        equity = cash + shares * row["close"]
        equity_curve.append((date, equity))
        exposure_flags.append(1 if shares > 0 else 0)

        # Check stop-loss / take-profit / trailing-stop intrabar (using this bar's low/high)
        if shares > 0 and entry_price is not None:
            peak_price_since_entry = max(peak_price_since_entry or entry_price, row["high"])

            exit_triggered = False
            exit_price = None
            exit_reason = None

            if config.stop_loss_pct is not None:
                stop_price = entry_price * (1 - config.stop_loss_pct / 100)
                if row["low"] <= stop_price:
                    exit_triggered, exit_price, exit_reason = True, stop_price, "stop_loss"

            if not exit_triggered and config.take_profit_pct is not None:
                target_price = entry_price * (1 + config.take_profit_pct / 100)
                if row["high"] >= target_price:
                    exit_triggered, exit_price, exit_reason = True, target_price, "take_profit"

            if not exit_triggered and config.trailing_stop_pct is not None:
                trail_price = peak_price_since_entry * (1 - config.trailing_stop_pct / 100)
                if row["low"] <= trail_price:
                    exit_triggered, exit_price, exit_reason = True, trail_price, "trailing_stop"

            if exit_triggered:
                fill_price = exit_price * (1 - slippage_rate)
                proceeds = shares * fill_price * (1 - cost_rate)
                pnl_pct = (fill_price / entry_price - 1) * 100
                trades.append({
                    "entry_date": trades[-1]["_pending_entry_date"] if trades and "_pending_entry_date" in trades[-1] else None,
                    "exit_date": date, "entry_price": entry_price, "exit_price": fill_price,
                    "pnl_pct": pnl_pct, "reason": exit_reason,
                })
                cash += proceeds
                shares = 0.0
                entry_price = None
                peak_price_since_entry = None
                prev_signal = 0
                continue

        # Signal-driven entry/exit executes at NEXT bar's open
        current_signal = signal.iloc[i]
        if current_signal != prev_signal:
            fill_price = next_row["open"]
            if current_signal == 1 and shares == 0:
                fill_price_adj = fill_price * (1 + slippage_rate)
                allocation = equity * (config.position_size_pct / 100)
                shares_to_buy = (allocation * (1 - cost_rate)) / fill_price_adj
                cost = shares_to_buy * fill_price_adj * (1 + cost_rate)
                if cost <= cash:
                    cash -= cost
                    shares = shares_to_buy
                    entry_price = fill_price_adj
                    peak_price_since_entry = fill_price_adj
                    trades.append({"_pending_entry_date": df.index[i + 1]})
            elif current_signal == 0 and shares > 0:
                fill_price_adj = fill_price * (1 - slippage_rate)
                proceeds = shares * fill_price_adj * (1 - cost_rate)
                pnl_pct = (fill_price_adj / entry_price - 1) * 100 if entry_price else 0.0
                # Replace the pending-entry placeholder with the completed trade record
                if trades and "_pending_entry_date" in trades[-1]:
                    trades[-1] = {
                        "entry_date": trades[-1]["_pending_entry_date"], "exit_date": df.index[i + 1],
                        "entry_price": entry_price, "exit_price": fill_price_adj,
                        "pnl_pct": pnl_pct, "reason": "signal_exit",
                    }
                cash += proceeds
                shares = 0.0
                entry_price = None
                peak_price_since_entry = None
        prev_signal = current_signal

    # Final mark-to-market on last bar
    final_row = df.iloc[-1]
    final_equity = cash + shares * final_row["close"]
    equity_curve.append((df.index[-1], final_equity))
    exposure_flags.append(1 if shares > 0 else 0)

    # Drop any still-open (never exited) trade placeholder — not a completed trade
    trades = [t for t in trades if "_pending_entry_date" not in t]

    equity_series = pd.Series({d: v for d, v in equity_curve}).sort_index()
    exposure_pct = (sum(exposure_flags) / len(exposure_flags) * 100) if exposure_flags else None

    return {
        "equity_curve": equity_series,
        "trades": trades,
        "final_equity": final_equity,
        "final_cash": cash,
        "final_shares": shares,
        "exposure_pct": round(exposure_pct, 2) if exposure_pct is not None else None,
    }
