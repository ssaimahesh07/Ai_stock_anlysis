"""Backtest performance metrics (spec Section 12)."""
from __future__ import annotations

import numpy as np
import pandas as pd


def compute_metrics(equity_curve: pd.Series, trades: list[dict], risk_free_rate_annual: float = 0.0) -> dict:
    """
    Args:
        equity_curve: Series of portfolio equity values indexed by date.
        trades: list of dicts with at least {'pnl_pct': float}.
    """
    if len(equity_curve) < 2:
        return {"note": "Insufficient data to compute backtest metrics."}

    returns = equity_curve.pct_change().dropna()
    total_return_pct = (equity_curve.iloc[-1] / equity_curve.iloc[0] - 1) * 100

    n_days = (equity_curve.index[-1] - equity_curve.index[0]).days
    years = max(n_days / 365.25, 1e-9)
    cagr_pct = ((equity_curve.iloc[-1] / equity_curve.iloc[0]) ** (1 / years) - 1) * 100 if equity_curve.iloc[0] > 0 else None

    ann_vol = returns.std() * np.sqrt(252) if len(returns) > 1 else None
    ann_return = returns.mean() * 252 if len(returns) > 0 else None
    sharpe = (ann_return - risk_free_rate_annual) / ann_vol if ann_vol and ann_vol > 0 else None

    downside_returns = returns[returns < 0]
    downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 1 else None
    sortino = (ann_return - risk_free_rate_annual) / downside_std if downside_std and downside_std > 0 else None

    running_max = equity_curve.cummax()
    drawdown = (equity_curve - running_max) / running_max * 100
    max_drawdown_pct = drawdown.min()

    wins = [t for t in trades if t.get("pnl_pct", 0) > 0]
    losses = [t for t in trades if t.get("pnl_pct", 0) <= 0]
    win_rate_pct = len(wins) / len(trades) * 100 if trades else None
    loss_rate_pct = len(losses) / len(trades) * 100 if trades else None

    gross_profit = sum(t["pnl_pct"] for t in wins)
    gross_loss = abs(sum(t["pnl_pct"] for t in losses))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else (float("inf") if gross_profit > 0 else None)

    avg_trade_pct = float(np.mean([t["pnl_pct"] for t in trades])) if trades else None

    return {
        "total_return_pct": round(float(total_return_pct), 2),
        "cagr_pct": round(float(cagr_pct), 2) if cagr_pct is not None else None,
        "sharpe_ratio": round(float(sharpe), 3) if sharpe is not None else None,
        "sortino_ratio": round(float(sortino), 3) if sortino is not None else None,
        "max_drawdown_pct": round(float(max_drawdown_pct), 2),
        "win_rate_pct": round(win_rate_pct, 2) if win_rate_pct is not None else None,
        "loss_rate_pct": round(loss_rate_pct, 2) if loss_rate_pct is not None else None,
        "profit_factor": round(profit_factor, 3) if isinstance(profit_factor, float) and profit_factor != float("inf") else profit_factor,
        "num_trades": len(trades),
        "avg_trade_pct": round(avg_trade_pct, 3) if avg_trade_pct is not None else None,
        "volatility_pct": round(float(ann_vol * 100), 2) if ann_vol is not None else None,
    }
