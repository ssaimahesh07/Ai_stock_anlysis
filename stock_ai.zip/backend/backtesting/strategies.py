"""
Backtesting strategies (spec Section 12).

Each strategy function takes an OHLCV DataFrame and returns a Series of
signals aligned to the index: 1 = go/stay long, 0 = flat. Signals at row t
are computed using only data up to and including t (no look-ahead).
"""
from __future__ import annotations

import pandas as pd

from backend.indicators.momentum import rsi
from backend.indicators.trend import sma


def trend_following_signal(df: pd.DataFrame, fast: int = 20, slow: int = 50) -> pd.Series:
    """Long when fast SMA > slow SMA (classic trend-following crossover)."""
    close = df["close"]
    fast_sma = sma(close, fast)
    slow_sma = sma(close, slow)
    signal = (fast_sma > slow_sma).astype(int)
    signal[fast_sma.isna() | slow_sma.isna()] = 0
    return signal


def mean_reversion_signal(df: pd.DataFrame, rsi_period: int = 14, oversold: float = 30, overbought: float = 55) -> pd.Series:
    """Long when RSI dips below `oversold`, exit when RSI rises above `overbought`."""
    r = rsi(df["close"], rsi_period)
    signal = pd.Series(0, index=df.index)
    in_position = False
    for i in range(len(df)):
        if pd.isna(r.iloc[i]):
            continue
        if not in_position and r.iloc[i] < oversold:
            in_position = True
        elif in_position and r.iloc[i] > overbought:
            in_position = False
        signal.iloc[i] = 1 if in_position else 0
    return signal


STRATEGY_REGISTRY = {
    "trend_following": trend_following_signal,
    "mean_reversion": mean_reversion_signal,
}
