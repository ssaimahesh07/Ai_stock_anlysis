"""
Central configuration for the Stock AI Research Platform.

All tunable parameters live here so behavior can be changed via environment
variables (.env) without touching code. Nothing in this file should ever
contain a real secret value — secrets are loaded from the environment only.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class ScoringWeights(BaseSettings):
    """
    Weights used to combine independent analysis signals into the
    'Research Score'. Weights must sum to 1.0 (validated at load time).

    These are intentionally exposed as configuration, NOT hardcoded logic,
    so the scoring methodology stays transparent and adjustable.
    """

    technical: float = Field(default=0.25, ge=0, le=1)
    fundamental: float = Field(default=0.20, ge=0, le=1)
    momentum: float = Field(default=0.15, ge=0, le=1)
    volume: float = Field(default=0.10, ge=0, le=1)
    market_regime: float = Field(default=0.10, ge=0, le=1)
    sector_strength: float = Field(default=0.05, ge=0, le=1)
    sentiment: float = Field(default=0.05, ge=0, le=1)
    risk_reward: float = Field(default=0.10, ge=0, le=1)

    def as_dict(self) -> dict[str, float]:
        return {
            "technical": self.technical,
            "fundamental": self.fundamental,
            "momentum": self.momentum,
            "volume": self.volume,
            "market_regime": self.market_regime,
            "sector_strength": self.sector_strength,
            "sentiment": self.sentiment,
            "risk_reward": self.risk_reward,
        }

    def total(self) -> float:
        return round(sum(self.as_dict().values()), 6)


class Settings(BaseSettings):
    """
    Application-wide settings, loaded from environment variables / .env.
    Never put a literal secret default here — use empty string / None so
    absence is obvious and the app can fail loudly and safely.
    """

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    # --- App metadata ---
    app_name: str = "Stock AI Research Platform"
    app_env: Literal["development", "staging", "production"] = "development"
    debug: bool = True
    api_v1_prefix: str = "/api/v1"

    # --- Server ---
    host: str = "0.0.0.0"
    port: int = 8000
    cors_origins: list[str] = ["http://localhost:5173", "http://localhost:8501"]

    # --- Database ---
    database_url: str = f"sqlite:///{BASE_DIR / 'stock_ai.db'}"

    # --- Secrets / API keys (loaded from environment ONLY, never hardcoded) ---
    market_data_api_key: str = ""
    market_data_provider: Literal["yfinance", "alpha_vantage", "mock"] = "yfinance"
    news_api_key: str = ""
    news_provider: Literal["newsapi", "mock"] = "mock"
    secret_key: str = ""  # used for auth token signing if auth is enabled

    # --- Caching ---
    cache_ttl_quote_seconds: int = 60
    cache_ttl_history_seconds: int = 3600
    cache_ttl_fundamentals_seconds: int = 21600
    cache_ttl_news_seconds: int = 1800

    # --- Rate limiting ---
    rate_limit_requests_per_minute: int = 60

    # --- Data freshness ---
    stale_data_threshold_hours: int = 24
    market_timezone: str = "America/New_York"

    # --- Paper trading defaults ---
    default_virtual_cash: float = 100_000.0
    default_transaction_cost_bps: float = 5.0  # basis points per trade
    default_slippage_bps: float = 2.0

    # --- Risk defaults ---
    default_max_risk_per_trade_pct: float = 1.0  # % of account risked per trade
    default_max_portfolio_exposure_pct: float = 50.0
    default_max_open_positions: int = 10

    # --- ML defaults ---
    ml_prediction_horizon_days: int = 10
    ml_target_return_threshold_pct: float = 3.0
    ml_min_training_samples: int = 250
    ml_train_period_years: int = 5
    ml_walk_forward_train_years: int = 3
    ml_walk_forward_validate_years: int = 1
    ml_walk_forward_test_years: int = 1

    # --- Scoring ---
    scoring_weights: ScoringWeights = Field(default_factory=ScoringWeights)

    # --- Logging ---
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_dir: str = str(BASE_DIR / "logs")

    @field_validator("scoring_weights")
    @classmethod
    def validate_weights_sum(cls, v: ScoringWeights) -> ScoringWeights:
        total = v.total()
        if abs(total - 1.0) > 1e-6:
            raise ValueError(
                f"Scoring weights must sum to 1.0, got {total}. "
                f"Adjust weights in configuration."
            )
        return v

    @property
    def is_market_data_configured(self) -> bool:
        """True only if a real (non-mock) provider has credentials set."""
        if self.market_data_provider == "mock":
            return True
        return bool(self.market_data_api_key)

    @property
    def is_news_configured(self) -> bool:
        if self.news_provider == "mock":
            return True
        return bool(self.news_api_key)


@lru_cache
def get_settings() -> Settings:
    """Cached settings singleton. Use this everywhere instead of Settings()."""
    return Settings()
