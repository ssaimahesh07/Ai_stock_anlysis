"""
Abstract market-data provider interface.

Every concrete provider (yfinance, Alpha Vantage, a future broker feed,
mock/offline) implements this same interface. Nothing else in the
application should import a concrete provider directly — always go through
this interface (or the `get_provider()` factory in market_data.py) so
providers can be swapped without touching analysis/ML/API code.

Design principles enforced by this interface:
- Every price/history response carries an explicit `as_of` timestamp and an
  `is_delayed` flag. Callers must never present delayed data as real-time.
- Errors are raised as typed exceptions (see backend/exceptions.py), never
  silently swallowed or replaced with fabricated numbers.
- Missing fields are represented as None, never guessed defaults.
"""
from __future__ import annotations

import datetime as dt
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import pandas as pd


@dataclass(frozen=True)
class Quote:
    """A single point-in-time price quote."""

    symbol: str
    price: float
    previous_close: float | None
    open: float | None
    day_high: float | None
    day_low: float | None
    volume: int | None
    currency: str | None
    as_of: dt.datetime  # timezone-aware UTC timestamp of the quote
    is_delayed: bool  # True unless provider explicitly guarantees real-time
    source: str  # provider name, e.g. "yfinance"

    @property
    def change(self) -> float | None:
        if self.previous_close is None:
            return None
        return round(self.price - self.previous_close, 4)

    @property
    def change_pct(self) -> float | None:
        if self.previous_close in (None, 0):
            return None
        return round((self.price - self.previous_close) / self.previous_close * 100, 4)


@dataclass(frozen=True)
class CompanyInfo:
    """Descriptive/static company information. Unknown fields are None, never guessed."""

    symbol: str
    company_name: str | None
    exchange: str | None
    sector: str | None
    industry: str | None
    currency: str | None
    country: str | None
    market_cap: float | None
    description: str | None
    website: str | None
    employees: int | None
    as_of: dt.datetime
    source: str


@dataclass(frozen=True)
class FundamentalsSnapshot:
    """
    Point-in-time fundamental/financial-ratio data.

    Every field is Optional. If a provider cannot supply a metric, it MUST
    be None — analysis code is responsible for displaying "Insufficient
    data" rather than treating None as zero.
    """

    symbol: str
    as_of: dt.datetime
    source: str

    # Valuation
    pe_ratio: float | None = None
    forward_pe: float | None = None
    pb_ratio: float | None = None
    peg_ratio: float | None = None

    # Profitability
    eps: float | None = None
    eps_growth_yoy_pct: float | None = None
    revenue: float | None = None
    revenue_growth_yoy_pct: float | None = None
    net_margin_pct: float | None = None
    operating_margin_pct: float | None = None
    roe_pct: float | None = None
    roce_pct: float | None = None

    # Balance sheet / cash
    debt_to_equity: float | None = None
    free_cash_flow: float | None = None
    cash_position: float | None = None

    # Dividends
    dividend_yield_pct: float | None = None
    payout_ratio_pct: float | None = None

    # Earnings growth
    earnings_growth_pct: float | None = None

    def missing_fields(self) -> list[str]:
        """Return the names of fundamental fields that are unavailable (None)."""
        exclude = {"symbol", "as_of", "source"}
        return [k for k, v in self.__dict__.items() if k not in exclude and v is None]


@dataclass(frozen=True)
class NewsItem:
    """A single news article. Never fabricated — always sourced from a real provider response."""

    headline: str
    summary: str | None
    url: str
    source: str  # publisher, e.g. "Reuters"
    published_at: dt.datetime
    related_symbols: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class HistoryResult:
    """Historical OHLCV bars plus explicit metadata about freshness and gaps."""

    symbol: str
    interval: str  # e.g. "1d", "1h"
    data: pd.DataFrame  # columns: open, high, low, close, volume; DatetimeIndex (UTC)
    as_of: dt.datetime  # timestamp of the most recent bar
    is_delayed: bool
    source: str
    timezone: str  # exchange/market timezone the bars are aligned to


class MarketDataProvider(ABC):
    """
    Abstract interface every market-data provider must implement.

    Implementations must NOT:
    - fabricate values when the upstream API has none
    - silently return stale data without setting is_delayed / as_of correctly
    - swallow errors — raise DataProviderError / InvalidSymbolError / RateLimitError
    """

    name: str = "base"

    @abstractmethod
    def get_quote(self, symbol: str) -> Quote:
        """Return the latest available quote for a symbol."""

    @abstractmethod
    def get_history(
        self,
        symbol: str,
        period: str = "1y",
        interval: str = "1d",
    ) -> HistoryResult:
        """
        Return historical OHLCV data.

        Args:
            symbol: ticker symbol.
            period: lookback window, e.g. "1mo", "6mo", "1y", "5y", "max".
            interval: bar size, e.g. "1d", "1h", "15m".
        """

    @abstractmethod
    def get_company_info(self, symbol: str) -> CompanyInfo:
        """Return descriptive company information."""

    @abstractmethod
    def get_fundamentals(self, symbol: str) -> FundamentalsSnapshot:
        """Return fundamental/financial-ratio data. Missing metrics must be None."""

    @abstractmethod
    def get_news(self, symbol: str, limit: int = 20) -> list[NewsItem]:
        """Return recent news items related to a symbol. Never fabricated."""

    @abstractmethod
    def validate_symbol(self, symbol: str) -> bool:
        """Return True if the symbol appears to be valid/tradable, False otherwise."""
