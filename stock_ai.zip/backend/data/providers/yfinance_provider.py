"""
yfinance-based MarketDataProvider implementation.

yfinance pulls data from Yahoo Finance. It requires NO API key. Data is
free but is generally delayed (typically ~15 minutes for most exchanges,
sometimes more) — never real-time in the way a paid direct-exchange feed
would be. We are explicit about this everywhere (is_delayed=True always,
unless a future provider can prove otherwise).

This module cannot be executed inside the current development sandbox
(no internet access, yfinance not installed there) — see README known
limitations. It is written carefully against yfinance's documented API
(Ticker.info, Ticker.history, Ticker.news) and should be verified with
`pytest tests/test_market_data.py -v` after `pip install -r requirements.txt`
on a machine with internet access.
"""
from __future__ import annotations

import datetime as dt

import pandas as pd
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from backend.config import get_settings
from backend.data.base_provider import (
    CompanyInfo,
    FundamentalsSnapshot,
    HistoryResult,
    MarketDataProvider,
    NewsItem,
    Quote,
)
from backend.data.cache import shared_cache
from backend.exceptions import DataProviderError, InvalidSymbolError, RateLimitError
from backend.logging_config import get_logger

logger = get_logger(__name__)

_RETRYABLE_EXCEPTIONS = (ConnectionError, TimeoutError)


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _to_utc(timestamp: float | int | None) -> dt.datetime | None:
    """Convert a Unix timestamp (as returned by yfinance) to a UTC datetime."""
    if timestamp is None:
        return None
    try:
        return dt.datetime.fromtimestamp(float(timestamp), tz=dt.timezone.utc)
    except (ValueError, OSError, OverflowError):
        return None


class YFinanceProvider(MarketDataProvider):
    """
    Market data provider backed by Yahoo Finance via the `yfinance` package.

    Known characteristics to be transparent about:
    - No API key required.
    - Data is delayed, not real-time.
    - Occasionally returns incomplete `info` dicts for smaller/foreign
      tickers — every field we can't confirm is set to None, never guessed.
    - Yahoo Finance can rate-limit or block excessive requests; we cache
      aggressively and retry transient network errors with backoff.
    """

    name = "yfinance"

    def __init__(self) -> None:
        self._settings = get_settings()

    def _get_ticker(self, symbol: str):
        import yfinance as yf  # imported lazily so the rest of the app doesn't hard-require it

        return yf.Ticker(symbol)

    @retry(
        retry=retry_if_exception_type(_RETRYABLE_EXCEPTIONS),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        reraise=True,
    )
    def _fetch_history_raw(self, symbol: str, period: str, interval: str) -> pd.DataFrame:
        ticker = self._get_ticker(symbol)
        df = ticker.history(period=period, interval=interval, auto_adjust=False)
        return df

    def validate_symbol(self, symbol: str) -> bool:
        if not symbol or not symbol.strip():
            return False
        try:
            df = self._fetch_history_raw(symbol, period="5d", interval="1d")
            return df is not None and not df.empty
        except Exception as exc:  # yfinance raises various error types for bad symbols
            logger.warning("Symbol validation failed for %s: %s", symbol, exc)
            return False

    def get_quote(self, symbol: str) -> Quote:
        cache_key = f"quote:{symbol}"
        cached = shared_cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            df = self._fetch_history_raw(symbol, period="5d", interval="1d")
        except Exception as exc:
            raise DataProviderError(f"Failed to fetch quote for '{symbol}': {exc}") from exc

        if df is None or df.empty:
            raise InvalidSymbolError(f"No data available for symbol '{symbol}'. It may be invalid or delisted.")

        latest = df.iloc[-1]
        previous_close = float(df.iloc[-2]["Close"]) if len(df) >= 2 else None
        as_of = df.index[-1]
        if as_of.tzinfo is None:
            as_of = as_of.tz_localize("UTC")
        else:
            as_of = as_of.tz_convert("UTC")

        currency = None
        try:
            info = self._get_ticker(symbol).fast_info
            currency = getattr(info, "currency", None) or (info.get("currency") if isinstance(info, dict) else None)
        except Exception as exc:
            logger.debug("Could not fetch fast_info currency for %s: %s", symbol, exc)

        quote = Quote(
            symbol=symbol,
            price=float(latest["Close"]),
            previous_close=previous_close,
            open=float(latest["Open"]) if pd.notna(latest["Open"]) else None,
            day_high=float(latest["High"]) if pd.notna(latest["High"]) else None,
            day_low=float(latest["Low"]) if pd.notna(latest["Low"]) else None,
            volume=int(latest["Volume"]) if pd.notna(latest["Volume"]) else None,
            currency=currency,
            as_of=as_of.to_pydatetime(),
            is_delayed=True,  # yfinance/Yahoo Finance data is never guaranteed real-time
            source=self.name,
        )
        shared_cache.set(cache_key, quote, self._settings.cache_ttl_quote_seconds)
        return quote

    def get_history(self, symbol: str, period: str = "1y", interval: str = "1d") -> HistoryResult:
        cache_key = f"history:{symbol}:{period}:{interval}"
        cached = shared_cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            df = self._fetch_history_raw(symbol, period=period, interval=interval)
        except Exception as exc:
            raise DataProviderError(f"Failed to fetch history for '{symbol}': {exc}") from exc

        if df is None or df.empty:
            raise InvalidSymbolError(f"No historical data available for symbol '{symbol}'.")

        df = df.rename(
            columns={
                "Open": "open",
                "High": "high",
                "Low": "low",
                "Close": "close",
                "Volume": "volume",
            }
        )[["open", "high", "low", "close", "volume"]]

        # Drop duplicate index entries (can occur around DST transitions / provider quirks)
        df = df[~df.index.duplicated(keep="last")]

        if df.index.tzinfo is None:
            df.index = df.index.tz_localize("UTC")
        else:
            df.index = df.index.tz_convert("UTC")

        as_of = df.index[-1].to_pydatetime()

        result = HistoryResult(
            symbol=symbol,
            interval=interval,
            data=df,
            as_of=as_of,
            is_delayed=True,
            source=self.name,
            timezone=str(self._settings.market_timezone),
        )
        shared_cache.set(cache_key, result, self._settings.cache_ttl_history_seconds)
        return result

    def get_company_info(self, symbol: str) -> CompanyInfo:
        cache_key = f"company_info:{symbol}"
        cached = shared_cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            info = self._get_ticker(symbol).info
        except Exception as exc:
            raise DataProviderError(f"Failed to fetch company info for '{symbol}': {exc}") from exc

        if not info or info.get("regularMarketPrice") is None and info.get("previousClose") is None:
            # yfinance often returns a near-empty dict for invalid symbols rather than raising.
            logger.warning("Company info for '%s' looks empty/invalid.", symbol)

        result = CompanyInfo(
            symbol=symbol,
            company_name=info.get("longName") or info.get("shortName"),
            exchange=info.get("exchange"),
            sector=info.get("sector"),
            industry=info.get("industry"),
            currency=info.get("currency"),
            country=info.get("country"),
            market_cap=info.get("marketCap"),
            description=info.get("longBusinessSummary"),
            website=info.get("website"),
            employees=info.get("fullTimeEmployees"),
            as_of=_utcnow(),
            source=self.name,
        )
        shared_cache.set(cache_key, result, self._settings.cache_ttl_fundamentals_seconds)
        return result

    def get_fundamentals(self, symbol: str) -> FundamentalsSnapshot:
        cache_key = f"fundamentals:{symbol}"
        cached = shared_cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            info = self._get_ticker(symbol).info
        except Exception as exc:
            raise DataProviderError(f"Failed to fetch fundamentals for '{symbol}': {exc}") from exc

        def _pct(value: float | None) -> float | None:
            """yfinance often returns ratios as decimals (0.15); convert to percent."""
            if value is None:
                return None
            return round(value * 100, 4)

        result = FundamentalsSnapshot(
            symbol=symbol,
            as_of=_utcnow(),
            source=self.name,
            pe_ratio=info.get("trailingPE"),
            forward_pe=info.get("forwardPE"),
            pb_ratio=info.get("priceToBook"),
            peg_ratio=info.get("pegRatio"),
            eps=info.get("trailingEps"),
            eps_growth_yoy_pct=_pct(info.get("earningsQuarterlyGrowth")),
            revenue=info.get("totalRevenue"),
            revenue_growth_yoy_pct=_pct(info.get("revenueGrowth")),
            net_margin_pct=_pct(info.get("profitMargins")),
            operating_margin_pct=_pct(info.get("operatingMargins")),
            roe_pct=_pct(info.get("returnOnEquity")),
            roce_pct=None,  # not directly available from yfinance; left as Insufficient data
            debt_to_equity=info.get("debtToEquity"),
            free_cash_flow=info.get("freeCashflow"),
            cash_position=info.get("totalCash"),
            dividend_yield_pct=_pct(info.get("dividendYield")),
            payout_ratio_pct=_pct(info.get("payoutRatio")),
            earnings_growth_pct=_pct(info.get("earningsGrowth")),
        )
        shared_cache.set(cache_key, result, self._settings.cache_ttl_fundamentals_seconds)
        return result

    def get_news(self, symbol: str, limit: int = 20) -> list[NewsItem]:
        cache_key = f"news:{symbol}:{limit}"
        cached = shared_cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            raw_news = self._get_ticker(symbol).news or []
        except Exception as exc:
            logger.warning("Failed to fetch news for '%s': %s", symbol, exc)
            raw_news = []

        items: list[NewsItem] = []
        seen_urls: set[str] = set()
        for entry in raw_news[:limit]:
            # yfinance news items nest content under "content" in newer versions;
            # handle both shapes defensively without fabricating missing fields.
            content = entry.get("content", entry)
            url = (
                content.get("canonicalUrl", {}).get("url")
                if isinstance(content.get("canonicalUrl"), dict)
                else content.get("link") or content.get("url")
            )
            headline = content.get("title")
            if not url or not headline:
                continue  # skip malformed entries rather than fabricating fields
            if url in seen_urls:
                continue  # de-duplicate
            seen_urls.add(url)

            pub_date = content.get("pubDate") or content.get("providerPublishTime")
            published_at = None
            if isinstance(pub_date, str):
                try:
                    published_at = dt.datetime.fromisoformat(pub_date.replace("Z", "+00:00"))
                except ValueError:
                    published_at = None
            elif isinstance(pub_date, (int, float)):
                published_at = _to_utc(pub_date)

            if published_at is None:
                published_at = _utcnow()  # fallback only for sort-order purposes; not fabricated content

            provider = content.get("provider", {})
            source_name = provider.get("displayName") if isinstance(provider, dict) else content.get("publisher")

            items.append(
                NewsItem(
                    headline=headline,
                    summary=content.get("summary") or content.get("description"),
                    url=url,
                    source=source_name or "Unknown",
                    published_at=published_at,
                    related_symbols=[symbol],
                )
            )

        shared_cache.set(cache_key, items, self._settings.cache_ttl_news_seconds)
        return items
