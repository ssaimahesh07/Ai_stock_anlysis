"""
Mock MarketDataProvider for offline development, unit tests, and CI.

IMPORTANT: This provider generates deterministic synthetic data using a
seeded random walk. It is clearly labeled as synthetic everywhere
(`source="mock"`) and must NEVER be used to make real trading decisions.
Its only purposes are:
  1. Letting the app run and be demoed with zero network dependency.
  2. Providing deterministic, reproducible data for unit tests (indicators,
     scoring, backtesting) so tests don't depend on live market conditions.

The mock news provider returns an EMPTY list by default rather than
fabricated headlines — per spec Section 7 ("Do NOT fabricate news"). A
small opt-in fixture set is available for tests that specifically need to
exercise sentiment-classification logic; those items are unmistakably
labeled as synthetic in their headline/source text.
"""
from __future__ import annotations

import datetime as dt

import numpy as np
import pandas as pd

from backend.data.base_provider import (
    CompanyInfo,
    FundamentalsSnapshot,
    HistoryResult,
    MarketDataProvider,
    NewsItem,
    Quote,
)
from backend.exceptions import InvalidSymbolError

_INVALID_SYMBOLS = {"INVALID", "NOTREAL", "DOESNOTEXIST"}


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _seed_for_symbol(symbol: str) -> int:
    """Deterministic seed derived from the symbol so the same symbol always
    produces the same synthetic series (reproducible tests)."""
    return abs(hash(symbol.upper())) % (2**32)


class MockMarketDataProvider(MarketDataProvider):
    """Deterministic synthetic data provider. Never represents real markets."""

    name = "mock"

    def validate_symbol(self, symbol: str) -> bool:
        if not symbol or not symbol.strip():
            return False
        return symbol.upper() not in _INVALID_SYMBOLS

    def _synthetic_ohlcv(self, symbol: str, n_days: int) -> pd.DataFrame:
        rng = np.random.default_rng(_seed_for_symbol(symbol))
        base_price = 100 + (_seed_for_symbol(symbol) % 900)  # deterministic starting price 100-1000

        # Generate the date index FIRST, then size all arrays off its actual
        # length — pd.bdate_range(periods=n) is authoritative on row count,
        # so deriving arrays from len(dates) avoids any length mismatch.
        end = pd.Timestamp.now(tz="UTC").normalize()
        dates = pd.bdate_range(end=end, periods=n_days, tz="UTC")
        n = len(dates)

        daily_returns = rng.normal(loc=0.0004, scale=0.018, size=n)  # mild upward drift, realistic vol
        close = base_price * np.cumprod(1 + daily_returns)

        high = close * (1 + np.abs(rng.normal(0, 0.006, n)))
        low = close * (1 - np.abs(rng.normal(0, 0.006, n)))
        open_ = low + (high - low) * rng.uniform(0.2, 0.8, n)
        volume = rng.integers(500_000, 5_000_000, n)

        df = pd.DataFrame(
            {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
            index=dates,
        )
        return df

    def get_quote(self, symbol: str) -> Quote:
        if not self.validate_symbol(symbol):
            raise InvalidSymbolError(f"Symbol '{symbol}' is not recognized by the mock provider.")

        df = self._synthetic_ohlcv(symbol, n_days=5)
        latest = df.iloc[-1]
        previous_close = float(df.iloc[-2]["close"])

        return Quote(
            symbol=symbol,
            price=round(float(latest["close"]), 2),
            previous_close=round(previous_close, 2),
            open=round(float(latest["open"]), 2),
            day_high=round(float(latest["high"]), 2),
            day_low=round(float(latest["low"]), 2),
            volume=int(latest["volume"]),
            currency="USD",
            as_of=df.index[-1].to_pydatetime(),
            is_delayed=True,
            source=self.name,
        )

    def get_history(self, symbol: str, period: str = "1y", interval: str = "1d") -> HistoryResult:
        if not self.validate_symbol(symbol):
            raise InvalidSymbolError(f"Symbol '{symbol}' is not recognized by the mock provider.")

        period_to_days = {
            "1mo": 22, "3mo": 66, "6mo": 132, "1y": 252,
            "2y": 504, "5y": 1260, "max": 1260,
        }
        n_days = period_to_days.get(period, 252)
        df = self._synthetic_ohlcv(symbol, n_days=n_days)

        return HistoryResult(
            symbol=symbol,
            interval=interval,
            data=df,
            as_of=df.index[-1].to_pydatetime(),
            is_delayed=True,
            source=self.name,
            timezone="UTC",
        )

    def get_company_info(self, symbol: str) -> CompanyInfo:
        if not self.validate_symbol(symbol):
            raise InvalidSymbolError(f"Symbol '{symbol}' is not recognized by the mock provider.")

        return CompanyInfo(
            symbol=symbol,
            company_name=f"{symbol.upper()} Mock Corp (synthetic test data)",
            exchange="MOCK",
            sector="Technology",
            industry="Software",
            currency="USD",
            country="N/A",
            market_cap=None,  # deliberately unset to exercise "Insufficient data" paths
            description=None,
            website=None,
            employees=None,
            as_of=_utcnow(),
            source=self.name,
        )

    def get_fundamentals(self, symbol: str) -> FundamentalsSnapshot:
        if not self.validate_symbol(symbol):
            raise InvalidSymbolError(f"Symbol '{symbol}' is not recognized by the mock provider.")

        rng = np.random.default_rng(_seed_for_symbol(symbol))
        return FundamentalsSnapshot(
            symbol=symbol,
            as_of=_utcnow(),
            source=self.name,
            pe_ratio=round(float(rng.uniform(8, 40)), 2),
            forward_pe=round(float(rng.uniform(8, 35)), 2),
            pb_ratio=round(float(rng.uniform(0.5, 8)), 2),
            peg_ratio=round(float(rng.uniform(0.5, 3)), 2),
            eps=round(float(rng.uniform(1, 50)), 2),
            eps_growth_yoy_pct=round(float(rng.uniform(-15, 30)), 2),
            revenue=float(rng.uniform(1e8, 1e10)),
            revenue_growth_yoy_pct=round(float(rng.uniform(-10, 25)), 2),
            net_margin_pct=round(float(rng.uniform(2, 30)), 2),
            operating_margin_pct=round(float(rng.uniform(5, 35)), 2),
            roe_pct=round(float(rng.uniform(5, 35)), 2),
            roce_pct=round(float(rng.uniform(5, 30)), 2),
            debt_to_equity=round(float(rng.uniform(0, 150)), 2),
            free_cash_flow=float(rng.uniform(1e7, 1e9)),
            cash_position=float(rng.uniform(1e7, 5e9)),
            dividend_yield_pct=round(float(rng.uniform(0, 4)), 2),
            payout_ratio_pct=round(float(rng.uniform(0, 60)), 2),
            earnings_growth_pct=round(float(rng.uniform(-10, 30)), 2),
        )

    def get_news(self, symbol: str, limit: int = 20) -> list[NewsItem]:
        """
        Returns an empty list by default — the mock provider does NOT
        fabricate news headlines, per spec Section 7. Use
        `get_synthetic_test_news()` explicitly in tests that need sample
        news items to exercise sentiment-classification logic.
        """
        if not self.validate_symbol(symbol):
            raise InvalidSymbolError(f"Symbol '{symbol}' is not recognized by the mock provider.")
        return []

    def get_synthetic_test_news(self, symbol: str) -> list[NewsItem]:
        """
        Explicit, opt-in synthetic news fixture for unit tests only. Every
        headline is unmistakably labeled as synthetic test data.
        """
        now = _utcnow()
        return [
            NewsItem(
                headline=f"[SYNTHETIC TEST DATA] {symbol.upper()} reports quarterly results",
                summary="This is synthetic test data generated for unit testing, not real news.",
                url="https://example.invalid/synthetic-news-1",
                source="Synthetic Test Fixture",
                published_at=now - dt.timedelta(days=1),
                related_symbols=[symbol],
            ),
            NewsItem(
                headline=f"[SYNTHETIC TEST DATA] Analysts comment on {symbol.upper()} outlook",
                summary="This is synthetic test data generated for unit testing, not real news.",
                url="https://example.invalid/synthetic-news-2",
                source="Synthetic Test Fixture",
                published_at=now - dt.timedelta(days=3),
                related_symbols=[symbol],
            ),
        ]
