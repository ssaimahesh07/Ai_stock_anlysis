"""
Fundamentals access layer.

Thin wrapper around the configured MarketDataProvider that adds:
  - "Insufficient data" reporting (which fields are missing and why),
  - basic sanity bounds checking (flagging, never silently correcting,
    implausible values that likely indicate a provider data-quality issue).

Per spec Section 6: if data is unavailable, display "Insufficient data"
instead of inventing values. This module never invents values.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.data.base_provider import FundamentalsSnapshot
from backend.data.market_data import get_provider
from backend.logging_config import get_logger

logger = get_logger(__name__)

# Loose sanity bounds used only to flag suspicious values for review —
# never to clamp, correct, or replace the reported number.
_SANITY_BOUNDS: dict[str, tuple[float, float]] = {
    "pe_ratio": (-1000, 1000),
    "pb_ratio": (0, 200),
    "roe_pct": (-500, 500),
    "net_margin_pct": (-500, 100),
    "debt_to_equity": (0, 5000),
    "dividend_yield_pct": (0, 50),
}


@dataclass(frozen=True)
class FundamentalsReport:
    """Fundamentals snapshot plus data-quality metadata for display."""

    snapshot: FundamentalsSnapshot
    missing_fields: list[str]
    flagged_fields: list[str]  # fields present but outside sanity bounds

    @property
    def has_sufficient_data(self) -> bool:
        """
        True if enough core fields are present to compute a meaningful
        fundamental score. Threshold: fewer than half of tracked fields missing.
        """
        total_fields = len(self.snapshot.__dataclass_fields__) - 3  # exclude symbol/as_of/source
        return len(self.missing_fields) < (total_fields / 2)


def get_fundamentals_report(symbol: str) -> FundamentalsReport:
    """Fetch fundamentals and annotate with missing/flagged field info."""
    provider = get_provider()
    snapshot = provider.get_fundamentals(symbol)

    missing = snapshot.missing_fields()

    flagged: list[str] = []
    for field_name, (low, high) in _SANITY_BOUNDS.items():
        value = getattr(snapshot, field_name, None)
        if value is not None and not (low <= value <= high):
            flagged.append(field_name)
            logger.warning(
                "Fundamental field '%s' for %s is outside sanity bounds: %s "
                "(not corrected, only flagged for review)",
                field_name, symbol, value,
            )

    if missing:
        logger.info("Fundamentals for %s missing fields: %s", symbol, missing)

    return FundamentalsReport(snapshot=snapshot, missing_fields=missing, flagged_fields=flagged)
