"""
Market data provider factory and facade.

This is the ONLY module the rest of the application (analysis, ML,
backtesting, API) should import from to get market data. It:
  1. Selects the configured provider (yfinance / alpha_vantage / mock)
     based on Settings, so nothing else hardcodes a provider.
  2. Adds cross-cutting concerns common to all providers: staleness
     detection, invalid-symbol short-circuiting, structured logging.

To add a new provider (e.g. Alpha Vantage) later: implement
MarketDataProvider in backend/data/providers/, register it in
_PROVIDER_REGISTRY below, and no other code needs to change.
"""
from __future__ import annotations

import datetime as dt
from functools import lru_cache

from backend.config import get_settings
from backend.data.base_provider import HistoryResult, MarketDataProvider, Quote
from backend.exceptions import InvalidSymbolError
from backend.logging_config import get_logger

logger = get_logger(__name__)


def _build_yfinance_provider() -> MarketDataProvider:
    from backend.data.providers.yfinance_provider import YFinanceProvider

    return YFinanceProvider()


def _build_mock_provider() -> MarketDataProvider:
    from backend.data.providers.mock_provider import MockMarketDataProvider

    return MockMarketDataProvider()


_PROVIDER_REGISTRY = {
    "yfinance": _build_yfinance_provider,
    "mock": _build_mock_provider,
    # "alpha_vantage": _build_alpha_vantage_provider,  # add when implemented
}


@lru_cache
def get_provider() -> MarketDataProvider:
    """Return the configured market data provider (singleton, cached)."""
    settings = get_settings()
    provider_name = settings.market_data_provider

    builder = _PROVIDER_REGISTRY.get(provider_name)
    if builder is None:
        logger.error(
            "Configured MARKET_DATA_PROVIDER='%s' is not implemented. Falling back to mock.",
            provider_name,
        )
        builder = _build_mock_provider

    provider = builder()
    logger.info("Market data provider initialized: %s", provider.name)
    return provider


def is_stale(as_of: dt.datetime) -> bool:
    """
    True if `as_of` is older than the configured staleness threshold.

    Used to decide whether to show a "stale data" warning to the user in
    addition to the always-shown "delayed data" label (staleness is about
    *how old*; delayed is about *not real-time*, which is always true for
    free-tier providers).
    """
    settings = get_settings()
    now = dt.datetime.now(dt.timezone.utc)
    if as_of.tzinfo is None:
        as_of = as_of.replace(tzinfo=dt.timezone.utc)
    age = now - as_of
    return age > dt.timedelta(hours=settings.stale_data_threshold_hours)


def get_quote_with_freshness(symbol: str) -> tuple[Quote, bool]:
    """Convenience wrapper: returns (quote, is_stale)."""
    provider = get_provider()
    quote = provider.get_quote(symbol)
    return quote, is_stale(quote.as_of)


def get_history_with_freshness(
    symbol: str, period: str = "1y", interval: str = "1d"
) -> tuple[HistoryResult, bool]:
    """Convenience wrapper: returns (history, is_stale)."""
    provider = get_provider()
    history = provider.get_history(symbol, period=period, interval=interval)
    return history, is_stale(history.as_of)


def validate_symbol_or_raise(symbol: str) -> None:
    """Raise InvalidSymbolError with a clear message if the symbol is not usable."""
    provider = get_provider()
    if not provider.validate_symbol(symbol):
        raise InvalidSymbolError(
            f"'{symbol}' does not appear to be a valid or tradable symbol on "
            f"provider '{provider.name}'. Check the ticker format (e.g. "
            f"'RELIANCE.NS' for NSE, 'AAPL' for NASDAQ)."
        )
