"""
Lightweight in-process TTL cache.

Used by data providers to avoid re-fetching identical quotes/history/
fundamentals/news within a configurable time window (spec Section 35:
"Avoid repeatedly downloading identical historical data").

This is intentionally simple (dict + lock) rather than pulling in Redis —
sufficient for a single-process research tool. If the app is later scaled
to multiple worker processes, swap this for a shared cache (Redis) behind
the same `get`/`set` interface without touching provider code.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Callable, TypeVar

T = TypeVar("T")


class TTLCache:
    """Thread-safe cache where each entry expires after its own TTL."""

    def __init__(self) -> None:
        self._store: dict[str, tuple[float, Any]] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Any | None:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            expires_at, value = entry
            if time.monotonic() >= expires_at:
                del self._store[key]
                return None
            return value

    def set(self, key: str, value: Any, ttl_seconds: float) -> None:
        with self._lock:
            self._store[key] = (time.monotonic() + ttl_seconds, value)

    def get_or_set(self, key: str, ttl_seconds: float, factory: Callable[[], T]) -> T:
        """Return cached value if present and fresh; otherwise call factory(), cache, and return it."""
        cached = self.get(key)
        if cached is not None:
            return cached
        value = factory()
        self.set(key, value, ttl_seconds)
        return value

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._store.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    def size(self) -> int:
        with self._lock:
            return len(self._store)


# Module-level singleton shared by all providers in-process.
shared_cache = TTLCache()
