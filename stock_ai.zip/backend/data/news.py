"""
News access layer.

Thin wrapper around the configured MarketDataProvider's get_news(), adding:
  - deduplication (by URL and by near-identical headline),
  - chronological sorting (most recent first),
  - source/timestamp guarantees for display (spec Section 7).

Sentiment classification itself lives in backend/analysis/sentiment.py
(Phase 6) — this module is only responsible for retrieving and cleaning
raw news items, never for fabricating or inferring content.
"""
from __future__ import annotations

import difflib

from backend.data.base_provider import NewsItem
from backend.data.market_data import get_provider
from backend.logging_config import get_logger

logger = get_logger(__name__)

_HEADLINE_SIMILARITY_THRESHOLD = 0.9


def _dedupe_by_headline(items: list[NewsItem]) -> list[NewsItem]:
    """
    Remove near-duplicate headlines (e.g. the same wire story syndicated by
    multiple outlets with minor title differences). Keeps the first
    (most-recently-sorted) occurrence.
    """
    kept: list[NewsItem] = []
    seen_headlines: list[str] = []

    for item in items:
        normalized = item.headline.strip().lower()
        is_duplicate = any(
            difflib.SequenceMatcher(None, normalized, seen).ratio() >= _HEADLINE_SIMILARITY_THRESHOLD
            for seen in seen_headlines
        )
        if not is_duplicate:
            kept.append(item)
            seen_headlines.append(normalized)

    return kept


def get_recent_news(symbol: str, limit: int = 20) -> list[NewsItem]:
    """
    Fetch, deduplicate (by URL, then by near-identical headline), and
    chronologically sort recent news for a symbol.

    Returns an empty list if no news is available — never fabricates
    placeholder articles.
    """
    provider = get_provider()
    raw_items = provider.get_news(symbol, limit=limit * 2)  # over-fetch to allow for dedup loss

    # De-dupe by URL first (cheap, exact)
    seen_urls: set[str] = set()
    url_deduped: list[NewsItem] = []
    for item in raw_items:
        if item.url in seen_urls:
            continue
        seen_urls.add(item.url)
        url_deduped.append(item)

    # Sort newest first
    url_deduped.sort(key=lambda i: i.published_at, reverse=True)

    # De-dupe near-identical headlines (syndicated wire stories)
    deduped = _dedupe_by_headline(url_deduped)

    result = deduped[:limit]
    logger.info(
        "News for %s: %d raw -> %d after dedup (returning %d)",
        symbol, len(raw_items), len(deduped), len(result),
    )
    return result
