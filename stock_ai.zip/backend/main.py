"""
FastAPI application entrypoint.

Run with: uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000

This exposes a JSON API only — the frontend (Streamlit, or later React)
talks to this over HTTP. Keeping the backend UI-agnostic is deliberate
(spec Section 2): a mobile-friendly Streamlit UI ships first, and a React
UI could be swapped in later without any backend changes.
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.api import analysis, backtesting, health, portfolio, scanner, stocks
from backend.config import get_settings
from backend.database.database import init_db
from backend.logging_config import get_logger

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    logger.info("Starting %s (env=%s, provider=%s)", settings.app_name, settings.app_env, settings.market_data_provider)
    init_db()
    yield
    logger.info("Shutting down.")


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        description=(
            "A multi-factor stock research and paper-trading platform. "
            "Outputs are probabilistic research estimates, not guaranteed "
            "predictions or financial advice."
        ),
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router, prefix=settings.api_v1_prefix, tags=["health"])
    app.include_router(stocks.router, prefix=settings.api_v1_prefix, tags=["stocks"])
    app.include_router(analysis.router, prefix=settings.api_v1_prefix, tags=["analysis"])
    app.include_router(backtesting.router, prefix=settings.api_v1_prefix, tags=["backtesting"])
    app.include_router(portfolio.router, prefix=settings.api_v1_prefix, tags=["portfolio"])
    app.include_router(scanner.router, prefix=settings.api_v1_prefix, tags=["scanner"])

    return app


app = create_app()
