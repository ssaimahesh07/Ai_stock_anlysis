"""
Shared exception types used across the platform.

Using specific exception types (rather than bare Exception) lets API
handlers return correct HTTP status codes and lets calling code decide
whether a failure is retryable, a user error, or a data-quality problem.
"""
from __future__ import annotations


class StockAIError(Exception):
    """Base class for all application-specific errors."""


class DataProviderError(StockAIError):
    """Raised when a market-data/news/fundamentals provider call fails."""


class RateLimitError(DataProviderError):
    """Raised when an external provider rate limit is hit."""


class InvalidSymbolError(StockAIError):
    """Raised when a requested ticker symbol is invalid or unknown."""


class InsufficientDataError(StockAIError):
    """
    Raised when there is not enough reliable data to compute a result.

    Callers should surface this as "Insufficient data" to the user rather
    than falling back to fabricated or guessed values.
    """


class StaleDataError(StockAIError):
    """Raised/flagged when the freshest available data exceeds the staleness threshold."""


class ModelNotFoundError(StockAIError):
    """Raised when a requested ML model version does not exist in the registry."""


class ModelTrainingError(StockAIError):
    """Raised when ML model training fails or produces an invalid model."""


class BacktestConfigError(StockAIError):
    """Raised when a backtest is configured inconsistently (e.g. leakage risk)."""


class InsufficientFundsError(StockAIError):
    """Raised when a paper-trading order cannot be filled due to insufficient virtual cash."""


class InvalidOrderError(StockAIError):
    """Raised when a paper-trading order fails validation."""


class RiskLimitExceededError(StockAIError):
    """Raised when an order would violate configured risk limits."""


class DatabaseError(StockAIError):
    """Raised when a database operation fails unexpectedly."""
