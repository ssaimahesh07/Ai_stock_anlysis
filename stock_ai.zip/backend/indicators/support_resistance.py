"""Support/resistance detection: swing highs/lows, level clustering, breakout/breakdown detection."""
from __future__ import annotations

import numpy as np
import pandas as pd


def find_swing_points(df: pd.DataFrame, window: int = 5) -> dict:
    """
    A swing high/low is a local max/min within `window` bars on each side.
    Returns the index positions (not timestamps) of detected swing points.
    """
    high, low = df["high"], df["low"]
    n = len(df)
    swing_highs, swing_lows = [], []

    for i in range(window, n - window):
        window_high = high.iloc[i - window : i + window + 1]
        window_low = low.iloc[i - window : i + window + 1]
        if high.iloc[i] == window_high.max():
            swing_highs.append(i)
        if low.iloc[i] == window_low.min():
            swing_lows.append(i)

    return {"swing_high_idx": swing_highs, "swing_low_idx": swing_lows}


def cluster_levels(prices: list[float], tolerance_pct: float = 1.5) -> list[float]:
    """Group nearby price levels together and return cluster centers, strongest (most-touched) first."""
    if not prices:
        return []
    sorted_prices = sorted(prices)
    clusters: list[list[float]] = [[sorted_prices[0]]]

    for p in sorted_prices[1:]:
        if abs(p - clusters[-1][-1]) / clusters[-1][-1] * 100 <= tolerance_pct:
            clusters[-1].append(p)
        else:
            clusters.append([p])

    # Sort clusters by size (number of touches) descending, then return centers
    clusters.sort(key=len, reverse=True)
    return [round(float(np.mean(c)), 2) for c in clusters]


def support_resistance_snapshot(df: pd.DataFrame, window: int = 5, lookback: int = 120) -> dict:
    """
    Compute support/resistance levels from recent swing points, plus simple
    breakout/breakdown detection relative to the most recent significant
    swing high/low.
    """
    recent = df.tail(lookback) if len(df) > lookback else df
    swings = find_swing_points(recent, window=window)

    swing_high_prices = [recent["high"].iloc[i] for i in swings["swing_high_idx"]]
    swing_low_prices = [recent["low"].iloc[i] for i in swings["swing_low_idx"]]

    resistance_levels = cluster_levels(swing_high_prices)[:3]
    support_levels = cluster_levels(swing_low_prices)[:3]

    price = df["close"].iloc[-1]
    nearest_resistance = min((r for r in resistance_levels if r > price), default=None)
    nearest_support = max((s for s in support_levels if s < price), default=None)

    breakout = nearest_resistance is not None and price >= nearest_resistance
    breakdown = nearest_support is not None and price <= nearest_support

    return {
        "support_levels": sorted(support_levels),
        "resistance_levels": sorted(resistance_levels),
        "nearest_support": nearest_support,
        "nearest_resistance": nearest_resistance,
        "breakout_detected": breakout,
        "breakdown_detected": breakdown,
        "price": price,
    }
