"""Volatility indicators: ATR, Bollinger Bands, historical volatility."""
from __future__ import annotations

import numpy as np
import pandas as pd


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["high"], df["low"], df["close"]
    tr1 = high - low
    tr2 = (high - close.shift()).abs()
    tr3 = (low - close.shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()


def bollinger_bands(series: pd.Series, period: int = 20, num_std: float = 2.0) -> dict:
    mid = series.rolling(period, min_periods=period).mean()
    std = series.rolling(period, min_periods=period).std()
    upper = mid + num_std * std
    lower = mid - num_std * std
    bandwidth = (upper - lower) / mid.replace(0, np.nan)
    return {"bb_mid": mid, "bb_upper": upper, "bb_lower": lower, "bb_bandwidth": bandwidth}


def historical_volatility(series: pd.Series, period: int = 20, annualize: bool = True) -> pd.Series:
    """Annualized historical volatility (%) from log returns."""
    log_returns = np.log(series / series.shift(1))
    vol = log_returns.rolling(period, min_periods=period).std()
    if annualize:
        vol = vol * np.sqrt(252)
    return vol * 100


def volatility_snapshot(df: pd.DataFrame) -> dict:
    close = df["close"]
    atr_14 = atr(df, 14)
    bb = bollinger_bands(close, 20, 2.0)
    hv_20 = historical_volatility(close, 20)

    def last(s):
        return s.iloc[-1] if len(s) and not pd.isna(s.iloc[-1]) else None

    latest = {
        "atr_14": last(atr_14),
        "bb_upper": last(bb["bb_upper"]),
        "bb_mid": last(bb["bb_mid"]),
        "bb_lower": last(bb["bb_lower"]),
        "bb_bandwidth": last(bb["bb_bandwidth"]),
        "historical_volatility_20": last(hv_20),
    }

    price = close.iloc[-1]
    if latest["atr_14"] is not None and price:
        atr_pct = latest["atr_14"] / price * 100
        if atr_pct > 4:
            vol_label = "High"
        elif atr_pct > 2:
            vol_label = "Moderate"
        else:
            vol_label = "Low"
    else:
        vol_label = "Insufficient data"

    return {"series": {"atr_14": atr_14, **bb, "historical_volatility_20": hv_20}, "latest": latest, "volatility_label": vol_label}
