"""Momentum indicators: RSI, MACD, Stochastic RSI, ROC."""
from __future__ import annotations

import pandas as pd


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, 1e-12)
    return 100 - (100 / (1 + rs))


def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> dict:
    ema_fast = series.ewm(span=fast, adjust=False, min_periods=fast).mean()
    ema_slow = series.ewm(span=slow, adjust=False, min_periods=slow).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False, min_periods=signal).mean()
    hist = macd_line - signal_line
    return {"macd_line": macd_line, "signal_line": signal_line, "histogram": hist}


def stochastic_rsi(series: pd.Series, period: int = 14, smooth_k: int = 3, smooth_d: int = 3) -> dict:
    rsi_series = rsi(series, period)
    min_rsi = rsi_series.rolling(period).min()
    max_rsi = rsi_series.rolling(period).max()
    stoch = (rsi_series - min_rsi) / (max_rsi - min_rsi).replace(0, 1e-12) * 100
    k = stoch.rolling(smooth_k).mean()
    d = k.rolling(smooth_d).mean()
    return {"stoch_rsi_k": k, "stoch_rsi_d": d}


def roc(series: pd.Series, period: int = 10) -> pd.Series:
    """Rate of Change (%)."""
    return (series / series.shift(period) - 1) * 100


def momentum_snapshot(df: pd.DataFrame) -> dict:
    close = df["close"]
    rsi_14 = rsi(close, 14)
    macd_out = macd(close)
    stoch = stochastic_rsi(close)
    roc_10 = roc(close, 10)

    def last(s):
        return s.iloc[-1] if len(s) and not pd.isna(s.iloc[-1]) else None

    latest = {
        "rsi_14": last(rsi_14),
        "macd_line": last(macd_out["macd_line"]),
        "macd_signal": last(macd_out["signal_line"]),
        "macd_histogram": last(macd_out["histogram"]),
        "stoch_rsi_k": last(stoch["stoch_rsi_k"]),
        "stoch_rsi_d": last(stoch["stoch_rsi_d"]),
        "roc_10": last(roc_10),
    }

    if latest["rsi_14"] is not None:
        if latest["rsi_14"] >= 70:
            rsi_label = "Overbought"
        elif latest["rsi_14"] <= 30:
            rsi_label = "Oversold"
        else:
            rsi_label = "Neutral"
    else:
        rsi_label = "Insufficient data"

    return {
        "series": {"rsi_14": rsi_14, **macd_out, **stoch, "roc_10": roc_10},
        "latest": latest,
        "rsi_label": rsi_label,
    }
