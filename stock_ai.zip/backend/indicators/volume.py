"""Volume indicators: Volume SMA, volume ratio, OBV, VWAP."""
from __future__ import annotations

import numpy as np
import pandas as pd


def volume_sma(volume: pd.Series, period: int = 20) -> pd.Series:
    return volume.rolling(period, min_periods=period).mean()


def volume_ratio(volume: pd.Series, period: int = 20) -> pd.Series:
    """Current volume relative to its N-period average (1.0 = average)."""
    avg = volume_sma(volume, period)
    return volume / avg.replace(0, np.nan)


def obv(df: pd.DataFrame) -> pd.Series:
    """On-Balance Volume."""
    close = df["close"]
    volume = df["volume"]
    direction = np.sign(close.diff().fillna(0))
    return (direction * volume).cumsum()


def vwap(df: pd.DataFrame) -> pd.Series:
    """
    Rolling session-agnostic VWAP over the full provided window. For daily
    bars this approximates a cumulative VWAP; for intraday data with a
    proper session index it approximates the intraday VWAP.
    """
    typical_price = (df["high"] + df["low"] + df["close"]) / 3
    cum_vol = df["volume"].cumsum()
    cum_vol_price = (typical_price * df["volume"]).cumsum()
    return cum_vol_price / cum_vol.replace(0, np.nan)


def volume_snapshot(df: pd.DataFrame) -> dict:
    volume = df["volume"]
    vol_sma_20 = volume_sma(volume, 20)
    vol_ratio = volume_ratio(volume, 20)
    obv_series = obv(df)
    vwap_series = vwap(df)

    def last(s):
        return s.iloc[-1] if len(s) and not pd.isna(s.iloc[-1]) else None

    latest = {
        "volume": int(volume.iloc[-1]) if pd.notna(volume.iloc[-1]) else None,
        "volume_sma_20": last(vol_sma_20),
        "volume_ratio": last(vol_ratio),
        "obv": last(obv_series),
        "vwap": last(vwap_series),
    }

    if latest["volume_ratio"] is not None:
        if latest["volume_ratio"] >= 2.0:
            label = "Unusually high"
        elif latest["volume_ratio"] >= 1.3:
            label = "Above average"
        elif latest["volume_ratio"] <= 0.5:
            label = "Unusually low"
        else:
            label = "Average"
    else:
        label = "Insufficient data"

    return {
        "series": {"volume_sma_20": vol_sma_20, "volume_ratio": vol_ratio, "obv": obv_series, "vwap": vwap_series},
        "latest": latest,
        "volume_label": label,
    }
