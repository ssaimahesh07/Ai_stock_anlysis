"""Trend indicators: SMA, EMA, ADX. All operate on a pandas Series/DataFrame of OHLCV data."""
from __future__ import annotations

import numpy as np
import pandas as pd


def sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(window=period, min_periods=period).mean()


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False, min_periods=period).mean()


def adx(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Average Directional Index — trend strength (not direction)."""
    high, low, close = df["high"], df["low"], df["close"]
    up_move = high.diff()
    down_move = -low.diff()

    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    tr1 = high - low
    tr2 = (high - close.shift()).abs()
    tr3 = (low - close.shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    atr_ = tr.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    plus_di = 100 * pd.Series(plus_dm, index=df.index).ewm(alpha=1 / period, min_periods=period, adjust=False).mean() / atr_
    minus_di = 100 * pd.Series(minus_dm, index=df.index).ewm(alpha=1 / period, min_periods=period, adjust=False).mean() / atr_

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    return dx.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()


def trend_snapshot(df: pd.DataFrame) -> dict:
    """Compute all standard trend indicators and a simple trend label from the last row."""
    close = df["close"]
    out = {
        "sma_20": sma(close, 20),
        "sma_50": sma(close, 50),
        "sma_100": sma(close, 100),
        "sma_200": sma(close, 200),
        "ema_20": ema(close, 20),
        "ema_50": ema(close, 50),
        "ema_200": ema(close, 200),
        "adx_14": adx(df, 14),
    }
    latest = {k: (v.iloc[-1] if len(v) and not pd.isna(v.iloc[-1]) else None) for k, v in out.items()}
    price = close.iloc[-1]

    above_50 = latest["sma_50"] is not None and price > latest["sma_50"]
    above_200 = latest["sma_200"] is not None and price > latest["sma_200"]
    if above_50 and above_200:
        label = "Uptrend"
    elif not above_50 and not above_200:
        label = "Downtrend"
    else:
        label = "Mixed"

    return {"series": out, "latest": latest, "price": price, "trend_label": label}
