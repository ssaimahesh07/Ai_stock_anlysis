"""Stock data endpoints: quote, history, company info, fundamentals, news."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query

from backend.data.fundamentals import get_fundamentals_report
from backend.data.market_data import get_provider, get_quote_with_freshness, is_stale
from backend.data.news import get_recent_news
from backend.exceptions import DataProviderError, InvalidSymbolError
from backend.logging_config import get_logger

logger = get_logger(__name__)
router = APIRouter()


@router.get("/stocks/{symbol}/quote")
def get_quote(symbol: str) -> dict:
    try:
        quote, stale = get_quote_with_freshness(symbol)
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return {
        "symbol": quote.symbol, "price": quote.price, "previous_close": quote.previous_close,
        "change": quote.change, "change_pct": quote.change_pct,
        "open": quote.open, "day_high": quote.day_high, "day_low": quote.day_low,
        "volume": quote.volume, "currency": quote.currency,
        "as_of": quote.as_of.isoformat(), "is_delayed": True, "is_stale": stale,
        "source": quote.source,
    }


@router.get("/stocks/{symbol}/history")
def get_history(symbol: str, period: str = "1y", interval: str = "1d") -> dict:
    provider = get_provider()
    try:
        result = provider.get_history(symbol, period=period, interval=interval)
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    df = result.data.reset_index()
    df.columns = ["date", "open", "high", "low", "close", "volume"]
    bars = df.to_dict(orient="records")
    for bar in bars:
        bar["date"] = bar["date"].isoformat()

    return {
        "symbol": symbol, "interval": interval, "bars": bars,
        "as_of": result.as_of.isoformat(), "is_delayed": True,
        "is_stale": is_stale(result.as_of), "source": result.source,
    }


@router.get("/stocks/{symbol}/company")
def get_company_info(symbol: str) -> dict:
    provider = get_provider()
    try:
        info = provider.get_company_info(symbol)
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return {
        "symbol": info.symbol, "company_name": info.company_name, "exchange": info.exchange,
        "sector": info.sector, "industry": info.industry, "currency": info.currency,
        "country": info.country, "market_cap": info.market_cap,
        "as_of": info.as_of.isoformat(), "source": info.source,
    }


@router.get("/stocks/{symbol}/fundamentals")
def get_fundamentals(symbol: str) -> dict:
    try:
        report = get_fundamentals_report(symbol)
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    snap = report.snapshot
    return {
        "symbol": snap.symbol, "as_of": snap.as_of.isoformat(), "source": snap.source,
        "metrics": {k: v for k, v in snap.__dict__.items() if k not in ("symbol", "as_of", "source")},
        "missing_fields": report.missing_fields,
        "flagged_fields": report.flagged_fields,
        "has_sufficient_data": report.has_sufficient_data,
    }


@router.get("/stocks/{symbol}/news")
def get_news(symbol: str, limit: int = Query(default=20, le=100)) -> dict:
    items = get_recent_news(symbol, limit=limit)
    return {
        "symbol": symbol,
        "count": len(items),
        "items": [
            {
                "headline": i.headline, "summary": i.summary, "url": i.url,
                "source": i.source, "published_at": i.published_at.isoformat(),
            }
            for i in items
        ],
    }
