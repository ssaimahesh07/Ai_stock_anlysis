"""Scanner endpoint: rank a universe of symbols (spec Section 16)."""
from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter
from pydantic import BaseModel

from backend.analysis.scanner import scan_universe
from backend.constants import GENERAL_DISCLAIMER

router = APIRouter()


class ScanRequest(BaseModel):
    symbols: list[str]
    min_score: float | None = None


@router.post("/scanner/scan")
def run_scan(req: ScanRequest) -> dict:
    if len(req.symbols) > 50:
        return {"error": "Limit scans to 50 symbols at a time to keep response times reasonable."}

    result = scan_universe(req.symbols, min_score=req.min_score)
    return {
        "top_candidates": [asdict(r) for r in result["top_candidates"]],
        "worst_setups": [asdict(r) for r in result["worst_setups"]],
        "requiring_more_data": [asdict(r) for r in result["insufficient_data"]],
        "total_scanned": result["total_scanned"],
        "total_scored": result["total_scanned"] - len(result["insufficient_data"]),
        "disclaimer": GENERAL_DISCLAIMER,
    }
