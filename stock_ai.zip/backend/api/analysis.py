"""
Analysis endpoints: the full multi-factor research report per stock
(spec Section 39 — "RELIANCE" search example).
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from backend.analysis.entry_exit import build_entry_plan, check_exit_conditions
from backend.analysis.fundamental import compute_fundamental_score
from backend.analysis.multi_factor import SubScores, compute_research_score
from backend.analysis.sentiment import analyze_news_sentiment
from backend.analysis.technical import compute_technical_score
from backend.config import get_settings
from backend.constants import GENERAL_DISCLAIMER, RiskLevel
from backend.data.fundamentals import get_fundamentals_report
from backend.data.market_data import get_provider, is_stale
from backend.data.news import get_recent_news
from backend.exceptions import DataProviderError, InvalidSymbolError
from backend.logging_config import get_logger

logger = get_logger(__name__)
router = APIRouter()



def _determine_risk_level(technical_result: dict) -> RiskLevel:
    vol = technical_result.get("volatility") if technical_result else None
    if not vol:
        return RiskLevel.UNKNOWN
    label = vol.get("volatility_label")
    return {"High": RiskLevel.HIGH, "Moderate": RiskLevel.MEDIUM, "Low": RiskLevel.LOW}.get(label, RiskLevel.UNKNOWN)


def _generate_explanation(symbol: str, technical: dict, fundamental: dict, sentiment: dict, research_score) -> str:
    """Generate a plain-language explanation from ACTUAL computed data only (spec Section 18)."""
    parts = [f"Research Score for {symbol.upper()}: {research_score if research_score is not None else 'Insufficient data'}."]

    if technical.get("score") is not None:
        parts.append(f"Technical score is {technical['score']}/100.")
        if technical["reasons"]:
            parts.append(technical["reasons"][0])
    if fundamental.get("score") is not None:
        parts.append(f"Fundamental score is {fundamental['score']}/100.")
    if sentiment.get("overall_label"):
        parts.append(f"Recent news sentiment is broadly {sentiment['overall_label'].value.lower()}.")

    parts.append(GENERAL_DISCLAIMER)
    return " ".join(parts)


@router.get("/analysis/{symbol}")
def get_full_analysis(symbol: str) -> dict:
    settings = get_settings()
    provider = get_provider()

    try:
        history = provider.get_history(symbol, period="1y", interval="1d")
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    technical_result = compute_technical_score(history.data)

    try:
        fundamentals_report = get_fundamentals_report(symbol)
        fundamental_result = compute_fundamental_score(fundamentals_report.snapshot)
    except DataProviderError:
        fundamental_result = {"score": None, "reasons": ["Fundamentals provider unavailable."]}

    try:
        news_items = get_recent_news(symbol, limit=20)
    except DataProviderError:
        news_items = []
    sentiment_result = analyze_news_sentiment(news_items)

    momentum_score = technical_result.get("momentum", {}).get("latest", {}).get("rsi_14")
    momentum_sub = None
    if momentum_score is not None:
        # Simple momentum sub-score: distance from neutral 50, scaled to 0-100
        momentum_sub = max(0, min(100, 50 + (momentum_score - 50)))

    volume_ratio = technical_result.get("volume", {}).get("latest", {}).get("volume_ratio")
    volume_sub = min(100, volume_ratio * 50) if volume_ratio is not None else None

    sentiment_sub = None
    if sentiment_result.get("overall_label") is not None:
        label = sentiment_result["overall_label"]
        sentiment_sub = {"Positive": 75.0, "Neutral": 50.0, "Negative": 25.0}.get(label.value)

    sub_scores = SubScores(
        technical=technical_result.get("score"),
        fundamental=fundamental_result.get("score"),
        momentum=momentum_sub,
        volume=volume_sub,
        market_regime=None,  # requires benchmark index data; wired at scanner/portfolio level
        sector_strength=None,  # requires sector peer data; not available from base provider yet
        sentiment=sentiment_sub,
        risk_reward=None,  # computed below from hypothetical levels once available
    )

    hypothetical = build_entry_plan(technical_result, technical_result.get("score"))
    if hypothetical.risk_reward_ratio:
        rr = hypothetical.risk_reward_ratio
        sub_scores.risk_reward = max(0, min(100, rr * 25))  # RR of 4.0 -> 100

    scoring_result = compute_research_score(sub_scores, settings.scoring_weights.as_dict())
    research_score = scoring_result["research_score"]

    signal = hypothetical.signal
    risk_level = _determine_risk_level(technical_result)
    explanation = _generate_explanation(symbol, technical_result, fundamental_result, sentiment_result, research_score)

    return {
        "symbol": symbol.upper(),
        "data_as_of": history.as_of.isoformat(),
        "is_delayed_data": True,
        "is_stale_data": is_stale(history.as_of),
        "research_score": research_score,
        "scoring_weights_used": scoring_result["weights_used"],
        "available_factors": scoring_result["available_factors"],
        "missing_factors": scoring_result["missing_factors"],
        "research_signal": signal.value,
        "risk_level": risk_level.value,
        "technical_analysis": {
            "score": technical_result.get("score"),
            "reasons": technical_result.get("reasons"),
            "trend_label": technical_result.get("trend", {}).get("trend_label") if technical_result.get("trend") else None,
            "rsi_label": technical_result.get("momentum", {}).get("rsi_label") if technical_result.get("momentum") else None,
            "volatility_label": technical_result.get("volatility", {}).get("volatility_label") if technical_result.get("volatility") else None,
            "volume_label": technical_result.get("volume", {}).get("volume_label") if technical_result.get("volume") else None,
            "support_levels": technical_result.get("support_resistance", {}).get("support_levels") if technical_result.get("support_resistance") else None,
            "resistance_levels": technical_result.get("support_resistance", {}).get("resistance_levels") if technical_result.get("support_resistance") else None,
        },
        "fundamental_analysis": {
            "score": fundamental_result.get("score"),
            "reasons": fundamental_result.get("reasons"),
            "missing_fields": fundamental_result.get("missing_fields", []),
        },
        "news_sentiment": {
            "positive_count": sentiment_result.get("positive_count", 0),
            "neutral_count": sentiment_result.get("neutral_count", 0),
            "negative_count": sentiment_result.get("negative_count", 0),
            "overall_label": sentiment_result.get("overall_label").value if sentiment_result.get("overall_label") else None,
            "items": sentiment_result.get("items", [])[:10],
        },
        "hypothetical_research_setup": {
            "signal": hypothetical.signal.value,
            "available": hypothetical.entry_zone_low is not None,
            "entry_zone_low": hypothetical.entry_zone_low,
            "entry_zone_high": hypothetical.entry_zone_high,
            "invalidation_level": hypothetical.invalidation_level,
            "target_1": hypothetical.target_1,
            "target_2": hypothetical.target_2,
            "risk_reward_ratio": hypothetical.risk_reward_ratio,
            "conditions_met": hypothetical.conditions_met,
            "conditions_not_met": hypothetical.conditions_not_met,
            "warnings": hypothetical.warnings,
            "disclaimer": hypothetical.disclaimer,
        },
        "explanation": explanation,
        "disclaimer": GENERAL_DISCLAIMER,
    }


@router.get("/analysis/{symbol}/exit-check")
def check_exit(
    symbol: str,
    invalidation_level: float,
    target_1: float,
    target_2: float | None = None,
) -> dict:
    """
    Given a position's PREDEFINED levels (set when the trade was entered —
    pass in what your entry plan originally said, never re-derived after
    the fact), check whether current price has triggered an exit condition.
    This is the mechanical "when to exit" check: no discretion applied.
    """
    provider = get_provider()
    try:
        quote = provider.get_quote(symbol)
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    result = check_exit_conditions(quote.price, invalidation_level, target_1, target_2)

    return {
        "symbol": symbol.upper(),
        "current_price": result.current_price,
        "price_as_of": quote.as_of.isoformat(),
        "is_delayed_data": True,
        "action": result.action,
        "reason": result.reason,
        "distance_to_invalidation_pct": result.distance_to_invalidation_pct,
        "distance_to_target_1_pct": result.distance_to_target_1_pct,
        "disclaimer": (
            "This is a mechanical check against levels YOU defined at entry. "
            "It does not predict future price movement and is not financial advice."
        ),
    }
