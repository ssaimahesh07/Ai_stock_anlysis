"""Health check endpoint — used to verify the API and its dependencies are up."""
from __future__ import annotations

import datetime as dt

from fastapi import APIRouter

from backend.config import get_settings
from backend.constants import GENERAL_DISCLAIMER

router = APIRouter()


@router.get("/health")
def health_check() -> dict:
    settings = get_settings()
    return {
        "status": "ok",
        "app": settings.app_name,
        "environment": settings.app_env,
        "market_data_provider": settings.market_data_provider,
        "server_time_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "disclaimer": GENERAL_DISCLAIMER,
    }
