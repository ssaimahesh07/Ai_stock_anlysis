"""
Paper trading portfolio endpoints — now DATABASE-BACKED (spec Section 25),
so portfolios survive server restarts.

Authentication is not yet enforced (see README known limitations), so all
requests use a single default local user/portfolio. This keeps the schema
and API auth-ready for when accounts are added, without blocking paper
trading in the meantime.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.constants import GENERAL_DISCLAIMER
from backend.data.market_data import get_provider
from backend.database.database import get_db
from backend.database.models import PaperPosition, User
from backend.exceptions import DataProviderError, InsufficientFundsError, InvalidOrderError, InvalidSymbolError
from backend.paper_trading.portfolio import execute_buy, execute_sell, get_or_create_portfolio, snapshot_equity

router = APIRouter()

_LOCAL_USER_EMAIL = "local@stockai.local"


def _get_or_create_local_user(db: Session) -> User:
    user = db.query(User).filter_by(email=_LOCAL_USER_EMAIL).first()
    if user is None:
        user = User(email=_LOCAL_USER_EMAIL, hashed_password="local-mode-no-auth", display_name="Local User")
        db.add(user)
        db.commit()
        db.refresh(user)
    return user


class OrderRequest(BaseModel):
    symbol: str
    quantity: float


@router.get("/portfolio/default")
def get_portfolio(db: Session = Depends(get_db)) -> dict:
    user = _get_or_create_local_user(db)
    portfolio = get_or_create_portfolio(db, user.id)
    provider = get_provider()

    open_positions = db.query(PaperPosition).filter_by(portfolio_id=portfolio.id, is_open=True).all()
    prices: dict[str, float] = {}
    for pos in open_positions:
        try:
            prices[pos.symbol] = provider.get_quote(pos.symbol).price
        except (InvalidSymbolError, DataProviderError):
            prices[pos.symbol] = pos.average_entry_price

    positions_out = [
        {
            "symbol": pos.symbol, "quantity": pos.quantity, "average_entry_price": round(pos.average_entry_price, 2),
            "current_price": round(prices.get(pos.symbol, pos.average_entry_price), 2),
            "unrealized_pnl": round((prices.get(pos.symbol, pos.average_entry_price) - pos.average_entry_price) * pos.quantity, 2),
            "market_value": round(pos.quantity * prices.get(pos.symbol, pos.average_entry_price), 2),
        }
        for pos in open_positions
    ]

    positions_value = sum(p["market_value"] for p in positions_out)
    total_equity = portfolio.cash_balance + positions_value

    return {
        "portfolio_id": portfolio.id,
        "cash": round(portfolio.cash_balance, 2),
        "positions": positions_out,
        "total_position_value": round(positions_value, 2),
        "total_equity": round(total_equity, 2),
        "max_risk_per_trade_pct": portfolio.max_risk_per_trade_pct,
        "max_portfolio_exposure_pct": portfolio.max_portfolio_exposure_pct,
        "max_open_positions": portfolio.max_open_positions,
        "disclaimer": GENERAL_DISCLAIMER + " This is a simulated, database-persisted paper-trading portfolio; no real money or real broker is involved.",
    }


@router.post("/portfolio/buy")
def buy_order(req: OrderRequest, db: Session = Depends(get_db)) -> dict:
    user = _get_or_create_local_user(db)
    portfolio = get_or_create_portfolio(db, user.id)
    provider = get_provider()

    try:
        quote = provider.get_quote(req.symbol)
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    try:
        order = execute_buy(db, portfolio, req.symbol, req.quantity, quote.price)
    except (InsufficientFundsError, InvalidOrderError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "status": "filled", "order_id": order.id, "symbol": order.symbol, "side": order.side.value,
        "quantity": order.quantity, "fill_price": round(order.fill_price, 4),
        "transaction_cost": round(order.transaction_cost, 4),
        "filled_at": order.filled_at.isoformat() if order.filled_at else None,
    }


@router.post("/portfolio/sell")
def sell_order(req: OrderRequest, db: Session = Depends(get_db)) -> dict:
    user = _get_or_create_local_user(db)
    portfolio = get_or_create_portfolio(db, user.id)
    provider = get_provider()

    try:
        quote = provider.get_quote(req.symbol)
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    try:
        order = execute_sell(db, portfolio, req.symbol, req.quantity, quote.price)
    except InvalidOrderError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "status": "filled", "order_id": order.id, "symbol": order.symbol, "side": order.side.value,
        "quantity": order.quantity, "fill_price": round(order.fill_price, 4),
        "transaction_cost": round(order.transaction_cost, 4),
        "filled_at": order.filled_at.isoformat() if order.filled_at else None,
    }


@router.get("/portfolio/default/trades")
def get_trade_history(db: Session = Depends(get_db)) -> dict:
    from backend.database.models import PaperOrder

    user = _get_or_create_local_user(db)
    portfolio = get_or_create_portfolio(db, user.id)
    orders = (
        db.query(PaperOrder)
        .filter_by(portfolio_id=portfolio.id)
        .order_by(PaperOrder.created_at.desc())
        .limit(100)
        .all()
    )
    return {
        "portfolio_id": portfolio.id,
        "trades": [
            {
                "id": o.id, "symbol": o.symbol, "side": o.side.value, "status": o.status.value,
                "quantity": o.quantity, "fill_price": o.fill_price, "transaction_cost": o.transaction_cost,
                "rejection_reason": o.rejection_reason,
                "created_at": o.created_at.isoformat(),
                "filled_at": o.filled_at.isoformat() if o.filled_at else None,
            }
            for o in orders
        ],
    }


@router.post("/portfolio/default/snapshot")
def take_equity_snapshot(db: Session = Depends(get_db)) -> dict:
    """Record a manual equity snapshot now (for equity-curve history). Intended to be called periodically, e.g. daily via a scheduler."""
    user = _get_or_create_local_user(db)
    portfolio = get_or_create_portfolio(db, user.id)
    provider = get_provider()

    open_positions = db.query(PaperPosition).filter_by(portfolio_id=portfolio.id, is_open=True).all()
    prices = {}
    for pos in open_positions:
        try:
            prices[pos.symbol] = provider.get_quote(pos.symbol).price
        except (InvalidSymbolError, DataProviderError):
            prices[pos.symbol] = pos.average_entry_price

    snap = snapshot_equity(db, portfolio, prices)
    return {"as_of": snap.as_of.isoformat(), "total_equity": round(snap.total_equity, 2)}
