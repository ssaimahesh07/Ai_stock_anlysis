"""Backtesting endpoints."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.backtesting.engine import BacktestConfig, run_backtest
from backend.backtesting.metrics import compute_metrics
from backend.backtesting.strategies import STRATEGY_REGISTRY
from backend.constants import BACKTEST_DISCLAIMER
from backend.data.market_data import get_provider
from backend.exceptions import BacktestConfigError, DataProviderError, InvalidSymbolError

router = APIRouter()


class BacktestRequest(BaseModel):
    symbol: str
    strategy: str = "trend_following"
    period: str = "2y"
    initial_capital: float = 100_000.0
    position_size_pct: float = 95.0
    transaction_cost_bps: float = 5.0
    slippage_bps: float = 2.0
    stop_loss_pct: float | None = 8.0
    take_profit_pct: float | None = 20.0


@router.post("/backtesting/run")
def run_backtest_endpoint(req: BacktestRequest) -> dict:
    if req.strategy not in STRATEGY_REGISTRY:
        raise HTTPException(status_code=400, detail=f"Unknown strategy '{req.strategy}'. Available: {list(STRATEGY_REGISTRY.keys())}")

    provider = get_provider()
    try:
        history = provider.get_history(req.symbol, period=req.period, interval="1d")
    except InvalidSymbolError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except DataProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    signal_fn = STRATEGY_REGISTRY[req.strategy]
    signal = signal_fn(history.data)

    config = BacktestConfig(
        initial_capital=req.initial_capital,
        position_size_pct=req.position_size_pct,
        transaction_cost_bps=req.transaction_cost_bps,
        slippage_bps=req.slippage_bps,
        stop_loss_pct=req.stop_loss_pct,
        take_profit_pct=req.take_profit_pct,
    )

    try:
        result = run_backtest(history.data, signal, config)
    except BacktestConfigError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    metrics = compute_metrics(result["equity_curve"], result["trades"])

    equity_curve = [{"date": d.isoformat(), "equity": round(float(v), 2)} for d, v in result["equity_curve"].items()]

    return {
        "symbol": req.symbol.upper(),
        "strategy": req.strategy,
        "period": req.period,
        "metrics": metrics,
        "equity_curve": equity_curve,
        "trades": [
            {**t, "entry_date": t["entry_date"].isoformat() if t.get("entry_date") is not None else None,
             "exit_date": t["exit_date"].isoformat() if t.get("exit_date") is not None else None}
            for t in result["trades"]
        ],
        "exposure_pct": result["exposure_pct"],
        "disclaimer": BACKTEST_DISCLAIMER,
    }


@router.get("/backtesting/strategies")
def list_strategies() -> dict:
    return {"strategies": list(STRATEGY_REGISTRY.keys())}
