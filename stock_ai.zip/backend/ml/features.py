"""
ML feature engineering (spec Section 10).

CRITICAL — no look-ahead bias: every feature at row t uses ONLY data
available up to and including bar t. The target label is the only column
that looks forward, and it is clearly named with a `target_` prefix and
excluded from the feature list automatically.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from backend.indicators.momentum import macd, rsi, roc
from backend.indicators.trend import adx, ema, sma
from backend.indicators.volatility import atr, historical_volatility
from backend.indicators.volume import volume_ratio

FEATURE_COLUMNS = [
    "return_1d", "return_5d", "return_10d",
    "sma20_ratio", "sma50_ratio", "sma200_ratio",
    "rsi_14", "macd_hist", "roc_10",
    "atr_pct", "hist_vol_20",
    "volume_ratio_20",
    "adx_14",
]


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build a feature matrix from OHLCV data. Every value at row t is computed
    using only data up to and including t (rolling/EWM windows naturally
    respect this — none of these functions use .shift(-n) or future data).
    """
    close = df["close"]
    out = pd.DataFrame(index=df.index)

    out["return_1d"] = close.pct_change(1) * 100
    out["return_5d"] = close.pct_change(5) * 100
    out["return_10d"] = close.pct_change(10) * 100

    out["sma20_ratio"] = close / sma(close, 20) - 1
    out["sma50_ratio"] = close / sma(close, 50) - 1
    out["sma200_ratio"] = close / sma(close, 200) - 1

    out["rsi_14"] = rsi(close, 14)
    out["macd_hist"] = macd(close)["histogram"]
    out["roc_10"] = roc(close, 10)

    atr_14 = atr(df, 14)
    out["atr_pct"] = atr_14 / close * 100
    out["hist_vol_20"] = historical_volatility(close, 20)

    out["volume_ratio_20"] = volume_ratio(df["volume"], 20)
    out["adx_14"] = adx(df, 14)

    return out[FEATURE_COLUMNS]


def build_target(
    df: pd.DataFrame,
    horizon_days: int,
    threshold_pct: float,
) -> pd.Series:
    """
    Build the binary classification target: 1 if the forward `horizon_days`
    return exceeds `threshold_pct`, else 0.

    This DOES look forward (by design — it's the label being predicted),
    which is exactly why it must NEVER be used as an input feature, and why
    the last `horizon_days` rows will have NaN targets (unknowable at
    training time) and must be dropped before training.
    """
    close = df["close"]
    forward_return_pct = (close.shift(-horizon_days) / close - 1) * 100
    target = (forward_return_pct > threshold_pct).astype(float)
    # Rows where the forward window doesn't exist yet must be NaN, not 0/1
    target[close.shift(-horizon_days).isna()] = np.nan
    target.name = f"target_{horizon_days}d_{threshold_pct}pct"
    return target


def build_training_dataset(
    df: pd.DataFrame,
    horizon_days: int,
    threshold_pct: float,
) -> pd.DataFrame:
    """
    Combine features + target into one aligned, NaN-dropped dataset ready
    for training. Rows are dropped only for NaN reasons (warmup period at
    the start for rolling indicators, and the final `horizon_days` rows
    where the target is unknowable) — never dropped for any other reason
    that could introduce survivorship bias.
    """
    features = build_features(df)
    target = build_target(df, horizon_days, threshold_pct)
    combined = features.copy()
    combined["target"] = target
    combined = combined.dropna()
    return combined
