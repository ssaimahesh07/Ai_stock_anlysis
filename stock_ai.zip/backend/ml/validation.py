"""
Walk-forward validation utilities (spec Sections 11 & 13).

Never uses random train/test splits for time-series data. Always splits
chronologically: train on an earlier block, validate/test on later,
non-overlapping blocks.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass
class WalkForwardSplit:
    train: pd.DataFrame
    validation: pd.DataFrame
    test: pd.DataFrame
    train_range: tuple
    validation_range: tuple
    test_range: tuple


def chronological_walk_forward_split(
    dataset: pd.DataFrame,
    train_years: float = 3,
    validation_years: float = 1,
    test_years: float = 1,
) -> WalkForwardSplit:
    """
    Split a chronologically-indexed dataset into train/validation/test
    blocks using ONLY time order — never shuffled, never random.

    The most recent `test_years` become the test set (out-of-sample),
    preceded by `validation_years` (validation), preceded by `train_years`
    (in-sample training data). If there isn't enough history for all three
    windows, uses whatever proportionally fits and shrinks train first.
    """
    if not isinstance(dataset.index, pd.DatetimeIndex):
        raise ValueError("Dataset must have a DatetimeIndex for chronological splitting.")

    dataset = dataset.sort_index()
    end = dataset.index.max()

    test_start = end - pd.DateOffset(years=test_years)
    validation_start = test_start - pd.DateOffset(years=validation_years)
    train_start = validation_start - pd.DateOffset(years=train_years)

    train = dataset[(dataset.index >= train_start) & (dataset.index < validation_start)]
    validation = dataset[(dataset.index >= validation_start) & (dataset.index < test_start)]
    test = dataset[dataset.index >= test_start]

    return WalkForwardSplit(
        train=train,
        validation=validation,
        test=test,
        train_range=(train.index.min() if len(train) else None, train.index.max() if len(train) else None),
        validation_range=(validation.index.min() if len(validation) else None, validation.index.max() if len(validation) else None),
        test_range=(test.index.min() if len(test) else None, test.index.max() if len(test) else None),
    )


def assert_no_temporal_overlap(split: WalkForwardSplit) -> None:
    """Defensive check: raises AssertionError if any split windows overlap in time."""
    if len(split.train) and len(split.validation):
        assert split.train.index.max() < split.validation.index.min(), "Train/validation overlap detected!"
    if len(split.validation) and len(split.test):
        assert split.validation.index.max() < split.test.index.min(), "Validation/test overlap detected!"
