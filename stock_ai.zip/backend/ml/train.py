"""
Model training pipeline (spec Sections 10, 11, 30).

Trains a classifier on the chronological train split, evaluates on
validation, and reports final metrics on the held-out test split only
(never optimized against). Uses scikit-learn; XGBoost used if available.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from backend.ml.features import FEATURE_COLUMNS, build_training_dataset
from backend.ml.validation import assert_no_temporal_overlap, chronological_walk_forward_split


@dataclass
class TrainedModelResult:
    model: object
    algorithm: str
    features: list[str]
    train_range: tuple
    validation_range: tuple
    test_range: tuple
    validation_metrics: dict
    test_metrics: dict
    calibration_notes: str
    n_train: int
    n_validation: int
    n_test: int
    trained_at: dt.datetime = field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))


def _build_model(algorithm: str):
    if algorithm == "logistic_regression":
        return LogisticRegression(max_iter=1000, class_weight="balanced")
    if algorithm == "random_forest":
        return RandomForestClassifier(
            n_estimators=200, max_depth=6, min_samples_leaf=20,
            class_weight="balanced", random_state=42,
        )
    if algorithm == "xgboost":
        try:
            from xgboost import XGBClassifier
        except ImportError as exc:
            raise ImportError(
                "xgboost is not installed. Install it (`pip install xgboost`) "
                "or choose algorithm='random_forest' / 'logistic_regression'."
            ) from exc
        return XGBClassifier(
            n_estimators=200, max_depth=4, learning_rate=0.05,
            eval_metric="logloss", random_state=42,
        )
    raise ValueError(f"Unknown algorithm '{algorithm}'. Choose logistic_regression, random_forest, or xgboost.")


def _evaluate(model, X: pd.DataFrame, y: pd.Series) -> dict:
    if len(X) == 0 or y.nunique() < 2:
        return {
            "accuracy": None, "precision": None, "recall": None,
            "f1": None, "roc_auc": None,
            "note": "Insufficient samples or single-class labels to compute metrics.",
        }
    preds = model.predict(X)
    proba = model.predict_proba(X)[:, 1]
    return {
        "accuracy": round(float(accuracy_score(y, preds)), 4),
        "precision": round(float(precision_score(y, preds, zero_division=0)), 4),
        "recall": round(float(recall_score(y, preds, zero_division=0)), 4),
        "f1": round(float(f1_score(y, preds, zero_division=0)), 4),
        "roc_auc": round(float(roc_auc_score(y, proba)), 4) if y.nunique() == 2 else None,
    }


def train_model(
    df: pd.DataFrame,
    horizon_days: int,
    threshold_pct: float,
    algorithm: str = "random_forest",
    train_years: float = 3,
    validation_years: float = 1,
    test_years: float = 1,
) -> TrainedModelResult:
    """
    Full training pipeline: build features/target -> chronological
    walk-forward split -> fit on train -> evaluate on validation -> report
    final metrics on held-out test (never touched during fitting/tuning).
    """
    dataset = build_training_dataset(df, horizon_days, threshold_pct)
    split = chronological_walk_forward_split(dataset, train_years, validation_years, test_years)
    assert_no_temporal_overlap(split)

    if len(split.train) < 50:
        raise ValueError(
            f"Insufficient training samples ({len(split.train)}) after chronological "
            f"split and NaN-dropping. Provide more historical data or reduce train_years."
        )

    X_train, y_train = split.train[FEATURE_COLUMNS], split.train["target"]
    X_val, y_val = split.validation[FEATURE_COLUMNS], split.validation["target"]
    X_test, y_test = split.test[FEATURE_COLUMNS], split.test["target"]

    model = _build_model(algorithm)
    model.fit(X_train, y_train)

    validation_metrics = _evaluate(model, X_val, y_val)
    test_metrics = _evaluate(model, X_test, y_test)  # reported only, never used to re-tune

    # Simple calibration note: compare predicted-probability mean vs actual positive rate on test
    calibration_notes = "Insufficient test data for calibration assessment."
    if len(X_test) > 0 and y_test.nunique() == 2:
        mean_pred_proba = float(model.predict_proba(X_test)[:, 1].mean())
        actual_positive_rate = float(y_test.mean())
        calibration_notes = (
            f"Mean predicted probability: {mean_pred_proba:.3f} vs actual positive rate: "
            f"{actual_positive_rate:.3f} on held-out test set."
        )

    return TrainedModelResult(
        model=model,
        algorithm=algorithm,
        features=FEATURE_COLUMNS,
        train_range=split.train_range,
        validation_range=split.validation_range,
        test_range=split.test_range,
        validation_metrics=validation_metrics,
        test_metrics=test_metrics,
        calibration_notes=calibration_notes,
        n_train=len(X_train),
        n_validation=len(X_val),
        n_test=len(X_test),
    )
