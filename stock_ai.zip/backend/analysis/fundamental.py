"""
Fundamental analysis scoring.

Converts a FundamentalsSnapshot into a 0-100 score plus explanation.
CRITICAL: if too many core fields are missing, returns score=None and
"Insufficient data" rather than guessing — per spec Section 6.
"""
from __future__ import annotations

from backend.data.base_provider import FundamentalsSnapshot


def compute_fundamental_score(snapshot: FundamentalsSnapshot) -> dict:
    missing = snapshot.missing_fields()
    core_fields = ["pe_ratio", "roe_pct", "net_margin_pct", "revenue_growth_yoy_pct", "debt_to_equity"]
    missing_core = [f for f in core_fields if getattr(snapshot, f) is None]

    if len(missing_core) >= 3:
        return {
            "score": None,
            "reasons": ["Insufficient fundamental data available to compute a reliable score."],
            "missing_fields": missing,
        }

    score = 50.0  # neutral baseline; adjusted by available signals only
    reasons: list[str] = []

    if snapshot.roe_pct is not None:
        if snapshot.roe_pct >= 18:
            score += 10
            reasons.append(f"Strong return on equity ({snapshot.roe_pct:.1f}%).")
        elif snapshot.roe_pct < 8:
            score -= 8
            reasons.append(f"Weak return on equity ({snapshot.roe_pct:.1f}%).")

    if snapshot.net_margin_pct is not None:
        if snapshot.net_margin_pct >= 15:
            score += 8
            reasons.append(f"Healthy net margin ({snapshot.net_margin_pct:.1f}%).")
        elif snapshot.net_margin_pct < 5:
            score -= 8
            reasons.append(f"Thin net margin ({snapshot.net_margin_pct:.1f}%).")

    if snapshot.revenue_growth_yoy_pct is not None:
        if snapshot.revenue_growth_yoy_pct >= 12:
            score += 10
            reasons.append(f"Strong revenue growth ({snapshot.revenue_growth_yoy_pct:.1f}% YoY).")
        elif snapshot.revenue_growth_yoy_pct < 0:
            score -= 10
            reasons.append(f"Revenue declined YoY ({snapshot.revenue_growth_yoy_pct:.1f}%).")

    if snapshot.debt_to_equity is not None:
        if snapshot.debt_to_equity > 150:
            score -= 10
            reasons.append(f"High debt-to-equity ({snapshot.debt_to_equity:.0f}) increases financial risk.")
        elif snapshot.debt_to_equity < 50:
            score += 5
            reasons.append(f"Conservative debt-to-equity ({snapshot.debt_to_equity:.0f}).")

    if snapshot.pe_ratio is not None:
        if 0 < snapshot.pe_ratio <= 20:
            score += 5
            reasons.append(f"P/E ({snapshot.pe_ratio:.1f}) is at a reasonable valuation level.")
        elif snapshot.pe_ratio > 45:
            score -= 5
            reasons.append(f"P/E ({snapshot.pe_ratio:.1f}) reflects a rich valuation.")

    score = max(0.0, min(100.0, score))

    if missing:
        reasons.append(f"Note: {len(missing)} fundamental field(s) unavailable ({', '.join(missing[:5])}{'...' if len(missing) > 5 else ''}).")

    return {"score": round(score, 1), "reasons": reasons, "missing_fields": missing}
