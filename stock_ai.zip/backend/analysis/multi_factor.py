"""
Multi-factor Research Score combiner (spec Section 9).

Combines independently-computed sub-scores (technical, fundamental,
momentum, volume, market regime, sector strength, sentiment, risk/reward)
into a single weighted "Research Score" (0-100). Weights are fully
configurable (backend/config.py ScoringWeights) and shown alongside the
result so the calculation is never a black box.

If a sub-score is unavailable (None, "Insufficient data"), its weight is
proportionally redistributed among the available sub-scores rather than
silently treating missing data as zero (which would unfairly punish a
stock just because one data source was down).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SubScores:
    technical: float | None = None
    fundamental: float | None = None
    momentum: float | None = None
    volume: float | None = None
    market_regime: float | None = None
    sector_strength: float | None = None
    sentiment: float | None = None
    risk_reward: float | None = None

    def as_dict(self) -> dict[str, float | None]:
        return {
            "technical": self.technical,
            "fundamental": self.fundamental,
            "momentum": self.momentum,
            "volume": self.volume,
            "market_regime": self.market_regime,
            "sector_strength": self.sector_strength,
            "sentiment": self.sentiment,
            "risk_reward": self.risk_reward,
        }


def compute_research_score(sub_scores: SubScores, weights: dict[str, float]) -> dict:
    """
    Compute the weighted Research Score, redistributing weight away from
    any sub-score that is None (missing/insufficient data).

    Returns dict with: research_score (0-100 or None if nothing available),
    weights_used (the redistributed weights actually applied),
    available_factors, missing_factors.
    """
    scores = sub_scores.as_dict()
    available = {k: v for k, v in scores.items() if v is not None}
    missing = [k for k, v in scores.items() if v is None]

    if not available:
        return {
            "research_score": None,
            "weights_used": {},
            "available_factors": [],
            "missing_factors": missing,
            "note": "No factors had sufficient data to compute a Research Score.",
        }

    available_weight_total = sum(weights[k] for k in available)
    if available_weight_total <= 0:
        return {
            "research_score": None,
            "weights_used": {},
            "available_factors": list(available.keys()),
            "missing_factors": missing,
            "note": "Available factors have zero combined weight.",
        }

    # Redistribute proportionally so weights among available factors still sum to 1.0
    weights_used = {k: round(weights[k] / available_weight_total, 6) for k in available}

    research_score = sum(available[k] * weights_used[k] for k in available)
    research_score = max(0.0, min(100.0, research_score))

    return {
        "research_score": round(research_score, 1),
        "weights_used": weights_used,
        "available_factors": list(available.keys()),
        "missing_factors": missing,
    }
