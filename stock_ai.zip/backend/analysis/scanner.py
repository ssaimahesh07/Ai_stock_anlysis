"""
Stock scanner (spec Section 16): ranks a universe of symbols by Research
Score, with filters. Reuses the same analysis pipeline as the single-stock
endpoint so scanner results are always consistent with the detail page.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.analysis.entry_exit import build_entry_plan
from backend.analysis.fundamental import compute_fundamental_score
from backend.analysis.multi_factor import SubScores, compute_research_score
from backend.analysis.sentiment import analyze_news_sentiment
from backend.analysis.technical import compute_technical_score
from backend.config import get_settings
from backend.data.fundamentals import get_fundamentals_report
from backend.data.market_data import get_provider
from backend.data.news import get_recent_news
from backend.exceptions import DataProviderError, InvalidSymbolError
from backend.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class ScanResult:
    symbol: str
    research_score: float | None
    signal: str
    trend_label: str | None
    risk_reward_ratio: float | None
    error: str | None = None


def _analyze_one(symbol: str) -> ScanResult:
    settings = get_settings()
    provider = get_provider()

    try:
        history = provider.get_history(symbol, period="1y", interval="1d")
    except InvalidSymbolError:
        return ScanResult(symbol=symbol, research_score=None, signal="INSUFFICIENT DATA", trend_label=None, risk_reward_ratio=None, error="Invalid symbol")
    except DataProviderError as exc:
        return ScanResult(symbol=symbol, research_score=None, signal="INSUFFICIENT DATA", trend_label=None, risk_reward_ratio=None, error=str(exc))

    technical_result = compute_technical_score(history.data)

    try:
        fundamentals_report = get_fundamentals_report(symbol)
        fundamental_result = compute_fundamental_score(fundamentals_report.snapshot)
    except DataProviderError:
        fundamental_result = {"score": None}

    try:
        news_items = get_recent_news(symbol, limit=10)
    except DataProviderError:
        news_items = []
    sentiment_result = analyze_news_sentiment(news_items)

    momentum_score = technical_result.get("momentum", {}).get("latest", {}).get("rsi_14")
    momentum_sub = max(0, min(100, 50 + (momentum_score - 50))) if momentum_score is not None else None

    volume_ratio = technical_result.get("volume", {}).get("latest", {}).get("volume_ratio")
    volume_sub = min(100, volume_ratio * 50) if volume_ratio is not None else None

    sentiment_sub = None
    if sentiment_result.get("overall_label") is not None:
        sentiment_sub = {"Positive": 75.0, "Neutral": 50.0, "Negative": 25.0}.get(sentiment_result["overall_label"].value)

    plan = build_entry_plan(technical_result, technical_result.get("score"))

    sub_scores = SubScores(
        technical=technical_result.get("score"),
        fundamental=fundamental_result.get("score"),
        momentum=momentum_sub,
        volume=volume_sub,
        sentiment=sentiment_sub,
        risk_reward=max(0, min(100, plan.risk_reward_ratio * 25)) if plan.risk_reward_ratio else None,
    )
    scoring_result = compute_research_score(sub_scores, settings.scoring_weights.as_dict())

    return ScanResult(
        symbol=symbol.upper(),
        research_score=scoring_result["research_score"],
        signal=plan.signal.value,
        trend_label=technical_result.get("trend", {}).get("trend_label") if technical_result.get("trend") else None,
        risk_reward_ratio=plan.risk_reward_ratio,
    )


def scan_universe(symbols: list[str], min_score: float | None = None) -> dict:
    """
    Analyze each symbol independently — one failing symbol never aborts the
    scan (spec Section 27: "never crash because one stock failed").
    Returns ranked results plus symbols that couldn't be scored.
    """
    results: list[ScanResult] = []
    for sym in symbols:
        try:
            results.append(_analyze_one(sym))
        except Exception as exc:  # defensive: absolutely never let one symbol kill the scan
            logger.exception("Unexpected error scanning %s", sym)
            results.append(ScanResult(symbol=sym, research_score=None, signal="INSUFFICIENT DATA", trend_label=None, risk_reward_ratio=None, error=str(exc)))

    scored = [r for r in results if r.research_score is not None]
    unscored = [r for r in results if r.research_score is None]

    if min_score is not None:
        scored = [r for r in scored if r.research_score >= min_score]

    scored.sort(key=lambda r: r.research_score, reverse=True)

    return {
        "top_candidates": scored[:10],
        "worst_setups": sorted(scored, key=lambda r: r.research_score)[:5] if scored else [],
        "insufficient_data": unscored,
        "total_scanned": len(symbols),
    }
