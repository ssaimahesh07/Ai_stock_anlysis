"""
News sentiment classification (spec Section 7).

Uses a transparent lexicon-based classifier (no external ML dependency
needed, deterministic, explainable) rather than a black-box model. This is
intentionally simple: it classifies sentiment of REAL, already-fetched news
items — it never invents or fetches news itself (see backend/data/news.py).

For a production upgrade, this classifier could be swapped for a proper
NLP/FinBERT-style model behind the same function signature.
"""
from __future__ import annotations

import re

from backend.constants import SentimentLabel
from backend.data.base_provider import NewsItem

_POSITIVE_WORDS = {
    "beat", "beats", "surge", "surged", "rally", "growth", "profit", "profits",
    "upgrade", "upgraded", "outperform", "record", "strong", "gain", "gains",
    "expansion", "contract", "contracts", "partnership", "approval", "approved",
    "bullish", "buyback", "dividend", "raised", "raises", "exceeds", "exceeded",
}
_NEGATIVE_WORDS = {
    "miss", "missed", "plunge", "plunged", "decline", "declined", "loss", "losses",
    "downgrade", "downgraded", "underperform", "weak", "fall", "falls", "fell",
    "lawsuit", "lawsuits", "investigation", "fraud", "recall", "layoffs", "layoff",
    "bearish", "cut", "cuts", "warning", "delay", "delayed", "resign", "resigned",
    "regulatory action", "fine", "penalty", "default",
}

# Event-type keyword patterns
_EVENT_PATTERNS = {
    "earnings": re.compile(r"\bearnings?\b|\bquarterly results?\b|\bq[1-4]\b", re.I),
    "regulatory": re.compile(r"\bregulat|\bSEC\b|\bcompliance\b|\bfine[d]?\b", re.I),
    "management_change": re.compile(r"\bCEO\b|\bCFO\b|\bresign|\bappoint(s|ed)?\b|\bsteps down\b", re.I),
    "contract": re.compile(r"\bcontract\b|\bdeal\b|\border\b|\bpartnership\b", re.I),
    "lawsuit": re.compile(r"\blawsuit\b|\bsues?\b|\blitigation\b", re.I),
}


def classify_sentiment(text: str) -> SentimentLabel:
    """Simple lexicon-based sentiment classification of a single text snippet."""
    words = set(re.findall(r"[a-zA-Z']+", text.lower()))
    pos_hits = len(words & _POSITIVE_WORDS)
    neg_hits = len(words & _NEGATIVE_WORDS)

    if pos_hits > neg_hits:
        return SentimentLabel.POSITIVE
    if neg_hits > pos_hits:
        return SentimentLabel.NEGATIVE
    return SentimentLabel.NEUTRAL


def detect_events(text: str) -> list[str]:
    return [event for event, pattern in _EVENT_PATTERNS.items() if pattern.search(text)]


def analyze_news_sentiment(items: list[NewsItem]) -> dict:
    """
    Classify a list of (already deduplicated) news items.

    Returns counts by label, per-item classifications, and detected event
    types. Never fabricates sentiment for items with no text.
    """
    if not items:
        return {
            "positive_count": 0, "neutral_count": 0, "negative_count": 0,
            "items": [], "overall_label": None,
            "note": "No recent news available for this symbol.",
        }

    classified = []
    counts = {SentimentLabel.POSITIVE: 0, SentimentLabel.NEUTRAL: 0, SentimentLabel.NEGATIVE: 0}

    for item in items:
        text = f"{item.headline} {item.summary or ''}"
        label = classify_sentiment(text)
        events = detect_events(text)
        counts[label] += 1
        classified.append({
            "headline": item.headline,
            "source": item.source,
            "url": item.url,
            "published_at": item.published_at,
            "sentiment": label,
            "events": events,
        })

    total = len(items)
    if counts[SentimentLabel.POSITIVE] > counts[SentimentLabel.NEGATIVE] and counts[SentimentLabel.POSITIVE] / total > 0.4:
        overall = SentimentLabel.POSITIVE
    elif counts[SentimentLabel.NEGATIVE] > counts[SentimentLabel.POSITIVE] and counts[SentimentLabel.NEGATIVE] / total > 0.4:
        overall = SentimentLabel.NEGATIVE
    else:
        overall = SentimentLabel.NEUTRAL

    return {
        "positive_count": counts[SentimentLabel.POSITIVE],
        "neutral_count": counts[SentimentLabel.NEUTRAL],
        "negative_count": counts[SentimentLabel.NEGATIVE],
        "items": classified,
        "overall_label": overall,
    }
