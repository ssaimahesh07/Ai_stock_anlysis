"""
Entry/Exit Research Signal Engine (spec Section 14).

This is the closest this platform comes to "when to enter / when to exit" —
and it is deliberately rule-based and fully explainable, not a black-box
"buy now" signal. It answers two separate questions:

  1. ENTRY: "Do current conditions support a hypothetical research entry,
     and if so, where would a disciplined trader define their zone, stop,
     and targets based on actual computed structure (S/R, ATR)?"

  2. EXIT (for an existing position): "Given today's price and the
     invalidation/target levels defined at entry, has an exit condition
     actually been triggered?"

Every level is derived from real technical structure (support/resistance,
ATR-based volatility). Nothing here is a prediction of what will happen —
it is a statement of what the data currently shows, plus the specific
price level(s) that would change that read. This must never be presented
as "guaranteed" — see HYPOTHETICAL_LEVELS_DISCLAIMER.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from backend.constants import HYPOTHETICAL_LEVELS_DISCLAIMER, ResearchSignal


@dataclass
class EntryPlan:
    signal: ResearchSignal
    entry_zone_low: float | None
    entry_zone_high: float | None
    invalidation_level: float | None
    target_1: float | None
    target_2: float | None
    risk_reward_ratio: float | None
    conditions_met: list[str]
    conditions_not_met: list[str]
    warnings: list[str] = field(default_factory=list)
    disclaimer: str = HYPOTHETICAL_LEVELS_DISCLAIMER


@dataclass
class ExitCheck:
    action: str  # "HOLD" | "EXIT_STOP_HIT" | "EXIT_TARGET_1_HIT" | "EXIT_TARGET_2_HIT" | "REVIEW"
    reason: str
    current_price: float
    distance_to_invalidation_pct: float | None
    distance_to_target_1_pct: float | None


# Minimum conditions (out of these checks) required to call something a
# "setup" at all, vs. NEUTRAL/INSUFFICIENT. Being explicit about the bar
# avoids implying a trade idea exists when the evidence is thin.
_MIN_CONDITIONS_FOR_BULLISH_SETUP = 3


def build_entry_plan(technical_result: dict, research_score: float | None) -> EntryPlan:
    """
    Evaluate a checklist of bullish conditions against the actual computed
    technical snapshot. This is transparent rule evaluation — every
    condition is either objectively true or false against real numbers,
    logged in conditions_met / conditions_not_met.
    """
    if not technical_result or technical_result.get("score") is None:
        return EntryPlan(
            signal=ResearchSignal.INSUFFICIENT_DATA,
            entry_zone_low=None, entry_zone_high=None, invalidation_level=None,
            target_1=None, target_2=None, risk_reward_ratio=None,
            conditions_met=[], conditions_not_met=["Insufficient price history to evaluate a setup."],
        )

    trend = technical_result["trend"]
    momentum = technical_result["momentum"]
    volume = technical_result["volume"]
    vol = technical_result["volatility"]
    sr = technical_result["support_resistance"]

    price = trend["price"]
    atr = vol["latest"]["atr_14"]

    checks = {
        "Price above 50-day SMA": trend["latest"]["sma_50"] is not None and price > trend["latest"]["sma_50"],
        "Price above 200-day SMA": trend["latest"]["sma_200"] is not None and price > trend["latest"]["sma_200"],
        "MACD histogram positive": momentum["latest"]["macd_histogram"] is not None and momentum["latest"]["macd_histogram"] > 0,
        "RSI in healthy range (40-70, not overbought)": momentum["latest"]["rsi_14"] is not None and 40 <= momentum["latest"]["rsi_14"] <= 70,
        "Volume at/above average": volume["latest"]["volume_ratio"] is not None and volume["latest"]["volume_ratio"] >= 0.9,
        "Not in a downtrend structure (no breakdown)": not sr["breakdown_detected"],
    }
    conditions_met = [k for k, v in checks.items() if v]
    conditions_not_met = [k for k, v in checks.items() if not v]

    n_met = len(conditions_met)

    if n_met >= 5 and (research_score or 0) >= 70:
        signal = ResearchSignal.STRONG_BULLISH_SETUP
    elif n_met >= _MIN_CONDITIONS_FOR_BULLISH_SETUP and (research_score or 0) >= 55:
        signal = ResearchSignal.BULLISH_SETUP
    elif n_met <= 1 and (research_score or 100) <= 35:
        signal = ResearchSignal.STRONG_BEARISH_SETUP
    elif n_met <= 2 and (research_score or 100) <= 45:
        signal = ResearchSignal.BEARISH_SETUP
    else:
        signal = ResearchSignal.NEUTRAL

    # Only compute hypothetical levels for setups where a bullish thesis is
    # actually being evaluated — a bearish/neutral read shouldn't ship a
    # "buy zone" that contradicts the signal.
    if signal in (ResearchSignal.STRONG_BULLISH_SETUP, ResearchSignal.BULLISH_SETUP) and atr is not None:
        support = sr["nearest_support"] or (price - 2 * atr)
        resistance = sr["nearest_resistance"]

        entry_zone_low = price
        entry_zone_high = round(price + 0.3 * atr, 2)
        # Invalidation level: use the CLOSER (tighter) of (nearest support,
        # ATR-based stop) so a distant support level never produces an
        # unreasonably wide stop — but keep the ATR multiplier tight enough
        # (1.2x) that a typical setup's risk/reward to Target 1 (2.0x ATR)
        # comes out above 1.0 by default.
        atr_based_stop = price - 1.2 * atr
        support_based_stop = support - 0.2 * atr
        invalidation_level = round(max(atr_based_stop, support_based_stop), 2)
        target_1 = round(price + 2.0 * atr, 2)
        target_2 = round(resistance, 2) if resistance and resistance > price else round(price + 3.5 * atr, 2)

        risk = entry_zone_low - invalidation_level
        reward = target_1 - entry_zone_low
        rr = round(reward / risk, 2) if risk > 0 else None
    else:
        entry_zone_low = entry_zone_high = invalidation_level = target_1 = target_2 = rr = None

    return EntryPlan(
        signal=signal,
        entry_zone_low=round(entry_zone_low, 2) if entry_zone_low else None,
        entry_zone_high=entry_zone_high,
        invalidation_level=invalidation_level,
        target_1=target_1,
        target_2=target_2,
        risk_reward_ratio=rr,
        conditions_met=conditions_met,
        conditions_not_met=conditions_not_met,
        warnings=(["Risk/reward ratio is below 1.0 — the hypothetical risk exceeds the hypothetical reward to Target 1. Many disciplined traders would skip a setup like this regardless of the signal label."] if rr is not None and rr < 1.0 else []),
    )


def check_exit_conditions(
    current_price: float,
    invalidation_level: float,
    target_1: float,
    target_2: float | None = None,
) -> ExitCheck:
    """
    Given a position's defined levels (set at entry — never recalculated
    after the fact to "make it work"), check whether the current price has
    actually triggered an exit condition. This is the "when to exit" half
    of the system: purely mechanical, no discretion, no hindsight bias.
    """
    dist_to_invalidation_pct = round((current_price - invalidation_level) / current_price * 100, 2)
    dist_to_target_1_pct = round((target_1 - current_price) / current_price * 100, 2)

    if current_price <= invalidation_level:
        return ExitCheck(
            action="EXIT_STOP_HIT",
            reason=f"Price ({current_price}) has reached or breached the invalidation level ({invalidation_level}). The original bullish thesis is no longer supported by price action.",
            current_price=current_price,
            distance_to_invalidation_pct=dist_to_invalidation_pct,
            distance_to_target_1_pct=dist_to_target_1_pct,
        )

    if target_2 is not None and current_price >= target_2:
        return ExitCheck(
            action="EXIT_TARGET_2_HIT",
            reason=f"Price ({current_price}) has reached Target 2 ({target_2}). Consider taking full/remaining profit per your plan.",
            current_price=current_price,
            distance_to_invalidation_pct=dist_to_invalidation_pct,
            distance_to_target_1_pct=dist_to_target_1_pct,
        )

    if current_price >= target_1:
        return ExitCheck(
            action="EXIT_TARGET_1_HIT",
            reason=f"Price ({current_price}) has reached Target 1 ({target_1}). Consider taking partial profit and/or trailing your stop to reduce risk on the remainder.",
            current_price=current_price,
            distance_to_invalidation_pct=dist_to_invalidation_pct,
            distance_to_target_1_pct=dist_to_target_1_pct,
        )

    return ExitCheck(
        action="HOLD",
        reason=f"Price ({current_price}) is between the invalidation level ({invalidation_level}) and Target 1 ({target_1}). No predefined exit condition has been triggered yet.",
        current_price=current_price,
        distance_to_invalidation_pct=dist_to_invalidation_pct,
        distance_to_target_1_pct=dist_to_target_1_pct,
    )
