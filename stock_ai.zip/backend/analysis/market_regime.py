"""
Market regime classification (spec Section 8).

Classifies overall market environment using a benchmark index's own
trend/volatility. Never presented as certain — always paired with the
UNCERTAIN state when signals conflict, and callers must display this as
an approximate read on conditions, not a fact.
"""
from __future__ import annotations

import pandas as pd

from backend.constants import MarketRegime
from backend.indicators.trend import trend_snapshot
from backend.indicators.volatility import volatility_snapshot


def classify_market_regime(index_df: pd.DataFrame) -> dict:
    """
    Args:
        index_df: OHLCV DataFrame for a benchmark index (e.g. S&P 500, NIFTY 50).
    Returns dict with `regime`, `confidence_note`, and supporting metrics.
    """
    if len(index_df) < 60:
        return {
            "regime": MarketRegime.UNCERTAIN,
            "reasons": ["Insufficient index history to classify market regime."],
        }

    trend = trend_snapshot(index_df)
    vol = volatility_snapshot(index_df)

    price = trend["price"]
    above_50 = trend["latest"]["sma_50"] is not None and price > trend["latest"]["sma_50"]
    above_200 = trend["latest"]["sma_200"] is not None and price > trend["latest"]["sma_200"]
    adx_v = trend["latest"]["adx_14"]
    strong_trend = adx_v is not None and adx_v >= 25

    reasons = []
    high_vol = vol["volatility_label"] == "High"
    if high_vol:
        reasons.append(f"Index historical volatility is elevated ({vol['latest']['historical_volatility_20']:.1f}% annualized).")

    if high_vol and adx_v is not None and adx_v < 20:
        regime = MarketRegime.HIGH_VOLATILITY
        reasons.append("Elevated volatility without a clear directional trend.")
    elif above_50 and above_200 and strong_trend:
        regime = MarketRegime.BULLISH
        reasons.append("Index is above both 50-day and 200-day moving averages with a strong trend (ADX).")
    elif not above_50 and not above_200 and strong_trend:
        regime = MarketRegime.BEARISH
        reasons.append("Index is below both 50-day and 200-day moving averages with a strong trend (ADX).")
    elif adx_v is not None and adx_v < 15:
        regime = MarketRegime.SIDEWAYS
        reasons.append(f"Low ADX ({adx_v:.1f}) indicates a lack of directional trend (range-bound).")
    else:
        regime = MarketRegime.UNCERTAIN
        reasons.append("Trend and moving-average signals are mixed or inconclusive.")

    return {
        "regime": regime,
        "reasons": reasons,
        "index_price": price,
        "above_sma_50": above_50,
        "above_sma_200": above_200,
        "adx": adx_v,
        "volatility_label": vol["volatility_label"],
    }
