"""
Technical analysis aggregator: combines trend/momentum/volatility/volume/S-R
indicators into a single 0-100 technical score with an explanation.

Scoring logic is rule-based and transparent (not a black box) — every point
awarded/deducted is traceable to a specific condition, listed in `reasons`.
"""
from __future__ import annotations

import pandas as pd

from backend.indicators import momentum as momentum_ind
from backend.indicators import support_resistance as sr_ind
from backend.indicators import trend as trend_ind
from backend.indicators import volatility as volatility_ind
from backend.indicators import volume as volume_ind


def compute_technical_score(df: pd.DataFrame) -> dict:
    """
    Returns a dict with: score (0-100), technical_snapshot (raw indicator
    values), reasons (list of human-readable contributing factors).

    Scoring is a simple additive rule system out of 100 points, distributed
    across trend (40), momentum (30), volume (15), and structure (15).
    This is intentionally transparent rather than a hidden ML black box —
    the ML probability estimate (separate, Phase 8) is where genuine
    statistical learning happens.
    """
    if len(df) < 60:
        return {
            "score": None,
            "reasons": ["Insufficient price history (need at least 60 bars) to compute a reliable technical score."],
            "trend": None, "momentum": None, "volatility": None, "volume": None, "support_resistance": None,
        }

    trend = trend_ind.trend_snapshot(df)
    momentum = momentum_ind.momentum_snapshot(df)
    volatility = volatility_ind.volatility_snapshot(df)
    volume = volume_ind.volume_snapshot(df)
    sr = sr_ind.support_resistance_snapshot(df)

    score = 0.0
    reasons: list[str] = []

    # --- Trend component (max 40) ---
    price = trend["price"]
    if trend["latest"]["sma_50"] is not None and price > trend["latest"]["sma_50"]:
        score += 12
        reasons.append("Price is above the 50-day moving average (short/medium-term uptrend support).")
    if trend["latest"]["sma_200"] is not None and price > trend["latest"]["sma_200"]:
        score += 13
        reasons.append("Price is above the 200-day moving average (long-term uptrend support).")
    if trend["latest"]["adx_14"] is not None and trend["latest"]["adx_14"] >= 25:
        score += 15
        reasons.append(f"ADX ({trend['latest']['adx_14']:.1f}) indicates a strong prevailing trend.")
    elif trend["latest"]["adx_14"] is not None and trend["latest"]["adx_14"] >= 15:
        score += 7
        reasons.append(f"ADX ({trend['latest']['adx_14']:.1f}) indicates a moderate trend.")

    # --- Momentum component (max 30) ---
    rsi_v = momentum["latest"]["rsi_14"]
    if rsi_v is not None:
        if 45 <= rsi_v <= 65:
            score += 10
            reasons.append(f"RSI ({rsi_v:.1f}) is in a healthy neutral-bullish range.")
        elif rsi_v > 70:
            score += 3
            reasons.append(f"RSI ({rsi_v:.1f}) is overbought — momentum strong but stretched, raising pullback risk.")
        elif rsi_v < 30:
            reasons.append(f"RSI ({rsi_v:.1f}) is oversold — momentum weak, though this can precede a bounce.")
    if momentum["latest"]["macd_histogram"] is not None and momentum["latest"]["macd_histogram"] > 0:
        score += 12
        reasons.append("MACD histogram is positive (bullish momentum).")
    if momentum["latest"]["roc_10"] is not None and momentum["latest"]["roc_10"] > 0:
        score += 8
        reasons.append(f"10-day rate of change is positive ({momentum['latest']['roc_10']:.1f}%).")

    # --- Volume component (max 15) ---
    if volume["latest"]["volume_ratio"] is not None:
        if volume["latest"]["volume_ratio"] >= 1.3:
            score += 15
            reasons.append(f"Volume is above average ({volume['latest']['volume_ratio']:.2f}x 20-day average), supporting conviction.")
        elif volume["latest"]["volume_ratio"] >= 0.8:
            score += 7
            reasons.append("Volume is near its average level.")
        else:
            reasons.append("Volume is below average, suggesting weaker participation.")

    # --- Structure component (max 15) ---
    if sr["breakout_detected"]:
        score += 15
        reasons.append(f"Price has broken above nearest resistance (~{sr['nearest_resistance']}).")
    elif sr["nearest_resistance"] is not None:
        distance_pct = (sr["nearest_resistance"] - price) / price * 100
        if distance_pct < 3:
            score += 8
            reasons.append(f"Price is approaching resistance (~{sr['nearest_resistance']}, {distance_pct:.1f}% away).")

    if sr["breakdown_detected"]:
        reasons.append(f"Price has broken below nearest support (~{sr['nearest_support']}) — structural weakness.")

    # Elevated volatility is noted but not scored positively or negatively on its own
    if volatility["volatility_label"] == "High":
        reasons.append("Volatility is elevated (wide ATR/Bollinger Bands), which increases both opportunity and risk.")

    score = max(0.0, min(100.0, score))

    return {
        "score": round(score, 1),
        "reasons": reasons,
        "trend": trend,
        "momentum": momentum,
        "volatility": volatility,
        "volume": volume,
        "support_resistance": sr,
    }
