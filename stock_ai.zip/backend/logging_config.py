"""
Centralized logging configuration.

Design goals:
- Structured, consistent log format across all modules.
- Never log secrets (API keys, tokens, passwords).
- Separate log files for general application logs vs. errors for easy triage.
- Console output in development, file output always.
"""
from __future__ import annotations

import logging
import logging.handlers
import sys
from pathlib import Path

from backend.config import get_settings

_CONFIGURED = False

# Substrings that should never appear in logs. Defense-in-depth on top of
# "never pass secrets into log calls" — a filter catches accidental leaks.
_SENSITIVE_MARKERS = ("api_key", "apikey", "secret", "password", "token")


class SensitiveDataFilter(logging.Filter):
    """Redacts log records whose message text looks like it contains a secret."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = str(record.getMessage()).lower()
        if any(marker in msg for marker in _SENSITIVE_MARKERS):
            record.msg = "[log message redacted: potential sensitive data]"
            record.args = ()
        return True


def configure_logging() -> None:
    """Idempotently configure root logging handlers. Call once at startup."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    settings = get_settings()
    log_dir = Path(settings.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(settings.log_level)

    # Console handler (development-friendly)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.addFilter(SensitiveDataFilter())
    root.addHandler(console_handler)

    # Rotating file handler — general logs
    file_handler = logging.handlers.RotatingFileHandler(
        log_dir / "app.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(SensitiveDataFilter())
    root.addHandler(file_handler)

    # Rotating file handler — errors only, for quick triage
    error_handler = logging.handlers.RotatingFileHandler(
        log_dir / "errors.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8"
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)
    error_handler.addFilter(SensitiveDataFilter())
    root.addHandler(error_handler)

    # Quiet noisy third-party libraries unless we're debugging
    for noisy_logger in ("urllib3", "httpx", "yfinance", "peewee"):
        logging.getLogger(noisy_logger).setLevel(logging.WARNING)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Get a module-level logger. Ensures logging is configured first."""
    configure_logging()
    return logging.getLogger(name)
