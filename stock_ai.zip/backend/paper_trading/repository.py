"""
Persistent paper-trading portfolio repository.

Wraps the pure-logic SimulatedPortfolio (backend/paper_trading/simulator.py)
with SQLAlchemy persistence, so orders/positions survive server restarts.
Every buy/sell is validated by the in-memory simulator's math (already
tested), then written to PaperPortfolio/PaperPosition/PaperOrder rows.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy.orm import Session

from backend.config import get_settings
from backend.constants import OrderSide, OrderStatus, OrderType
from backend.database.models import PaperOrder, PaperPortfolio, PaperPosition, PortfolioEquitySnapshot
from backend.exceptions import InsufficientFundsError, InvalidOrderError
from backend.logging_config import get_logger
from backend.paper_trading.simulator import SimulatedPortfolio

logger = get_logger(__name__)


def get_or_create_portfolio(db: Session, user_id: str, portfolio_name: str = "Paper Portfolio") -> PaperPortfolio:
    portfolio = (
        db.query(PaperPortfolio)
        .filter_by(user_id=user_id, name=portfolio_name)
        .first()
    )
    if portfolio is None:
        settings = get_settings()
        portfolio = PaperPortfolio(
            user_id=user_id,
            name=portfolio_name,
            starting_cash=settings.default_virtual_cash,
            cash_balance=settings.default_virtual_cash,
            max_risk_per_trade_pct=settings.default_max_risk_per_trade_pct,
            max_portfolio_exposure_pct=settings.default_max_portfolio_exposure_pct,
            max_open_positions=settings.default_max_open_positions,
        )
        db.add(portfolio)
        db.commit()
        db.refresh(portfolio)
        logger.info("Created new paper portfolio %s for user %s", portfolio.id, user_id)
    return portfolio


def _load_simulator(portfolio: PaperPortfolio) -> SimulatedPortfolio:
    """Rehydrate an in-memory SimulatedPortfolio from persisted DB rows."""
    settings = get_settings()
    sim = SimulatedPortfolio(
        cash=portfolio.cash_balance,
        transaction_cost_bps=settings.default_transaction_cost_bps,
        slippage_bps=settings.default_slippage_bps,
    )
    for pos in portfolio.positions:
        if pos.is_open:
            from backend.paper_trading.simulator import Position as SimPosition
            sim.positions[pos.symbol] = SimPosition(
                symbol=pos.symbol, quantity=pos.quantity,
                average_entry_price=pos.average_entry_price, realized_pnl=pos.realized_pnl,
            )
    return sim


def execute_buy(db: Session, portfolio: PaperPortfolio, symbol: str, quantity: float, market_price: float) -> PaperOrder:
    sim = _load_simulator(portfolio)
    try:
        fill = sim.buy(symbol, quantity, market_price)
    except (InsufficientFundsError, InvalidOrderError) as exc:
        order = PaperOrder(
            portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.BUY, order_type=OrderType.MARKET,
            status=OrderStatus.REJECTED, quantity=quantity, rejection_reason=str(exc),
        )
        db.add(order)
        db.commit()
        raise

    _persist_after_trade(db, portfolio, sim, symbol)

    order = PaperOrder(
        portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.BUY, order_type=OrderType.MARKET,
        status=OrderStatus.FILLED, quantity=quantity, fill_price=fill["fill_price"],
        transaction_cost=fill["transaction_cost"], filled_at=fill["timestamp"],
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    return order


def execute_sell(db: Session, portfolio: PaperPortfolio, symbol: str, quantity: float, market_price: float) -> PaperOrder:
    sim = _load_simulator(portfolio)
    try:
        fill = sim.sell(symbol, quantity, market_price)
    except InvalidOrderError as exc:
        order = PaperOrder(
            portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.SELL, order_type=OrderType.MARKET,
            status=OrderStatus.REJECTED, quantity=quantity, rejection_reason=str(exc),
        )
        db.add(order)
        db.commit()
        raise

    _persist_after_trade(db, portfolio, sim, symbol)

    order = PaperOrder(
        portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.SELL, order_type=OrderType.MARKET,
        status=OrderStatus.FILLED, quantity=quantity, fill_price=fill["fill_price"],
        transaction_cost=fill["transaction_cost"], filled_at=fill["timestamp"],
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    return order


def _persist_after_trade(db: Session, portfolio: PaperPortfolio, sim: SimulatedPortfolio, symbol: str) -> None:
    """Sync the DB portfolio cash and position rows after a simulator trade."""
    portfolio.cash_balance = sim.cash

    existing = db.query(PaperPosition).filter_by(portfolio_id=portfolio.id, symbol=symbol, is_open=True).first()

    if symbol in sim.positions:
        sim_pos = sim.positions[symbol]
        if existing:
            existing.quantity = sim_pos.quantity
            existing.average_entry_price = sim_pos.average_entry_price
            existing.realized_pnl = sim_pos.realized_pnl
        else:
            db.add(PaperPosition(
                portfolio_id=portfolio.id, symbol=symbol, quantity=sim_pos.quantity,
                average_entry_price=sim_pos.average_entry_price, realized_pnl=sim_pos.realized_pnl,
            ))
    else:
        # Position fully closed
        if existing:
            existing.is_open = False
            existing.closed_at = dt.datetime.now(dt.timezone.utc)

    db.commit()


def record_equity_snapshot(db: Session, portfolio: PaperPortfolio, positions_value: float) -> PortfolioEquitySnapshot:
    snapshot = PortfolioEquitySnapshot(
        portfolio_id=portfolio.id,
        as_of=dt.datetime.now(dt.timezone.utc),
        cash_balance=portfolio.cash_balance,
        positions_value=positions_value,
        total_equity=portfolio.cash_balance + positions_value,
    )
    db.add(snapshot)
    db.commit()
    db.refresh(snapshot)
    return snapshot
