"""
Database-backed paper trading portfolio management (spec Sections 19, 25).

Wraps the pure-logic SimulatedPortfolio (backend/paper_trading/simulator.py)
with SQLAlchemy persistence, so portfolios survive server restarts. Every
write happens inside a transaction; failures roll back cleanly rather than
leaving cash/position rows inconsistent.
"""
from __future__ import annotations

import datetime as dt

from sqlalchemy.orm import Session

from backend.config import get_settings
from backend.database.models import PaperOrder, PaperPortfolio, PaperPosition, PortfolioEquitySnapshot
from backend.constants import OrderSide, OrderStatus, OrderType
from backend.exceptions import InsufficientFundsError, InvalidOrderError
from backend.logging_config import get_logger

logger = get_logger(__name__)


def get_or_create_portfolio(db: Session, user_id: str, portfolio_name: str = "Default Paper Portfolio") -> PaperPortfolio:
    portfolio = (
        db.query(PaperPortfolio)
        .filter_by(user_id=user_id, name=portfolio_name)
        .first()
    )
    if portfolio is not None:
        return portfolio

    settings = get_settings()
    portfolio = PaperPortfolio(
        user_id=user_id,
        name=portfolio_name,
        starting_cash=settings.default_virtual_cash,
        cash_balance=settings.default_virtual_cash,
        max_risk_per_trade_pct=settings.default_max_risk_per_trade_pct,
        max_portfolio_exposure_pct=settings.default_max_portfolio_exposure_pct,
        max_open_positions=settings.default_max_open_positions,
    )
    db.add(portfolio)
    db.commit()
    db.refresh(portfolio)
    logger.info("Created new paper portfolio %s for user %s", portfolio.id, user_id)
    return portfolio


def execute_buy(db: Session, portfolio: PaperPortfolio, symbol: str, quantity: float, market_price: float) -> PaperOrder:
    settings = get_settings()
    if quantity <= 0:
        raise InvalidOrderError("Buy quantity must be positive.")
    if market_price <= 0:
        raise InvalidOrderError("market_price must be positive.")

    fill_price = market_price * (1 + settings.default_slippage_bps / 10_000)
    notional = quantity * fill_price
    cost = notional * (settings.default_transaction_cost_bps / 10_000)
    total_cost = notional + cost

    if total_cost > portfolio.cash_balance:
        order = PaperOrder(
            portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.BUY, order_type=OrderType.MARKET,
            status=OrderStatus.REJECTED, quantity=quantity,
            rejection_reason=f"Insufficient virtual cash: needs {total_cost:.2f}, has {portfolio.cash_balance:.2f}",
        )
        db.add(order)
        db.commit()
        raise InsufficientFundsError(order.rejection_reason)

    portfolio.cash_balance -= total_cost

    position = db.query(PaperPosition).filter_by(portfolio_id=portfolio.id, symbol=symbol, is_open=True).first()
    if position:
        new_qty = position.quantity + quantity
        position.average_entry_price = (position.average_entry_price * position.quantity + fill_price * quantity) / new_qty
        position.quantity = new_qty
    else:
        position = PaperPosition(portfolio_id=portfolio.id, symbol=symbol, quantity=quantity, average_entry_price=fill_price)
        db.add(position)

    order = PaperOrder(
        portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.BUY, order_type=OrderType.MARKET,
        status=OrderStatus.FILLED, quantity=quantity, fill_price=fill_price,
        transaction_cost=cost, slippage_applied=fill_price - market_price,
        filled_at=dt.datetime.now(dt.timezone.utc),
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    logger.info("BUY filled: %s x%s @ %.4f (portfolio %s)", symbol, quantity, fill_price, portfolio.id)
    return order


def execute_sell(db: Session, portfolio: PaperPortfolio, symbol: str, quantity: float, market_price: float) -> PaperOrder:
    settings = get_settings()
    if quantity <= 0:
        raise InvalidOrderError("Sell quantity must be positive.")
    if market_price <= 0:
        raise InvalidOrderError("market_price must be positive.")

    position = db.query(PaperPosition).filter_by(portfolio_id=portfolio.id, symbol=symbol, is_open=True).first()
    if position is None or position.quantity < quantity:
        held = position.quantity if position else 0
        order = PaperOrder(
            portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.SELL, order_type=OrderType.MARKET,
            status=OrderStatus.REJECTED, quantity=quantity,
            rejection_reason=f"Cannot sell {quantity}: only {held} held (no short-selling).",
        )
        db.add(order)
        db.commit()
        raise InvalidOrderError(order.rejection_reason)

    fill_price = market_price * (1 - settings.default_slippage_bps / 10_000)
    notional = quantity * fill_price
    cost = notional * (settings.default_transaction_cost_bps / 10_000)
    proceeds = notional - cost

    realized = (fill_price - position.average_entry_price) * quantity - cost
    position.realized_pnl += realized
    position.quantity -= quantity
    portfolio.cash_balance += proceeds

    if position.quantity == 0:
        position.is_open = False
        position.closed_at = dt.datetime.now(dt.timezone.utc)

    order = PaperOrder(
        portfolio_id=portfolio.id, symbol=symbol, side=OrderSide.SELL, order_type=OrderType.MARKET,
        status=OrderStatus.FILLED, quantity=quantity, fill_price=fill_price,
        transaction_cost=cost, slippage_applied=market_price - fill_price,
        filled_at=dt.datetime.now(dt.timezone.utc),
    )
    db.add(order)
    db.commit()
    db.refresh(order)
    logger.info("SELL filled: %s x%s @ %.4f realized_pnl=%.2f (portfolio %s)", symbol, quantity, fill_price, realized, portfolio.id)
    return order


def snapshot_equity(db: Session, portfolio: PaperPortfolio, prices: dict[str, float]) -> PortfolioEquitySnapshot:
    """Record a point-in-time equity snapshot for equity-curve charting."""
    open_positions = db.query(PaperPosition).filter_by(portfolio_id=portfolio.id, is_open=True).all()
    positions_value = sum(pos.quantity * prices.get(pos.symbol, pos.average_entry_price) for pos in open_positions)
    total_equity = portfolio.cash_balance + positions_value

    snap = PortfolioEquitySnapshot(
        portfolio_id=portfolio.id,
        as_of=dt.datetime.now(dt.timezone.utc),
        cash_balance=portfolio.cash_balance,
        positions_value=positions_value,
        total_equity=total_equity,
    )
    db.add(snap)
    db.commit()
    db.refresh(snap)
    return snap
