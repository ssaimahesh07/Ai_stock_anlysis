"""
Paper trading simulator (spec Section 19). Pure in-memory simulation logic,
independent of the database layer, so it's testable without SQLAlchemy.
The FastAPI layer (Phase 12) wires this to persistent PaperPortfolio rows.

NEVER connects to a real broker. No network calls happen in this module.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

from backend.exceptions import InsufficientFundsError, InvalidOrderError


@dataclass
class Position:
    symbol: str
    quantity: float
    average_entry_price: float
    realized_pnl: float = 0.0

    def unrealized_pnl(self, current_price: float) -> float:
        return (current_price - self.average_entry_price) * self.quantity

    def market_value(self, current_price: float) -> float:
        return self.quantity * current_price


@dataclass
class SimulatedPortfolio:
    """
    In-memory paper trading account. `positions` keyed by symbol.
    Transaction costs are applied as a flat basis-point fee on notional value.
    """

    cash: float
    transaction_cost_bps: float = 5.0
    slippage_bps: float = 2.0
    positions: dict[str, Position] = field(default_factory=dict)
    trade_log: list[dict] = field(default_factory=list)

    def total_position_value(self, prices: dict[str, float]) -> float:
        return sum(pos.market_value(prices.get(sym, pos.average_entry_price)) for sym, pos in self.positions.items())

    def total_equity(self, prices: dict[str, float]) -> float:
        return self.cash + self.total_position_value(prices)

    def buy(self, symbol: str, quantity: float, market_price: float, timestamp: dt.datetime | None = None) -> dict:
        if quantity <= 0:
            raise InvalidOrderError("Buy quantity must be positive.")
        if market_price <= 0:
            raise InvalidOrderError("market_price must be positive.")

        fill_price = market_price * (1 + self.slippage_bps / 10_000)
        notional = quantity * fill_price
        cost = notional * (self.transaction_cost_bps / 10_000)
        total_cost = notional + cost

        if total_cost > self.cash:
            raise InsufficientFundsError(
                f"Order requires {total_cost:.2f} but only {self.cash:.2f} virtual cash is available."
            )

        self.cash -= total_cost

        if symbol in self.positions:
            pos = self.positions[symbol]
            new_qty = pos.quantity + quantity
            pos.average_entry_price = (pos.average_entry_price * pos.quantity + fill_price * quantity) / new_qty
            pos.quantity = new_qty
        else:
            self.positions[symbol] = Position(symbol=symbol, quantity=quantity, average_entry_price=fill_price)

        record = {
            "timestamp": timestamp or dt.datetime.now(dt.timezone.utc),
            "symbol": symbol, "side": "BUY", "quantity": quantity,
            "fill_price": round(fill_price, 4), "transaction_cost": round(cost, 4),
        }
        self.trade_log.append(record)
        return record

    def sell(self, symbol: str, quantity: float, market_price: float, timestamp: dt.datetime | None = None) -> dict:
        if quantity <= 0:
            raise InvalidOrderError("Sell quantity must be positive.")
        if market_price <= 0:
            raise InvalidOrderError("market_price must be positive.")
        if symbol not in self.positions or self.positions[symbol].quantity < quantity:
            held = self.positions[symbol].quantity if symbol in self.positions else 0
            raise InvalidOrderError(
                f"Cannot sell {quantity} shares of {symbol}: only {held} held (no short-selling supported)."
            )

        fill_price = market_price * (1 - self.slippage_bps / 10_000)
        notional = quantity * fill_price
        cost = notional * (self.transaction_cost_bps / 10_000)
        proceeds = notional - cost

        pos = self.positions[symbol]
        realized = (fill_price - pos.average_entry_price) * quantity - cost
        pos.realized_pnl += realized
        pos.quantity -= quantity
        self.cash += proceeds

        if pos.quantity == 0:
            del self.positions[symbol]

        record = {
            "timestamp": timestamp or dt.datetime.now(dt.timezone.utc),
            "symbol": symbol, "side": "SELL", "quantity": quantity,
            "fill_price": round(fill_price, 4), "transaction_cost": round(cost, 4),
            "realized_pnl": round(realized, 4),
        }
        self.trade_log.append(record)
        return record
