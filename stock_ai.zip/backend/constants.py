"""
Shared enums and constant text used across the platform.

Centralizing the disclaimer text and label enums here ensures every part of
the app (API responses, UI, reports) uses identical, unwatered-down language
about the probabilistic and non-guaranteed nature of the outputs.
"""
from __future__ import annotations

from enum import Enum


class MarketRegime(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    SIDEWAYS = "SIDEWAYS"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    UNCERTAIN = "UNCERTAIN"


class ResearchSignal(str, Enum):
    STRONG_BULLISH_SETUP = "STRONG BULLISH SETUP"
    BULLISH_SETUP = "BULLISH SETUP"
    NEUTRAL = "NEUTRAL"
    BEARISH_SETUP = "BEARISH SETUP"
    STRONG_BEARISH_SETUP = "STRONG BEARISH SETUP"
    INSUFFICIENT_DATA = "INSUFFICIENT DATA"


class RiskLevel(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    UNKNOWN = "Unknown"


class SentimentLabel(str, Enum):
    POSITIVE = "Positive"
    NEUTRAL = "Neutral"
    NEGATIVE = "Negative"


class ValidationStage(str, Enum):
    """Used to label backtest / ML results so users know how trustworthy a number is."""

    IN_SAMPLE = "in_sample"
    VALIDATION = "validation"
    OUT_OF_SAMPLE = "out_of_sample"


class OrderSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"


class OrderStatus(str, Enum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


# ----------------------------------------------------------------------------
# Disclaimer text — used verbatim in API responses and UI. Do not soften.
# ----------------------------------------------------------------------------
GENERAL_DISCLAIMER = (
    "This application is a financial research and paper-trading tool. Its "
    "outputs are probabilistic estimates based on historical and available "
    "data and are not guaranteed predictions of future market movements. "
    "Nothing in this application constitutes personalized financial advice "
    "or a guarantee of profit."
)

ML_PROBABILITY_DISCLAIMER = (
    "This is a model-estimated probability derived from historical patterns. "
    "It does NOT mean a guaranteed chance of profit, and past performance of "
    "the model is not indicative of future results."
)

HYPOTHETICAL_LEVELS_DISCLAIMER = (
    "These are hypothetical research levels derived from technical structure, "
    "not guaranteed entry, exit, or profit levels. Markets can move through "
    "any level without warning."
)

BACKTEST_DISCLAIMER = (
    "Backtested performance is based on historical data and simplifying "
    "assumptions (e.g. transaction costs, slippage, fill logic). It does not "
    "guarantee similar results in live or future markets."
)

INSUFFICIENT_DATA_LABEL = "Insufficient data"
DELAYED_DATA_LABEL = "Delayed market data"
