"""
Risk engine (spec Section 20): validates proposed paper trades against
configured account risk limits before an order is allowed to fill.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.exceptions import RiskLimitExceededError


@dataclass
class RiskCheckResult:
    approved: bool
    reasons: list[str]


def check_order_risk(
    account_equity: float,
    proposed_position_value: float,
    current_total_exposure_value: float,
    current_open_positions: int,
    max_portfolio_exposure_pct: float,
    max_open_positions: int,
) -> RiskCheckResult:
    reasons: list[str] = []

    prospective_exposure_pct = (current_total_exposure_value + proposed_position_value) / account_equity * 100 if account_equity else 100.0
    if prospective_exposure_pct > max_portfolio_exposure_pct:
        reasons.append(
            f"Proposed trade would bring total exposure to {prospective_exposure_pct:.1f}%, "
            f"exceeding the configured max of {max_portfolio_exposure_pct:.1f}%."
        )

    if current_open_positions >= max_open_positions:
        reasons.append(
            f"Already at max open positions ({current_open_positions}/{max_open_positions})."
        )

    return RiskCheckResult(approved=len(reasons) == 0, reasons=reasons)


def enforce_order_risk(*args, **kwargs) -> None:
    """Raises RiskLimitExceededError if check_order_risk(...) disapproves. Convenience wrapper."""
    result = check_order_risk(*args, **kwargs)
    if not result.approved:
        raise RiskLimitExceededError("; ".join(result.reasons))
