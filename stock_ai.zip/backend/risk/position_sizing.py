"""
Position sizing based on account risk and distance to invalidation level
(spec Section 20). Never encourages leverage beyond 1x account equity.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PositionSizeResult:
    shares: float
    dollar_risk: float
    position_value: float
    position_pct_of_account: float
    warnings: list[str]


def calculate_position_size(
    account_equity: float,
    entry_price: float,
    invalidation_price: float,
    max_risk_per_trade_pct: float,
    max_position_pct_of_account: float = 100.0,
) -> PositionSizeResult:
    """
    Position size = (account risk in $) / (per-share risk in $).

    Where account risk = account_equity * max_risk_per_trade_pct / 100, and
    per-share risk = |entry_price - invalidation_price|.
    """
    warnings: list[str] = []

    if entry_price <= 0 or invalidation_price <= 0:
        raise ValueError("entry_price and invalidation_price must be positive.")
    if entry_price == invalidation_price:
        raise ValueError("entry_price and invalidation_price cannot be equal (zero risk distance).")

    per_share_risk = abs(entry_price - invalidation_price)
    dollar_risk = account_equity * (max_risk_per_trade_pct / 100)
    shares = dollar_risk / per_share_risk

    position_value = shares * entry_price
    max_position_value = account_equity * (max_position_pct_of_account / 100)

    if position_value > max_position_value:
        shares = max_position_value / entry_price
        position_value = shares * entry_price
        warnings.append(
            f"Position size capped by max_position_pct_of_account ({max_position_pct_of_account}%); "
            f"actual risk taken is below the requested {max_risk_per_trade_pct}% due to this cap."
        )

    if position_value > account_equity:
        warnings.append("Calculated position value exceeds account equity — this would require leverage, which is not supported by this paper-trading engine.")
        shares = account_equity / entry_price
        position_value = account_equity

    return PositionSizeResult(
        shares=round(shares, 4),
        dollar_risk=round(dollar_risk, 2),
        position_value=round(position_value, 2),
        position_pct_of_account=round(position_value / account_equity * 100, 2) if account_equity else 0.0,
        warnings=warnings,
    )
