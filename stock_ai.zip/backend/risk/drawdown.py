"""Drawdown calculations for portfolio equity curves."""
from __future__ import annotations

import pandas as pd


def compute_drawdown_series(equity_curve: pd.Series) -> pd.Series:
    running_max = equity_curve.cummax()
    return (equity_curve - running_max) / running_max * 100


def max_drawdown(equity_curve: pd.Series) -> float:
    if len(equity_curve) < 2:
        return 0.0
    return float(compute_drawdown_series(equity_curve).min())


def current_drawdown(equity_curve: pd.Series) -> float:
    if len(equity_curve) < 2:
        return 0.0
    return float(compute_drawdown_series(equity_curve).iloc[-1])
