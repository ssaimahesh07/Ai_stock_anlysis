"""
Tests for DB-persisted paper trading (backend/paper_trading/repository.py).

Run with: pytest tests/test_paper_trading_repository.py -v
"""
from __future__ import annotations

import pytest

from backend.database.models import User
from backend.exceptions import InsufficientFundsError, InvalidOrderError
from backend.paper_trading.portfolio import (
    execute_buy,
    execute_sell,
    get_or_create_portfolio,
)


@pytest.fixture()
def user(db_session):
    u = User(email="paper_trader@example.com", hashed_password="x")
    db_session.add(u)
    db_session.commit()
    return u


def test_get_or_create_portfolio_is_idempotent(db_session, user):
    pf1 = get_or_create_portfolio(db_session, user.id, "Test Portfolio")
    pf2 = get_or_create_portfolio(db_session, user.id, "Test Portfolio")
    assert pf1.id == pf2.id
    assert pf1.cash_balance == pf1.starting_cash


def test_buy_persists_position_and_reduces_cash(db_session, user):
    portfolio = get_or_create_portfolio(db_session, user.id, "Test Portfolio")
    starting_cash = portfolio.cash_balance

    order = execute_buy(db_session, portfolio, "AAPL", 10, 150.0)

    db_session.refresh(portfolio)
    assert order.status.value == "FILLED"
    assert portfolio.cash_balance < starting_cash

    open_positions = [p for p in portfolio.positions if p.is_open]
    assert len(open_positions) == 1
    assert open_positions[0].symbol == "AAPL"
    assert open_positions[0].quantity == 10


def test_sell_reduces_position_and_increases_cash(db_session, user):
    portfolio = get_or_create_portfolio(db_session, user.id, "Test Portfolio")
    execute_buy(db_session, portfolio, "MSFT", 20, 300.0)
    db_session.refresh(portfolio)
    cash_after_buy = portfolio.cash_balance

    order = execute_sell(db_session, portfolio, "MSFT", 10, 320.0)
    db_session.refresh(portfolio)

    assert order.status.value == "FILLED"
    assert portfolio.cash_balance > cash_after_buy

    open_positions = [p for p in portfolio.positions if p.is_open]
    assert len(open_positions) == 1
    assert open_positions[0].quantity == 10


def test_full_sell_closes_position(db_session, user):
    portfolio = get_or_create_portfolio(db_session, user.id, "Test Portfolio")
    execute_buy(db_session, portfolio, "GOOG", 5, 100.0)
    db_session.refresh(portfolio)

    execute_sell(db_session, portfolio, "GOOG", 5, 110.0)
    db_session.refresh(portfolio)

    open_positions = [p for p in portfolio.positions if p.is_open]
    closed_positions = [p for p in portfolio.positions if not p.is_open]
    assert len(open_positions) == 0
    assert len(closed_positions) == 1
    assert closed_positions[0].closed_at is not None


def test_insufficient_funds_creates_rejected_order(db_session, user):
    portfolio = get_or_create_portfolio(db_session, user.id, "Test Portfolio")

    with pytest.raises(InsufficientFundsError):
        execute_buy(db_session, portfolio, "BRK.A", 1000, 500000.0)

    rejected_orders = [o for o in portfolio.orders if o.status.value == "REJECTED"]
    assert len(rejected_orders) == 1
    assert rejected_orders[0].rejection_reason is not None


def test_sell_unheld_symbol_creates_rejected_order(db_session, user):
    portfolio = get_or_create_portfolio(db_session, user.id, "Test Portfolio")

    with pytest.raises(InvalidOrderError):
        execute_sell(db_session, portfolio, "NFLX", 5, 400.0)

    rejected_orders = [o for o in portfolio.orders if o.status.value == "REJECTED"]
    assert len(rejected_orders) == 1


def test_average_entry_price_updates_across_multiple_buys(db_session, user):
    portfolio = get_or_create_portfolio(db_session, user.id, "Test Portfolio")
    execute_buy(db_session, portfolio, "TSLA", 10, 100.0)
    execute_buy(db_session, portfolio, "TSLA", 10, 120.0)
    db_session.refresh(portfolio)

    open_positions = [p for p in portfolio.positions if p.is_open and p.symbol == "TSLA"]
    assert len(open_positions) == 1
    pos = open_positions[0]
    assert pos.quantity == 20
    # Average entry should be between 100 and 120, closer to midpoint (fees/slippage cause slight skew)
    assert 105 < pos.average_entry_price < 115
