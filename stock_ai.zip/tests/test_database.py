"""
Tests for the database layer: table creation, CRUD basics, and constraints.

Run with: pytest tests/test_database.py -v
"""
from __future__ import annotations

import datetime as dt

import pytest
from sqlalchemy.exc import IntegrityError

from backend.constants import MarketRegime, OrderSide, OrderType, ValidationStage
from backend.database.models import (
    AlertType,
    Alert,
    AnalysisResult,
    BacktestResult,
    HistoricalDataMeta,
    MLModel,
    PaperOrder,
    PaperPortfolio,
    PaperPosition,
    StockMetadata,
    User,
    Watchlist,
    WatchlistItem,
)


def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def test_tables_created(db_session):
    """All expected tables should exist after Base.metadata.create_all()."""
    from backend.database.database import Base

    table_names = set(Base.metadata.tables.keys())
    expected = {
        "users",
        "stock_metadata",
        "historical_data_meta",
        "analysis_results",
        "ml_models",
        "backtest_results",
        "watchlists",
        "watchlist_items",
        "paper_portfolios",
        "paper_positions",
        "paper_orders",
        "portfolio_equity_history",
        "alerts",
    }
    assert expected.issubset(table_names)


def test_create_user(db_session):
    user = User(email="researcher@example.com", hashed_password="not_a_real_hash")
    db_session.add(user)
    db_session.commit()

    fetched = db_session.query(User).filter_by(email="researcher@example.com").first()
    assert fetched is not None
    assert fetched.is_active is True
    assert fetched.id is not None  # UUID auto-generated


def test_user_email_unique_constraint(db_session):
    db_session.add(User(email="dup@example.com", hashed_password="x"))
    db_session.commit()

    db_session.add(User(email="dup@example.com", hashed_password="y"))
    with pytest.raises(IntegrityError):
        db_session.commit()
    db_session.rollback()


def test_stock_metadata_insufficient_data_representation(db_session):
    """
    Fields the provider couldn't supply should be NULL, never a fabricated
    default like 0 or empty string (spec Section 6: 'Insufficient data').
    """
    meta = StockMetadata(symbol="RELIANCE.NS", company_name="Reliance Industries")
    db_session.add(meta)
    db_session.commit()

    fetched = db_session.get(StockMetadata, "RELIANCE.NS")
    assert fetched.company_name == "Reliance Industries"
    assert fetched.market_cap is None  # not fabricated
    assert fetched.sector is None


def test_watchlist_with_items_cascade_delete(db_session):
    user = User(email="watchlist_user@example.com", hashed_password="x")
    db_session.add(user)
    db_session.commit()

    wl = Watchlist(user_id=user.id, name="My Core Holdings")
    db_session.add(wl)
    db_session.commit()

    item = WatchlistItem(watchlist_id=wl.id, symbol="RELIANCE.NS")
    db_session.add(item)
    db_session.commit()

    assert len(wl.items) == 1

    db_session.delete(wl)
    db_session.commit()

    remaining = db_session.query(WatchlistItem).filter_by(watchlist_id=wl.id).all()
    assert remaining == []  # cascade delete worked


def test_watchlist_duplicate_symbol_constraint(db_session):
    user = User(email="dup_symbol@example.com", hashed_password="x")
    db_session.add(user)
    db_session.commit()

    wl = Watchlist(user_id=user.id, name="Test")
    db_session.add(wl)
    db_session.commit()

    db_session.add(WatchlistItem(watchlist_id=wl.id, symbol="TCS.NS"))
    db_session.commit()

    db_session.add(WatchlistItem(watchlist_id=wl.id, symbol="TCS.NS"))
    with pytest.raises(IntegrityError):
        db_session.commit()
    db_session.rollback()


def test_ml_model_registry_traceability(db_session):
    """
    Every ML model row must carry enough metadata to be fully traceable
    (spec Section 31): training period, features, target, validation method.
    """
    model = MLModel(
        name="reliance_10d_return_classifier",
        version="v1",
        algorithm="RandomForestClassifier",
        training_period_start=dt.datetime(2019, 1, 1, tzinfo=dt.timezone.utc),
        training_period_end=dt.datetime(2023, 12, 31, tzinfo=dt.timezone.utc),
        prediction_horizon_days=10,
        target_return_threshold_pct=3.0,
        target_definition="1 if 10-day forward return > 3% else 0",
        features=["rsi_14", "macd_hist", "atr_14", "volume_ratio"],
        validation_methodology="walk-forward: 3y train / 1y validate / 1y test",
        accuracy=0.58,
        roc_auc=0.61,
    )
    db_session.add(model)
    db_session.commit()

    fetched = db_session.query(MLModel).first()
    assert fetched.features == ["rsi_14", "macd_hist", "atr_14", "volume_ratio"]
    assert fetched.validation_methodology.startswith("walk-forward")
    assert fetched.roc_auc == 0.61


def test_analysis_result_links_to_model_and_stores_warnings(db_session):
    model = MLModel(
        name="test_model",
        version="v1",
        algorithm="LogisticRegression",
        training_period_start=_utcnow(),
        training_period_end=_utcnow(),
        prediction_horizon_days=10,
        target_return_threshold_pct=3.0,
        target_definition="test",
        features=["rsi_14"],
        validation_methodology="walk-forward",
    )
    db_session.add(model)
    db_session.commit()

    result = AnalysisResult(
        symbol="INFY.NS",
        as_of=_utcnow(),
        research_score=72.5,
        market_regime=MarketRegime.BULLISH,
        ml_model_id=model.id,
        ml_estimated_probability=0.63,
        warnings=["Fundamental data partially unavailable"],
        scoring_weights_used={"technical": 0.25, "fundamental": 0.20},
        is_delayed_data=True,
    )
    db_session.add(result)
    db_session.commit()

    fetched = db_session.query(AnalysisResult).filter_by(symbol="INFY.NS").first()
    assert fetched.ml_model.name == "test_model"
    assert fetched.market_regime == MarketRegime.BULLISH
    assert "Fundamental data partially unavailable" in fetched.warnings
    assert fetched.is_delayed_data is True


def test_backtest_result_validation_stage_labeling(db_session):
    """Backtest results must be tagged with a validation stage (spec Section 13)."""
    bt = BacktestResult(
        symbol="RELIANCE.NS",
        strategy_name="trend_following",
        strategy_params={"fast_ma": 20, "slow_ma": 50},
        period_start=dt.datetime(2024, 1, 1, tzinfo=dt.timezone.utc),
        period_end=dt.datetime(2024, 12, 31, tzinfo=dt.timezone.utc),
        validation_stage=ValidationStage.OUT_OF_SAMPLE,
        cagr_pct=14.2,
        sharpe_ratio=1.1,
        max_drawdown_pct=-18.4,
        win_rate_pct=47.0,
        profit_factor=1.35,
        num_trades=22,
        benchmark_return_pct=11.0,
        benchmark_symbol="^NSEI",
    )
    db_session.add(bt)
    db_session.commit()

    fetched = db_session.query(BacktestResult).first()
    assert fetched.validation_stage == ValidationStage.OUT_OF_SAMPLE
    assert fetched.benchmark_symbol == "^NSEI"


def test_paper_portfolio_no_real_broker_fields(db_session):
    """
    Structural guarantee: PaperPortfolio/PaperOrder have no broker credential
    or live-execution fields, reflecting the paper-trading-only architecture.
    """
    user = User(email="trader@example.com", hashed_password="x")
    db_session.add(user)
    db_session.commit()

    portfolio = PaperPortfolio(
        user_id=user.id,
        starting_cash=100_000.0,
        cash_balance=100_000.0,
        max_risk_per_trade_pct=1.0,
        max_portfolio_exposure_pct=50.0,
        max_open_positions=10,
    )
    db_session.add(portfolio)
    db_session.commit()

    order = PaperOrder(
        portfolio_id=portfolio.id,
        symbol="RELIANCE.NS",
        side=OrderSide.BUY,
        order_type=OrderType.MARKET,
        quantity=10,
        fill_price=2500.0,
        transaction_cost=12.5,
    )
    db_session.add(order)
    db_session.commit()

    fetched_order = db_session.query(PaperOrder).first()
    assert fetched_order.side == OrderSide.BUY
    # Confirm no broker-related columns exist on the model
    column_names = {c.name for c in PaperOrder.__table__.columns}
    assert "broker_account_id" not in column_names
    assert "broker_api_key" not in column_names


def test_alert_no_guaranteed_profit_language_in_schema(db_session):
    """
    condition_params is a free-form JSON dict for structured rule config —
    ensures alerts are rule-based, not "AI says buy" black-box messages.
    """
    user = User(email="alert_user@example.com", hashed_password="x")
    db_session.add(user)
    db_session.commit()

    alert = Alert(
        user_id=user.id,
        symbol="TCS.NS",
        alert_type=AlertType.RSI_CONDITION,
        condition_params={"rsi_period": 14, "threshold": 30, "direction": "below"},
    )
    db_session.add(alert)
    db_session.commit()

    fetched = db_session.query(Alert).first()
    assert fetched.alert_type == AlertType.RSI_CONDITION
    assert fetched.condition_params["threshold"] == 30
    assert fetched.trigger_count == 0
