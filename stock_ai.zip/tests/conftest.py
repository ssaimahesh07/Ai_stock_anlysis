"""
Shared pytest fixtures.

Uses an isolated in-memory SQLite database per test session so tests never
touch the real development database file.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Force an in-memory test database BEFORE backend.config is imported anywhere,
# so get_settings() picks it up.
os.environ["DATABASE_URL"] = "sqlite:///:memory:"
os.environ["MARKET_DATA_PROVIDER"] = "mock"
os.environ["NEWS_PROVIDER"] = "mock"

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from backend.database.database import Base


@pytest.fixture()
def db_session():
    """Fresh in-memory SQLite database + session for each test function."""
    engine = create_engine(
        "sqlite:///:memory:", connect_args={"check_same_thread": False}
    )
    from backend.database import models  # noqa: F401 — register models

    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    session: Session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine)
