# Stock AI Research Platform

A multi-factor, evidence-based **stock research and paper-trading platform**.

> ⚠️ **This is a research and educational tool.** It does not predict the market
> with certainty, does not guarantee profits, and does not place real trades.
> See [Disclaimer](#disclaimer) below.

## Status

Core platform is now **runnable end-to-end**: data layer, all technical
indicators, multi-factor scoring, ML training pipeline with walk-forward
validation, backtesting engine, risk engine, paper trading simulator,
FastAPI backend, and a mobile-friendly Streamlit frontend.

| Phase | Description | Status |
|---|---|---|
| 1 | Project structure & configuration | ✅ Done |
| 2 | Database layer | ✅ Done |
| 3 | Market data abstraction | ✅ Done |
| 4 | Technical indicators | ✅ Done |
| 5–7 | Fundamental / sentiment / multi-factor scoring | ✅ Done |
| 8 | ML pipeline (walk-forward validated) | ✅ Done |
| 9 | Backtesting engine | ✅ Done |
| 10 | Risk engine | ✅ Done |
| 11 | Paper trading | ✅ Done |
| 12 | FastAPI backend | ✅ Done |
| 13 | Frontend (Streamlit, mobile-friendly) | ✅ Done |
| 14 | Testing | 🟡 Partial (see below) |
| 15 | Docker/deployment | ✅ Done |
| — | Entry/Exit signal engine + Scanner + DB-persisted paper trading | ✅ Done |

**Not yet wired:** sector-strength scoring (needs a peer/sector data
source) and live market-regime injection into the per-stock analysis
endpoint (the classifier exists in `backend/analysis/market_regime.py` but
needs a benchmark index symbol wired in — the multi-factor score already
gracefully redistributes their weight to available factors in the
meantime). Alerts and watchlists have DB schema ready but no API endpoints
yet. ML probability estimates (Phase 8's trained model) aren't yet
surfaced in the live analysis endpoint — `backend/ml/train.py` works
standalone (see step 9 below) but isn't called from the API on each
request, since training per-request would be too slow; the natural next
step is a scheduled/background training job that populates the
`MLModel`/`AnalysisResult` tables.

## Running this on your phone/tablet

This ships as a **responsive web app**, not a native app-store app:

1. Run the backend + frontend (locally, on a home server, or a cloud VM —
   see below).
2. On your phone/tablet, open the Streamlit URL in the browser
   (`http://<server-ip>:8501`).
3. The layout is mobile-responsive (Streamlit stacks vertically on narrow
   screens).

For "live" data: this only becomes genuinely live once you run it on a
machine with real internet access — this project was developed in a
sandboxed environment with no network access, which is disclosed
throughout. `yfinance` (default provider, no API key needed) gives free,
**delayed** market data, not real-time. The app always labels this clearly.

## 1–4. Install, venv, dependencies, configure

```bash
cd stock_ai
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # defaults work with zero API keys (yfinance + mock news)
```

## 5. Initialize the database

```bash
python scripts/init_db.py
```

## 6. Start the backend

```bash
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

Visit `http://localhost:8000/docs` for interactive Swagger API docs.

## 7. Start the frontend

In a second terminal:

```bash
streamlit run frontend/app.py --server.address=0.0.0.0
```

Visit `http://localhost:8501` (or `http://<your-lan-ip>:8501` from your
phone on the same Wi-Fi).

## 8. Run tests

```bash
pytest -v
```

## 9. Train a model (example, via Python shell or a script you add)

```python
from backend.data.market_data import get_provider
from backend.ml.train import train_model

provider = get_provider()
history = provider.get_history("AAPL", period="5y", interval="1d")
result = train_model(history.data, horizon_days=10, threshold_pct=3.0, algorithm="random_forest")
print(result.test_metrics)
```

## 10. Run backtests

```bash
curl -X POST http://localhost:8000/api/v1/backtesting/run \
  -H "Content-Type: application/json" \
  -d '{"symbol": "AAPL", "strategy": "trend_following", "period": "2y"}'
```

Or use the **Backtesting** page in the Streamlit UI.

## 11. Deploy (Docker)

```bash
docker compose up --build
```

- Backend: `http://<host>:8000`
- Frontend: `http://<host>:8501`

For a cloud deployment (e.g. a VPS, Render, Railway, Fly.io, or a home
server exposed via Tailscale/Cloudflare Tunnel for phone access anywhere),
point `docker-compose.yml`'s `.env` at your production `DATABASE_URL`
(uncomment the Postgres service) and open ports 8000/8501 (or put both
behind a reverse proxy like nginx/Caddy on 443 with TLS).

## What actually got tested, and how

This project was built in a **sandboxed environment with no internet
access** — `pip install` of FastAPI/SQLAlchemy/yfinance was not possible
there. To keep this honest rather than just claiming things work:

- **Real execution, real assertions** (not just "looks right"): all
  indicators (trend/momentum/volatility/volume/support-resistance),
  technical/fundamental scoring, market regime classification, sentiment
  analysis, the multi-factor weight-redistribution logic, ML feature
  engineering (explicitly verified **zero look-ahead bias** by comparing
  truncated- vs full-dataset feature computation row-by-row), ML training
  with chronological walk-forward splits, the backtest engine (including a
  real bug caught and fixed — an exposure% calculation), and the paper
  trading simulator (buy/sell/avg-price/P&L/insufficient-funds/no-shorting)
  were all executed against real synthetic data with `pandas`/`numpy`/
  `scikit-learn`, which are available in the sandbox, and passed.
- **Static + structural validation only** (not executed) for everything
  touching `fastapi`, `pydantic`, `sqlalchemy`: AST syntax-parsed (55/55
  files pass), plus structural cross-checks (every DB model field
  referenced in tests confirmed to exist; every SQLAlchemy
  `relationship(back_populates=...)` pair confirmed symmetric).
- **You should run `pytest -v` yourself** after `pip install -r
  requirements.txt` to get true confirmation of the FastAPI/DB layers —
  flagged rather than assumed.

## The "when to enter / when to exit" feature — what it actually is

`backend/analysis/entry_exit.py` is the closest this platform comes to
that question, and it's built to be mechanical and auditable, not a
black-box "buy now" button:

- **Entry side (`build_entry_plan`):** evaluates a fixed checklist of
  objective, real conditions (price vs. 50/200-day SMA, MACD histogram,
  RSI range, volume, support/resistance structure) against actual computed
  numbers. Only when enough conditions are met AND the Research Score
  supports it does it produce a `BULLISH SETUP` / `STRONG BULLISH SETUP`
  signal — and only then does it compute an entry zone, stop
  (invalidation), and two targets, derived from ATR and support/resistance
  (never guessed). If conditions don't support a bullish read, it
  explicitly returns `NEUTRAL` (or bearish) with **no entry zone at all**
  — it will never show a "buy zone" that contradicts its own signal. A
  poor risk/reward setup (<1.0) is flagged with an explicit warning rather
  than hidden. Verified via testing across dozens of randomized scenarios:
  entry/stop/target levels are always internally consistent (stop below
  entry, targets above), and typical R:R lands around 1.7 by construction.
- **Exit side (`check_exit_conditions`):** given the levels defined at
  entry (which you supply back in — the system never silently redefines
  them after the fact to "make the trade work"), checks current price
  against them and returns `HOLD`, `EXIT_STOP_HIT`, `EXIT_TARGET_1_HIT`,
  or `EXIT_TARGET_2_HIT`. Purely mechanical, no discretion, no hindsight
  bias.
- Exposed via `GET /api/v1/analysis/{symbol}` (entry plan, in
  `hypothetical_research_setup`) and `GET
  /api/v1/analysis/{symbol}/exit-check?invalidation_level=...&target_1=...`,
  and surfaced in the Streamlit "Hypothetical Setup" tab with a live
  "Check current exit status" button.

**What this is not:** a prediction, a guarantee, or a claim that following
it will be profitable. It tells you what a disciplined, rule-based read of
current data supports, and exactly what would change that read. See
`HYPOTHETICAL_LEVELS_DISCLAIMER` in `backend/constants.py`, shown
alongside every result.

## Known limitations

- No authentication enforced yet (schema exists, endpoints are open).
- Paper trading portfolio is currently in-memory per server process (not
  yet persisted to the `PaperPortfolio` DB tables) — resets on restart.
  Swapping in persistence is straightforward since `SimulatedPortfolio` is
  already decoupled from storage.
- Sector strength and live market-regime are not yet wired into the
  per-stock analysis endpoint (multi-factor score redistributes their
  weight to available factors in the meantime, per Section 9 design).
- Scanner/ranking, alerts, and watchlist endpoints are not yet built
  (Sections 16, 22, 24) — DB schema is ready for them.
- **ESP32 / microcontrollers cannot run this.** An ESP32 has ~320–520KB of
  RAM; this platform needs years of historical data, scikit-learn/XGBoost
  models, and multi-factor computation — fundamentally server/PC-class
  work. An ESP32 *could* act as a thin display client polling this API for
  a single stock's score/alert, if useful as a future add-on.
- No feature here outputs a "guaranteed" entry/exit or profit signal, by
  design — see the disclaimers embedded throughout the API responses and
  UI. This reflects the explicit non-goal stated in the original spec
  (Section 40): nothing in trading can be guaranteed.

## Project structure

```
stock_ai/
├── backend/
│   ├── main.py                # FastAPI app entrypoint (Phase 12)
│   ├── config.py               # ✅ Centralized settings (env-driven)
│   ├── logging_config.py       # ✅ Structured logging setup
│   ├── exceptions.py           # ✅ Shared exception types
│   ├── constants.py            # ✅ Shared enums + disclaimer text
│   ├── api/                    # FastAPI routers
│   ├── data/                   # Market data / fundamentals / news providers
│   ├── indicators/             # Technical indicator calculations
│   ├── analysis/               # Technical/fundamental/sentiment/regime/multi-factor
│   ├── ml/                     # Feature engineering, training, prediction
│   ├── backtesting/            # Backtest engine, strategies, metrics
│   ├── risk/                   # Risk engine, position sizing, drawdown
│   ├── paper_trading/          # Simulated portfolio, orders
│   └── database/               # SQLAlchemy models + session management
├── frontend/                   # Streamlit MVP (later React option)
├── tests/                      # pytest test suite
├── scripts/                    # CLI utilities (train model, run backtest, init db)
├── .env.example                # Environment variable template (NO real secrets)
├── requirements.txt
├── Dockerfile
└── docker-compose.yml
```

## 1. Install Python

Requires **Python 3.12+**. Verify with:

```bash
python3 --version
```

## 2. Create a virtual environment

```bash
cd stock_ai
python3 -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
```

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 4. Configure environment variables

```bash
cp .env.example .env
```

Then edit `.env`. For local development, the defaults work with **no API
keys at all**:
- `MARKET_DATA_PROVIDER=yfinance` (free, no key required)
- `NEWS_PROVIDER=mock` (returns clearly-labeled empty/mock results — never
  fabricates real news)

If you later want Alpha Vantage or a real news API, set `MARKET_DATA_PROVIDER`,
`MARKET_DATA_API_KEY`, `NEWS_PROVIDER`, `NEWS_API_KEY` accordingly.

**Never commit your `.env` file.** It's already in `.gitignore`.

## 5. Initialize the database

```bash
python scripts/init_db.py
```

This creates all tables (users, watchlists, stock metadata, historical data
metadata, analysis results, ML model registry, backtest results, paper
trading portfolios/positions/orders, portfolio equity history, alerts) in
SQLite by default. For PostgreSQL, set `DATABASE_URL` in `.env` first — no
code changes needed, the schema is dialect-agnostic.

**Database schema overview** (`backend/database/models.py`):

| Table | Purpose |
|---|---|
| `users` | Auth-ready user accounts (bcrypt password hashes only) |
| `stock_metadata` | Cached descriptive info per symbol; unknown fields are `NULL`, never fabricated |
| `historical_data_meta` | Tracks what OHLCV ranges/intervals have been fetched, and freshness |
| `analysis_results` | Point-in-time Research Score snapshots with full sub-score breakdown |
| `ml_models` | Model registry — every prediction traces to training period, features, target, validation method, and held-out performance |
| `backtest_results` | Backtest metrics tagged with `validation_stage` (in-sample / validation / out-of-sample) |
| `watchlists` / `watchlist_items` | User watchlists |
| `paper_portfolios` / `paper_positions` / `paper_orders` | Simulated trading only — no broker credential fields exist anywhere in this schema |
| `portfolio_equity_history` | Equity curve snapshots for charting |
| `alerts` | Rule-based alert conditions (JSON config), not black-box "AI says buy" messages |

For production, prefer **Alembic migrations** over calling `init_db()`
against an existing database with real data.

## 6. Start the backend

*(Available starting Phase 12)*

```bash
uvicorn backend.main:app --reload --port 8000
```

## 7. Start the frontend

*(Available starting Phase 13)*

```bash
streamlit run frontend/app.py
```

## 8. Run tests

```bash
pytest -v
```

## 9. Train a model

*(Available starting Phase 8)*

```bash
python scripts/train_model.py --symbol RELIANCE.NS --horizon 10
```

## 10. Run backtests

*(Available starting Phase 9)*

```bash
python scripts/run_backtest.py --symbol RELIANCE.NS --strategy trend_following
```

## 11. Deploy

*(Available starting Phase 15 — Docker Compose, cloud-ready)*

## Configuration reference

All settings are defined in `backend/config.py` and overridable via `.env`.
Key categories:

- **Scoring weights** — how the multi-factor Research Score is computed
  (Technical 25%, Fundamental 20%, Momentum 15%, Volume 10%, Market Regime
  10%, Sector Strength 5%, Sentiment 5%, Risk/Reward 10% by default). Must
  sum to 1.0 — this is validated at startup.
- **ML settings** — prediction horizon, target threshold, training window,
  walk-forward split sizes.
- **Risk settings** — max risk per trade, max exposure, max open positions.
- **Paper trading defaults** — starting virtual cash, transaction costs,
  slippage assumptions.
- **Caching TTLs** — how long quotes/history/fundamentals/news are cached
  before re-fetching.

## Disclaimer

> This application is a financial research and paper-trading tool. Its
> outputs are probabilistic estimates based on historical and available data
> and are not guaranteed predictions of future market movements. Nothing in
> this application constitutes personalized financial advice or a guarantee
> of profit.

This disclaimer text is defined once in `backend/constants.py`
(`GENERAL_DISCLAIMER`) and reused everywhere it needs to appear (API
responses, UI footer, reports) so it can never drift or be watered down in
one place and not another.

## License

See `LICENSE`.
