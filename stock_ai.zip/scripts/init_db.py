"""
CLI script: initialize the database (create all tables if they don't exist).

Usage:
    python scripts/init_db.py
"""
from __future__ import annotations

import sys
from pathlib import Path

# Allow running as `python scripts/init_db.py` from project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.database.database import init_db
from backend.logging_config import get_logger

logger = get_logger(__name__)


def main() -> None:
    logger.info("Initializing database...")
    init_db()
    logger.info("Database initialization complete.")


if __name__ == "__main__":
    main()
