"""
Stock AI Research Platform — Streamlit frontend.

Mobile/tablet-friendly by design: Streamlit's default layout stacks
vertically on narrow screens, so this works in your phone's browser
without a separate native app. Run with:

    streamlit run frontend/app.py

Talks to the FastAPI backend over HTTP (must be running separately, see
README). No business logic lives here — this is a thin presentation layer.
"""
from __future__ import annotations

import os

import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st

API_BASE = os.environ.get("STOCK_AI_API_BASE", "http://localhost:8000/api/v1")

st.set_page_config(page_title="Stock AI Research Platform", page_icon="📊", layout="wide")

# --- Mobile-friendly CSS tweaks ---
st.markdown(
    """
    <style>
    .block-container { padding-top: 1.2rem; padding-bottom: 2rem; }
    @media (max-width: 640px) {
        .block-container { padding-left: 0.6rem; padding-right: 0.6rem; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)


def api_get(path: str, params: dict | None = None) -> dict | None:
    try:
        resp = requests.get(f"{API_BASE}{path}", params=params, timeout=20)
        if resp.status_code != 200:
            st.error(f"API error ({resp.status_code}): {resp.json().get('detail', resp.text)}")
            return None
        return resp.json()
    except requests.exceptions.ConnectionError:
        st.error(
            "Cannot reach the backend API. Make sure it's running: "
            "`uvicorn backend.main:app --reload`"
        )
        return None


def api_post(path: str, json: dict) -> dict | None:
    try:
        resp = requests.post(f"{API_BASE}{path}", json=json, timeout=30)
        if resp.status_code != 200:
            st.error(f"API error ({resp.status_code}): {resp.json().get('detail', resp.text)}")
            return None
        return resp.json()
    except requests.exceptions.ConnectionError:
        st.error("Cannot reach the backend API.")
        return None


# --- Sidebar navigation ---
st.sidebar.title("📊 Stock AI Research")
page = st.sidebar.radio(
    "Navigate",
    ["Stock Analysis", "Scanner", "Backtesting", "Paper Trading", "Market Overview"],
    label_visibility="collapsed",
)

st.sidebar.markdown("---")
st.sidebar.caption(
    "⚠️ Research & education only. Not financial advice. No guaranteed "
    "profits. All predictions are probabilistic estimates."
)

# ==========================================================================
# STOCK ANALYSIS PAGE
# ==========================================================================
if page == "Stock Analysis":
    st.title("Stock Research Report")
    symbol = st.text_input("Enter a ticker symbol", value="AAPL", placeholder="e.g. AAPL, RELIANCE.NS, TCS.NS")

    if st.button("Analyze", type="primary", use_container_width=True) and symbol:
        with st.spinner(f"Analyzing {symbol}..."):
            report = api_get(f"/analysis/{symbol}")

        if report:
            st.caption(
                f"Data as of: {report['data_as_of']} · "
                f"{'⚠️ Delayed data' if report['is_delayed_data'] else ''} "
                f"{'· ⚠️ Data may be stale' if report['is_stale_data'] else ''}"
            )

            score = report["research_score"]
            col1, col2, col3 = st.columns(3)
            col1.metric("Research Score", f"{score}/100" if score is not None else "Insufficient data")
            col2.metric("Research Signal", report["research_signal"])
            col3.metric("Risk Level", report["risk_level"])

            st.info(report["explanation"])

            # --- Price chart ---
            hist = api_get(f"/stocks/{symbol}/history", params={"period": "1y", "interval": "1d"})
            if hist and hist["bars"]:
                df = pd.DataFrame(hist["bars"])
                df["date"] = pd.to_datetime(df["date"])
                fig = go.Figure(data=[go.Candlestick(
                    x=df["date"], open=df["open"], high=df["high"], low=df["low"], close=df["close"], name=symbol,
                )])
                fig.update_layout(height=400, margin=dict(l=10, r=10, t=30, b=10), xaxis_rangeslider_visible=False)
                st.plotly_chart(fig, use_container_width=True)

                vol_fig = go.Figure(data=[go.Bar(x=df["date"], y=df["volume"], name="Volume")])
                vol_fig.update_layout(height=180, margin=dict(l=10, r=10, t=10, b=10))
                st.plotly_chart(vol_fig, use_container_width=True)

            tabs = st.tabs(["Technical", "Fundamental", "News/Sentiment", "Hypothetical Setup"])

            with tabs[0]:
                tech = report["technical_analysis"]
                st.write(f"**Score:** {tech['score']}/100" if tech["score"] is not None else "**Insufficient data**")
                st.write(f"Trend: {tech.get('trend_label')} · RSI: {tech.get('rsi_label')} · Volatility: {tech.get('volatility_label')} · Volume: {tech.get('volume_label')}")
                for r in tech.get("reasons") or []:
                    st.write(f"- {r}")
                if tech.get("support_levels"):
                    st.write(f"**Support levels:** {tech['support_levels']}")
                if tech.get("resistance_levels"):
                    st.write(f"**Resistance levels:** {tech['resistance_levels']}")

            with tabs[1]:
                fund = report["fundamental_analysis"]
                st.write(f"**Score:** {fund['score']}/100" if fund["score"] is not None else "**Insufficient data**")
                for r in fund.get("reasons") or []:
                    st.write(f"- {r}")

            with tabs[2]:
                sent = report["news_sentiment"]
                c1, c2, c3 = st.columns(3)
                c1.metric("Positive", sent["positive_count"])
                c2.metric("Neutral", sent["neutral_count"])
                c3.metric("Negative", sent["negative_count"])
                for item in sent.get("items") or []:
                    st.write(f"**[{item['sentiment']}]** {item['headline']} — *{item['source']}*")
                if not sent.get("items"):
                    st.caption("No recent news available for this symbol.")

            with tabs[3]:
                hyp = report["hypothetical_research_setup"]
                if hyp.get("available"):
                    st.warning(hyp["disclaimer"])
                    for w in hyp.get("warnings") or []:
                        st.error(w)
                    c1, c2 = st.columns(2)
                    c1.metric("Entry zone", f"{hyp['entry_zone_low']} – {hyp['entry_zone_high']}")
                    c1.metric("Invalidation (stop)", hyp["invalidation_level"])
                    c2.metric("Target 1", hyp["target_1"])
                    c2.metric("Target 2", hyp["target_2"])
                    st.metric("Risk/Reward", hyp.get("risk_reward_ratio") or "N/A")
                    st.write("**Conditions met:**")
                    for c in hyp.get("conditions_met") or []:
                        st.write(f"✅ {c}")
                    st.write("**Conditions not met:**")
                    for c in hyp.get("conditions_not_met") or []:
                        st.write(f"❌ {c}")
                    st.markdown("---")
                    st.subheader("Check Exit Now")
                    st.caption("Once you're in a position, use these SAME levels to check if an exit has been mechanically triggered — no guesswork.")
                    if st.button("Check current exit status", key="exit_check_btn"):
                        exit_result = api_get(f"/analysis/{symbol}/exit-check", params={
                            "invalidation_level": hyp["invalidation_level"],
                            "target_1": hyp["target_1"],
                            "target_2": hyp["target_2"],
                        })
                        if exit_result:
                            action = exit_result["action"]
                            if action == "HOLD":
                                st.info(f"**{action}** — {exit_result['reason']}")
                            elif action.startswith("EXIT"):
                                st.warning(f"**{action}** — {exit_result['reason']}")
                            st.caption(exit_result["disclaimer"])
                else:
                    st.caption(f"Signal: {hyp.get('signal')}. No hypothetical bullish entry zone is generated for this signal — conditions do not currently support one.")
                    st.write("**Conditions met:**")
                    for c in hyp.get("conditions_met") or []:
                        st.write(f"✅ {c}")
                    st.write("**Conditions not met:**")
                    for c in hyp.get("conditions_not_met") or []:
                        st.write(f"❌ {c}")

            st.caption(report["disclaimer"])

elif page == "Scanner":
    st.title("Stock Scanner")
    st.caption("Ranks multiple symbols by Research Score. One symbol failing never blocks the rest.")

    symbols_input = st.text_area("Symbols (comma or newline separated)", value="AAPL, MSFT, GOOG, TSLA, AMZN")
    min_score = st.slider("Minimum Research Score", 0, 100, 0)

    if st.button("Run Scan", type="primary", use_container_width=True):
        symbols = [s.strip() for s in symbols_input.replace("\n", ",").split(",") if s.strip()]
        with st.spinner(f"Scanning {len(symbols)} symbols..."):
            result = api_post("/scanner/scan", {"symbols": symbols, "min_score": min_score if min_score > 0 else None})
        if result:
            st.write(f"Scanned {result['total_scanned']} · Scored {result['total_scored']}")

            st.subheader("Top Candidates")
            if result["top_candidates"]:
                st.dataframe(pd.DataFrame(result["top_candidates"]), use_container_width=True)
            else:
                st.caption("No candidates matched the filter.")

            st.subheader("Worst Setups")
            if result["worst_setups"]:
                st.dataframe(pd.DataFrame(result["worst_setups"]), use_container_width=True)

            if result["requiring_more_data"]:
                st.subheader("Requiring More Data")
                st.dataframe(pd.DataFrame(result["requiring_more_data"]), use_container_width=True)

            st.caption(result["disclaimer"])

# ==========================================================================
# BACKTESTING PAGE
# ==========================================================================
elif page == "Backtesting":
    st.title("Strategy Backtesting")
    col1, col2 = st.columns(2)
    symbol = col1.text_input("Symbol", value="AAPL")
    strategy = col2.selectbox("Strategy", ["trend_following", "mean_reversion"])
    period = st.select_slider("History period", options=["6mo", "1y", "2y", "5y"], value="2y")

    with st.expander("Advanced settings"):
        c1, c2, c3 = st.columns(3)
        capital = c1.number_input("Initial capital", value=100000)
        stop_loss = c2.number_input("Stop loss %", value=8.0)
        take_profit = c3.number_input("Take profit %", value=20.0)

    if st.button("Run Backtest", type="primary", use_container_width=True):
        with st.spinner("Running backtest..."):
            result = api_post("/backtesting/run", {
                "symbol": symbol, "strategy": strategy, "period": period,
                "initial_capital": capital, "stop_loss_pct": stop_loss, "take_profit_pct": take_profit,
            })
        if result:
            m = result["metrics"]
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Total Return", f"{m.get('total_return_pct')}%")
            c2.metric("CAGR", f"{m.get('cagr_pct')}%")
            c3.metric("Sharpe", m.get("sharpe_ratio"))
            c4.metric("Max Drawdown", f"{m.get('max_drawdown_pct')}%")

            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Win Rate", f"{m.get('win_rate_pct')}%")
            c2.metric("Profit Factor", m.get("profit_factor"))
            c3.metric("# Trades", m.get("num_trades"))
            c4.metric("Exposure", f"{result.get('exposure_pct')}%")

            eq_df = pd.DataFrame(result["equity_curve"])
            eq_df["date"] = pd.to_datetime(eq_df["date"])
            fig = go.Figure(data=[go.Scatter(x=eq_df["date"], y=eq_df["equity"], mode="lines", name="Equity")])
            fig.update_layout(height=350, margin=dict(l=10, r=10, t=30, b=10), title="Equity Curve")
            st.plotly_chart(fig, use_container_width=True)

            st.warning(result["disclaimer"])

# ==========================================================================
# PAPER TRADING PAGE
# ==========================================================================
elif page == "Paper Trading":
    st.title("Paper Trading (Simulated)")
    st.caption("No real money or broker involved. Virtual cash only.")

    pf = api_get("/portfolio/default")
    if pf:
        c1, c2 = st.columns(2)
        c1.metric("Cash", f"${pf['cash']:,.2f}")
        c2.metric("Total Equity", f"${pf['total_equity']:,.2f}")

        if pf["positions"]:
            st.subheader("Open Positions")
            st.dataframe(pd.DataFrame(pf["positions"]), use_container_width=True)
        else:
            st.caption("No open positions.")

        st.subheader("Place Order")
        c1, c2, c3 = st.columns(3)
        order_symbol = c1.text_input("Symbol", value="AAPL", key="order_symbol")
        order_qty = c2.number_input("Quantity", min_value=1.0, value=10.0)
        side = c3.selectbox("Side", ["BUY", "SELL"])

        if st.button("Submit Order", type="primary"):
            endpoint = "/portfolio/buy" if side == "BUY" else "/portfolio/sell"
            result = api_post(endpoint, {"symbol": order_symbol, "quantity": order_qty})
            if result:
                st.success(f"Order filled: {result['side']} {result['quantity']} {result['symbol']} @ {result['fill_price']}")
                st.rerun()

        st.caption(pf["disclaimer"])

# ==========================================================================
# MARKET OVERVIEW PAGE
# ==========================================================================
elif page == "Market Overview":
    st.title("Market Overview")
    health = api_get("/health")
    if health:
        st.write(f"**Provider:** {health['market_data_provider']} · **Server time (UTC):** {health['server_time_utc']}")
    st.info(
        "Market regime classification requires benchmark index history and "
        "is available via the analysis engine (backend.analysis.market_regime); "
        "wire an index symbol here to display it live."
    )
    st.caption(health["disclaimer"] if health else "")
